function [data, samp_rate, ch_name, date] = ReadNsnFile(filename)
% reads NSN format file
% [data, samp_rate, ch_name, date] = ReadNsnFile(filename)
%
% Created  By: Satoshi MURATA (1),  satoshi-m@atr.jp  09/12/28
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/03/01
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/04/14
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Add path (if needed:)
str = which('ns_OpenFile');
if isempty(str)
    dirname = uigetdir(pwd, 'Select ''read_neuroshare_matlab'' directory');
    if ~ischar(dirname)
        error('''read_neuroshare_matlab'' directory can''t find');
    end
    addpath(dirname);
end


%% Read NSN file:
warning('off');

% open file:
hFile = ns_OpenFile(filename);

% check file:
nsFileInfo = ns_GetFileInfo(hFile);
if ~strcmp(nsFileInfo.AppName,'SimpleConverter')
    error('This file wasn''t made by ''SimpleConverter''');
end

% get date:
date = sprintf('%04d/%02d/%02d %02d:%02d:%02d',...
               nsFileInfo.Time_Year, nsFileInfo.Time_Month, nsFileInfo.Time_Day,...
               nsFileInfo.Time_Hour, nsFileInfo.Time_Min, nsFileInfo.Time_Sec);

% get data:
nsEntityInfo            = ns_GetEntityInfo(hFile);
[data_name, nouse, ind] = unique({nsEntityInfo.EntityLabel});
num_data                = length(data_name);
data                    = cell(1,num_data);
samp_rate               = cell(1,num_data);
ch_name                 = cell(1,num_data);

nsAnalogInfo            = ns_GetAnalogInfo(hFile);
[nouse, nsAnalogData]   = ns_GetAnalogData(hFile);
nsNeuralInfo            = ns_GetNeuralInfo(hFile);
nsNeuralData            = ns_GetNeuralData(hFile);
nsEventInfo             = ns_GetEventInfo(hFile);
[timestamp, eventdata]  = ns_GetEventData(hFile);

for itd=1:num_data
    pos_ch = find(ind==itd);
    switch nsEntityInfo(pos_ch(1)).EntityType
        case 1      % Event Entity (EVENT)
            for itc=1:length(pos_ch)
                data{itd}{itc}{1} = timestamp{pos_ch(itc)};
                data{itd}{itc}{2} = eventdata{pos_ch(itc)};
            end
            samp_rate{itd} = [];
            ch_name{itd}   = {nsEventInfo(pos_ch).CSVDesc};
            ch_name{itd}   = [data_name{itd} ch_name{itd}];
        case 2      % Analog Entity (TIME SERIES)
            data{itd}      = nsAnalogData(pos_ch);
            samp_rate{itd} = [nsAnalogInfo(pos_ch).SampleRate];
            ch_name{itd}   = {nsAnalogInfo(pos_ch).ProbeInfo};
            ch_name{itd}   = [data_name{itd} ch_name{itd}];
            data{itd}      = cell2mat(data{itd}');
        case 4      % Neural Entity (SPIKE)
            data{itd}      = nsNeuralData(pos_ch)';
            samp_rate{itd} = [];
            ch_name{itd}   = {nsNeuralInfo(pos_ch).ProbeInfo};
            ch_name{itd}   = [data_name{itd} ch_name{itd}];
    end
end

ns_CloseFile(hFile);

warning('on');




