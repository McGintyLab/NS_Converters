function [data, samp_rate, ch_name, date] = CheckArgs(data, samp_rate, ch_name, date)
% checks input args of ns_Converter
%
% Created  By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/04/15
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Data:
if isempty(data)
    error('''data'' should be specified');
elseif ~iscell(data)
    data = {data};
end

num_cell = length(data);


%% Sampling rate:
if isempty(samp_rate)
    samp_rate = cell(1,num_cell);
elseif ~iscell(samp_rate)
    samp_rate = {samp_rate};
end
if length(samp_rate)~=num_cell
    if num_cell==1 && length(samp_rate)==size(data{1},2)
        samp_rate = {samp_rate};
    else
        error('number of channel in ''data'' and length of ''samp_rate'' are different');
    end
end


%% Channel name:
if isempty(ch_name)
    ch_name = [repmat('measure',num_cell,1) num2str((1:num_cell)')];
    ch_name = mat2cell(ch_name,repmat(1,num_cell,1),size(ch_name,2))';
elseif ~iscell(ch_name)
    ch_name = {ch_name};
end
if length(ch_name)~=num_cell && length(ch_name)~=1
    if num_cell==1 && (length(ch_name)==size(data{1},2) || length(ch_name)==size(data{1},2)+1)
        ch_name = {ch_name};
    else
        error('number of ''data'' and length of ''ch_name'' are different');
    end
end


%% Date:
if ~exist('date','var') || isempty(date)
%    date = datestr(now, 'yyyy/mm/dd HH:MM:SS');
    date = fix(clock);
else
    date = textscan(date, '%f/%f/%f %f:%f:%f');
    if ~isempty(find(cellfun(@isempty,date),1))
        error('format of ''date'' is wrong');
    end
    date = cell2mat(date);
end
