function [data, samp_rate, ch_name, ch_desc, date, file_type, file_desc] = ReadMatFile(mat_filename)
% reads MAT-file, and makes input-args of SimpleConverter
% [data, samp_rate, ch_name, ch_desc, date, file_type, file_desc] = ReadCsvFormat(csv_filename)
%
% Input:
%   csv_filename - CSV filename; if absent, you should put by dialog
%
% Output:
%   data      - brain activity and behavioral data, {[time x space], ...}
%   samp_rate - sampring rate, [1 x channel]
%   ch_name   - channel name, {1 x channel}
%   ch_desc   - description of each channel, {1 x channel}
%   date      - date of experiment, [yyyy, mm, dd, HH, MM, SS]
%   file_type - explanation of this file/experiment
%   file_desc - comment of this file/experiment
%
% Created  By: Satoshi MURATA (1),  satoshi-m@atr.jp  11/04/01
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/04/03
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Check arg:
if ~exist('mat_filename','var') || isempty(mat_filename)
    [file, path] = uigetfile({'*.mat','MAT-files (*.mat)'}, 'Select MAT file');
    if isequal(file,0)
        error('MAT filename should be specified');
    end
    mat_filename = fullfile(path, file);
end


%% Read file:
rdata  = load(mat_filename);

% data:
if ~isfield(rdata,'data')
    error('''data'' should be included in MAT-file');
end
data   = rdata.data;

num_ch = size(data,2);

% samp_rate
samp_rate = getFieldDef(rdata,'srate',NaN(1,num_ch));

% ch_name:
if isfield(rdata,'ch_inf') && isfield(rdata.ch_inf,'name')
    ch_name = {rdata.ch_inf.name};
elseif isfield(rdata,'ch_name')
    ch_name = rdata.ch_name;
else
    ch_name = [repmat('ch',num_ch,1) num2str((1:num_ch)')];
    ch_name = mat2cell(ch_name,ones(num_ch,1),size(ch_name,2))';
end

% ch_desc:
if isfield(rdata,'ch_inf') && isfield(rdata.ch_inf,'comment')
    ch_desc = {rdata.ch_inf.comment};
else
    ch_desc = getFieldDef(rdata,'ch_comment',repmat(cellstr(''),1,num_ch));
end

% date:
if isfield(rdata,'file_inf') && isfield(rdata.file_inf,'date')
    date = rdata.file_inf.date;
else
    date = getFieldDef(rdata,'date',clock);
end
if ischar(date)
    date = textscan(date, '%f/%f/%f %f:%f:%f');
    if ~isempty(find(cellfun(@isempty,date),1))
        error('format of ''date'' is wrong');
    end
    date = cell2mat(date);
end

% file_type:
if isfield(rdata,'file_inf') && isfield(rdata.file_inf,'title')
    file_type = rdata.file_inf.title;
elseif isfield(rdata,'title')
    file_type = rdata.title;
else
    [nouse, fname] = fileparts(mat_filename);
    file_type      = fname;
end

% file_desc:
if isfield(rdata,'file_inf') && isfield(rdata.file_inf,'explanation')
    file_desc = rdata.file_inf.explanation;
else
    file_desc = getFieldDef(rdata,'explanation','');
end





%% ----------------------------------------------------------------------------
function val = getFieldDef(S,field,def)
% return S.<field> if S has field, return def if S doesn't have field

if isfield(S,field)
    val = S.(field);
else
    val = def;
end
