function result = AddData(data, samp_rate, ch_name, filename)
% add data into 'filename'
%
% Created  By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/04/19
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Add path (if needed):
str = which('ns_CreateFile');
if isempty(str)
    dirname = uigetdir(pwd,'Select ''ns_CreateFile'' directory');
    if ~ischar(dirname)
        error('''ns_Create Library'' can''t find');
    end
    addpath(dirname);
end


%% Add data:
% open file:
fid = fopen(filename,'a');

% write data:
num_cell = length(data);
num_data = 0;
for itd=1:num_cell
    % judge entity type:
    if ~isempty(samp_rate{itd})
        etype = 2;      % TIME SERIES data (Analog entity)
    elseif ~iscell(data{itd}{1})
        etype = 4;      % TIME STAMP data (Neural event entity)
    else
        etype = 1;      % EVENT data (Event entity)
    end
    
    switch etype
        case 1      % Event entity
            num_add_data = AddEventData(fid, data{itd}, ch_name{itd});
        case 2      % Analog entity
            num_add_data = AddAnalogData(fid, data{itd}, samp_rate{itd}, ch_name{itd});
        case 4      % Neural event entity
            num_add_data = AddNeuralData(fid, data{itd}, ch_name{itd});
    end
    
    num_data = num_data + num_add_data;
end

% close file:
fclose(fid);


%% Update 'EntityCount':
% open file:
fid = fopen(filename,'r+');

% read 'EnityCount':
fseek(fid, 16+32, 'bof');
ecount = fread(fid, 1, 'uint32');

% write new value:
fseek(fid, 16+32, 'bof');
fwrite(fid, ecount+num_data, 'uint32');

% close file:
fclose(fid);



result = 0;
