function num_data = AddEventData(fid, data, ch_name)
% add Event data into preexisted nsn file
%
% Created  By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/04/19
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Calculate length in bytes of the following data:
elength = 32+4*2 + 4*3+128;


%% Make EntityLabel:
elabel = [ch_name{1} blanks(32)];
elabel = elabel(1:32);


%% Add data:
num_ch = length(data);
for itc=1:num_ch
    num_samp = length(data{itc}{1});
    
    % judge EventType:
    if iscell(data{itc}{2})
        evalue = data{itc}{2}{1};
    else
        evalue = data{itc}{2}(1);
    end
    switch class(evalue)
        case 'char'
            etype = 0;      % TEXT
            dsize = 1;
        case {'uint8','int8'}
            etype = 2;      % BYTE
            dsize = 1;
        case {'uint16','int16'}
            etype = 3;      % WORD
            dsize = 2;
        case {'uint32','int32'}
            etype = 4;      % DWORD
            dsize = 4;
        otherwise
            etype = -1;     % Maybe 'double'
            dsize = 4;
    end
    
    % cast EventValue:
    if isequal(etype,-1)
        if iscell(data{itc}{2})
            data{itc}{2} = cell2mat(data{itc}{2});
        end
        data{itc}{2} = cast(data{itc}{2},'int32');
        etype        = 4;
    end
    
    % write ns_TAGELEMENT:
    fwrite(fid, 1, 'uint32');                                               % ElemType (Event = 1)
    if isequal(etype,0)
        num_char = cellfun('length',data{itc}{2});
        fwrite(fid, elength+(8+4)*num_samp+dsize*sum(num_char), 'uint32');  % ElemLength (text)
    else
        fwrite(fid, elength+(8+4+dsize)*num_samp, 'uint32');                % ElemLength (integer)
    end
    
    % write ns_ENTITYINFO:
    fwrite(fid, elabel);                % EntityLabel
    fwrite(fid, 1, 'uint32');           % EntityType
    fwrite(fid, num_samp, 'uint32');    % ItemCount
    
    % write ns_EVENTINFO:
    fwrite(fid, etype, 'uint32');       % EventType
    if isequal(etype,0)
        fwrite(fid, min(num_char), 'uint32');   % MinDataLength
        fwrite(fid, max(num_char), 'uint32');   % MaxDataLength
    else
        fwrite(fid, dsize, 'uint32');   % MinDataLength
        fwrite(fid, dsize, 'uint32');   % MaxDataLength
    end
    csvdesc = [ch_name{itc+1} blanks(128)];
    fwrite(fid, csvdesc(1:128));        % CSVDesc
    
    % write data
    for its=1:num_samp
        fwrite(fid, data{itc}{1}(its), 'double');   % Timestamp
        if isequal(etype,0)
            fwrite(fid, num_char(its), 'uint32');   % DataByteSize (text)
            fwrite(fid, data{itc}{2}{its});         % EventValue (text)
        else
            fwrite(fid, dsize, 'uint32');           % DataByteSize (integer)
            if iscell(data{itc}{2})
                evalue = data{itc}{2}{its};
            else
                evalue = data{itc}{2}(its);
            end
            fwrite(fid, evalue, class(evalue));     % EventValue (integer)
        end
    end
end


num_data = num_ch;
