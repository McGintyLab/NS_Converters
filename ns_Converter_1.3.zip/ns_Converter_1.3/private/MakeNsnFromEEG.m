function result = MakeNsnFromEEG(EEG, filename)
% makes NSN format file from EEGLAB structure
% result = MakeNsnFromEEG(EEG, filename)
%
% Created  By: Satoshi MURATA (1),  satoshi-m@atr.jp  11/06/24
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Add path (if needed):
% ns_CreateFile
str = which('ns_CreateFile');
if isempty(str)
    dirname = uigetdir(pwd,'Select ''ns_CreateFile'' directory');
    if ~ischar(dirname)
        error('''ns_Create Library'' can''t find');
    end
    addpath(dirname);
end

% EEGLAB
str = which('eeglab');
if isempty(str)
    dirname = uigetdir(pwd, 'Select ''EEGLAB'' directory');
    if ~ischar(dirname)
        error('''EEGLAB'' can''t be found');
    end
    addpath(genpath(dirname));
end


%% Set pars:
num_ch = EEG.nbchan;


%% Create file:
[result nsObj] = ns_CreateFile(filename);
if result~=0,   return;     end


%% Set file-info
[result ns_FILEINFO]         = ns_GetFileInfo(nsObj);
if result~=0,   return;     end
ns_FILEINFO.szFileType       = EEG.setname;
ns_FILEINFO.szAppName        = 'ns_Converter';
date                         = clock;
ns_FILEINFO.dwTime_Year      = date(1);
ns_FILEINFO.dwTime_Month     = date(2);
ns_FILEINFO.dwTime_Day       = date(3);
ns_FILEINFO.dwTime_DayOfWeek = weekday(datenum(date(1),date(2),date(3))) -1; 
ns_FILEINFO.dwTime_Hour      = date(4);
ns_FILEINFO.dwTime_Min       = date(5);
ns_FILEINFO.dwTime_Sec       = round(date(6));
ns_FILEINFO.szFileComment    = EEG.comments;
[result nsObj]               = ns_SetFileInfo(nsObj, ns_FILEINFO);
if result~=0,   return;     end


%% Put data:
% data:
for itc=1:num_ch
    if isempty(EEG.chanlocs)
        [result, nsObj, DataID] = ns_NewAnalogData(nsObj);
    else
        [result, nsObj, DataID] = ns_NewAnalogData(nsObj, EEG.chanlocs(itc).labels);
    end
    if result~=0,   return;     end
    [result, nsANALOGINFO]   = ns_GetAnalogInfo(nsObj, DataID);
    if result~=0,   return;     end
    nsANALOGINFO.dSampleRate = EEG.srate;
    if ~isempty(EEG.chanlocs)
        nsANALOGINFO.szProbeInfo = EEG.chanlocs(itc).ref;
    end
    [result, nsObj]          = ns_SetAnalogInfo(nsObj, DataID, nsANALOGINFO);
    if result~=0,   return;     end
    [result, nsObj]          = ns_AddAnalogData(nsObj, DataID, EEG.xmin, double(EEG.data(itc,:)));
    if result~=0,   return;     end
end

% event:
[result, nsObj, EventID] = ns_NewEventData(nsObj, 'Event');
if result~=0,   return;     end
for ite=1:length(EEG.event)
    [result, nsObj] = ns_AddEventData(nsObj, EventID, EEG.event(ite).latency, EEG.event(ite).type);
    if result~=0,   return;     end
end


%% Close file:
result = ns_CloseFile(nsObj);
if result~=0,   return;     end

