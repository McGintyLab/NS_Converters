function result = ConvertFileWithDll(source_file, target_file, dll_file)
% makes NSN format file with DLL file
% result = ConvertFileWithDll(source_file, target_file, dll_file)
%
% Created  By: Keiji Harada (1),    kharada@atr.jp    10/06/24
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/11/19
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  11/03/03
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Add path (if need):
% Matlab-Import-Filter
str = which('ns_SetLibrary');
if isempty(str)
    str  = which(mfilename);
    path = fileparts(str);
    addpath(fullfile(path(1:end-8),'Matlab-Import-Filter_2_5'));
end

% DLLs
if ~exist('nsPlxLibrary.dll','file')
    str  = which(mfilename);
    path = fileparts(str);
    addpath(fullfile(path(1:end-8),'dll'));
end


%% Set DLL:
result =  ns_SetLibrary(which(dll_file));
if result~=0,   error('Can''t open or find DLL file:%s',dll_file);      end


%% Open file:
% data file:
[result, hFile] = ns_OpenFile(source_file);
if result~=0,   error('Can''t open data file:%s',source_file);        end

% Neuroshare file:
[result, nsObj] = ns_CreateFile(target_file);
if result~=0,   error('Can''t create Neuroshare file:%s',target_file);      end


%% Read FileInfo:
[result, ns_FILEINFO] = ns_GetFileInfo(hFile);
if result~=0,   error('Can''t read file info from data file');      end


%% Set FileInfo:
% get FileInfo:
[result, nsa_FILEINFO] = ns_GetFileInfo(nsObj);
if result~=0,   error('Can''t get file info from Neuroshare file');     end

% modify FileInfo:
nsa_FILEINFO.szFileType           = deblank(ns_FILEINFO.FileType);
nsa_FILEINFO.dTimeStampResolution = ns_FILEINFO.TimeStampResolution;
nsa_FILEINFO.dTimeSpan            = ns_FILEINFO.TimeSpan;
nsa_FILEINFO.szAppName            = deblank(ns_FILEINFO.AppName);
nsa_FILEINFO.dwTime_Year          = ns_FILEINFO.Time_Year;
nsa_FILEINFO.dwTime_Month         = ns_FILEINFO.Time_Month;
nsa_FILEINFO.dwTime_DayOfWeek     = weekday(datenum(ns_FILEINFO.Time_Year,ns_FILEINFO.Time_Month,ns_FILEINFO.Time_Day)) -1; 
nsa_FILEINFO.dwTime_Day           = ns_FILEINFO.Time_Day;
nsa_FILEINFO.dwTime_Hour          = ns_FILEINFO.Time_Hour;
nsa_FILEINFO.dwTime_Min           = ns_FILEINFO.Time_Min;
nsa_FILEINFO.dwTime_Sec           = ns_FILEINFO.Time_Sec;
nsa_FILEINFO.dwTime_MilliSec      = ns_FILEINFO.Time_MilliSec;
nsa_FILEINFO.szFileComment        = deblank(ns_FILEINFO.FileComment);

% add ATR mark:
if isempty(nsa_FILEINFO.szAppName)
    nsa_FILEINFO.szAppName = 'ns_Converter';
elseif isempty(nsa_FILEINFO.szFileComment)
    nsa_FILEINFO.szFileComment = 'edited by ATR';
elseif length(nsa_FILEINFO.szFileComment) <= 250
    nsa_FILEINFO.szFileComment = [nsa_FILEINFO.szFileComment ', ATR'];
else
    nsa_FILEINFO.szFileComment = [nsa_FILEINFO.szFileComment(1:250) ', ATR'];
end

% set FileInfo;
[result, nsObj] = ns_SetFileInfo(nsObj, nsa_FILEINFO);
if result~=0,   error('Can''t set file info in Neuroshare file');      end


%% Convert data:
% get EntityInfo:
[result, ns_ENTITYINFO] = ns_GetEntityInfo(hFile, 1:ns_FILEINFO.EntityCount);
if result~=0,   error('Can''t see the inside of data file');        end

% read and write data:
for ite=1:ns_FILEINFO.EntityCount
    switch ns_ENTITYINFO(ite).EntityType
        case 1      % Event entity
            % get EventInfo:
            [result, ns_EVENTINFO]  = ns_GetEventInfo(hFile, ite);
            if result~=0,   error('Can''t see the inside of data file');    end
            % set EventInfo:
            [result, nsObj, ID]     = ns_NewEventData(nsObj, ns_ENTITYINFO(ite).EntityLabel);
            if result~=0,   error('Can''t create new event entity');    end
            [result, nsa_EVENTINFO] = ns_GetEventInfo(nsObj, ID);
            if result~=0,   error('Can''t get event info from Neuroshare file');    end
            nsa_EVENTINFO.szCSVDesc = deblank(ns_EVENTINFO.CSVDesc);
            [result, nsObj]         = ns_SetEventInfo(nsObj, ID, nsa_EVENTINFO);
            if result~=0,   error('Can''t set event info in Neuroshare file');    end
            % get event data:
            if ns_ENTITYINFO(ite).ItemCount==0,     continue;       end
            [result, tstamp, val]   = ns_GetEventData(hFile, ite, 1:ns_ENTITYINFO(ite).ItemCount);
            if result~=0,   error('Can''t get event data from data file');      end
            % add event data:
            for itd=1:ns_ENTITYINFO(ite).ItemCount
                if iscell(val)
                    [result, nsObj] = ns_AddEventData(nsObj, ID, tstamp(itd), val{itd});
                else
                    [result, nsObj] = ns_AddEventData(nsObj, ID, tstamp(itd), val(itd));
                end
                if result~=0,   error('Can''t add event data to Neuroshare file');      end
            end
            % clear:
            clear ns_EVENTINFO nsa_EVENTINFO tstamp val;
            
        case 2      % Analog entity
            % get AnalogInfo:
            [result, ns_ANALOGINFO]  = ns_GetAnalogInfo(hFile, ite);
            if result~=0,   error('Can''t see the inside of data file');    end
            % set AnalogInfo:
            [result, nsObj, ID]      = ns_NewAnalogData(nsObj, ns_ENTITYINFO(ite).EntityLabel);
            if result~=0,   error('Can''t create new analog entity');    end
            [result, nsa_ANALOGINFO] = ns_GetAnalogInfo(nsObj, ID);
            if result~=0,   error('Can''t get analog info from Neuroshare file');    end
            nsa_ANALOGINFO.dSampleRate      = ns_ANALOGINFO.SampleRate;
            nsa_ANALOGINFO.dMinVal          = ns_ANALOGINFO.MinVal;
            nsa_ANALOGINFO.dMaxVal          = ns_ANALOGINFO.MaxVal;
            nsa_ANALOGINFO.szUnits          = deblank(ns_ANALOGINFO.Units);
            nsa_ANALOGINFO.dResolution      = ns_ANALOGINFO.Resolution;
            nsa_ANALOGINFO.dLocationX       = ns_ANALOGINFO.LocationX;
            nsa_ANALOGINFO.dLocationY       = ns_ANALOGINFO.LocationY;
            nsa_ANALOGINFO.dLocationZ       = ns_ANALOGINFO.LocationZ;
            nsa_ANALOGINFO.dLocationUser    = ns_ANALOGINFO.LocationUser;
            nsa_ANALOGINFO.dHighFreqCorner  = ns_ANALOGINFO.HighFreqCorner;
            nsa_ANALOGINFO.dwHighFreqOrder  = ns_ANALOGINFO.HighFreqOrder;
            nsa_ANALOGINFO.szHighFilterType = deblank(ns_ANALOGINFO.HighFilterType);
            nsa_ANALOGINFO.dLowFreqCorner   = ns_ANALOGINFO.LowFreqCorner;
            nsa_ANALOGINFO.dwLowFreqOrder   = ns_ANALOGINFO.LowFreqOrder;
            nsa_ANALOGINFO.szLowFilterType  = deblank(ns_ANALOGINFO.LowFilterType);
            nsa_ANALOGINFO.szProbeInfo      = deblank(ns_ANALOGINFO.ProbeInfo);
            [result, nsObj]          = ns_SetAnalogInfo(nsObj, ID, nsa_ANALOGINFO);
            if result~=0,   error('Can''t set analog info in Neuroshare file');    end
            % get analog data:
            if ns_ENTITYINFO(ite).ItemCount==0,     continue;       end
            [result, nouse, val]     = ns_GetAnalogData(hFile, ite, 1, ns_ENTITYINFO(ite).ItemCount);
            if result~=0,   error('Can''t get analog data from data file');    end
            % add analog data:
            [result, nsObj]          = ns_AddAnalogData(nsObj, ID, 0, val');
            if result~=0,   error('Can''t add analog data to Neuroshare file');     end
            % clear:
            clear ns_ANALOGINFO nsa_ANALOGINFO nouse val
            
        case 3      % Segment entity
            % get SegmentInfo:
            [result, ns_SEGMENTINFO]    = ns_GetSegmentInfo(hFile, ite);
            if result~=0,   error('Can''t see the inside of data file');    end
            % set SegmentInfo:
            [result, nsObj, ID]         = ns_NewSegmentData(nsObj, ns_ENTITYINFO(ite).EntityLabel);
            if result~=0,   error('Can''t create new segment entity');      end
            [result, nsa_SEGMENTINFO]   = ns_GetSegmentInfo(nsObj, ID);
            if result~=0,   error('Can''t get segment info from Neuroshare file');      end
            nsa_SEGMENTINFO.dSampleRate = ns_SEGMENTINFO.SampleRate;
            if isfield(ns_SEGMENTINFO, 'Units')
                nsa_SEGMENTINFO.szUnits = deblank(ns_SEGMENTINFO.Units);
            end
            [result, nsObj]             = ns_SetSegmentInfo(nsObj, ID, nsa_SEGMENTINFO);
            if result~=0,   error('Can''t set segment info in Neuroshare file');    end
            % get SegmentSourceInfo:
            [result, ns_SEGSOURCEINFO]  = ns_GetSegmentSourceInfo(hFile, ite, 1);
            if result~=0,   error('Can''t see the inside of data file');    end
            % set SegmentSourceInfo:
            [result, nsa_SEGSOURCEINFO] = ns_GetSegmentSourceInfo(nsObj, ID, 1);
            if result~=0,   error('Can''t get segment source info from Neuroshare file');      end
            nsa_SEGSOURCEINFO.dMinVal          = ns_SEGSOURCEINFO.MinVal;
            nsa_SEGSOURCEINFO.dMaxVal          = ns_SEGSOURCEINFO.MaxVal;
            nsa_SEGSOURCEINFO.dResolution      = ns_SEGSOURCEINFO.Resolution;
            nsa_SEGSOURCEINFO.dSubSampleShift  = ns_SEGSOURCEINFO.SubSampleShift;
            nsa_SEGSOURCEINFO.dLocationX       = ns_SEGSOURCEINFO.LocationX;
            nsa_SEGSOURCEINFO.dLocationY       = ns_SEGSOURCEINFO.LocationY;
            nsa_SEGSOURCEINFO.dLocationZ       = ns_SEGSOURCEINFO.LocationZ;
            nsa_SEGSOURCEINFO.dLocationUser    = ns_SEGSOURCEINFO.LocationUser;
            nsa_SEGSOURCEINFO.dHighFreqCorner  = ns_SEGSOURCEINFO.HighFreqCorner;
            nsa_SEGSOURCEINFO.dwHighFreqOrder  = ns_SEGSOURCEINFO.HighFreqOrder;
            nsa_SEGSOURCEINFO.szHighFilterType = deblank(ns_SEGSOURCEINFO.HighFilterType);
            nsa_SEGSOURCEINFO.dLowFreqCorner   = ns_SEGSOURCEINFO.LowFreqCorner;
            nsa_SEGSOURCEINFO.dwLowFreqOrder   = ns_SEGSOURCEINFO.LowFreqOrder;
            nsa_SEGSOURCEINFO.szLowFilterType  = deblank(ns_SEGSOURCEINFO.LowFilterType);
            nsa_SEGSOURCEINFO.szProbeInfo      = deblank(ns_SEGSOURCEINFO.ProbeInfo);
            for itd=1:ns_ENTITYINFO(ite).ItemCount
                % get segment data:
                [result, tstamp, val, sc, uid] = ns_GetSegmentData(hFile, ite, itd);
                if result~=0,   error('Can''t get segment data from data file');    end
                % add segment data:
                [result, nsObj]                = ns_AddSegmentData(nsObj, ID, tstamp, uid, val(1:sc));
                if result~=0,   error('Can''t add segment data to Neuroshare file');     end
            end
            % clear:
            clear ns_SEGMENTINFO nsa_SEGMENTINFO ns_SEGSOURCEINFO nsa_SEGSOURCEINFO tstamp val sc uid
            
        case 4      % Neural Event entity
            % get NeuralInfo:
            [result, ns_NEURALINFO]  = ns_GetNeuralInfo(hFile, ite);
            if result~=0,   error('Can''t see the inside of data file');    end
            % set NeuralInfo:
            [result, nsObj, ID]      = ns_NewNeuralEventData(nsObj, ns_ENTITYINFO(ite).EntityLabel);
            if result~=0,   error('Can''t create new neural entity');       end
            [result, nsa_NEURALINFO] = ns_GetNeuralInfo(nsObj, ID);
            if result~=0,   error('Can''t get neural info from Neuroshare file');   end
            nsa_NEURALINFO.dwSourceEntityID = ns_NEURALINFO.SourceEntityID;
            nsa_NEURALINFO.dwSourceUnitID   = ns_NEURALINFO.SourceUnitID;
            nsa_NEURALINFO.szProbeInfo      = ns_NEURALINFO.ProbeInfo;
            [result, nsObj]          = ns_SetNeuralInfo(nsObj, ID, nsa_NEURALINFO);
            if result~=0,   error('Can''t set neural info in Neuroshare file');     end
            % get neural data:
            if ns_ENTITYINFO(ite).ItemCount==0,     continue;       end
            [result, val]            = ns_GetNeuralData(hFile, ite, 1, ns_ENTITYINFO(ite).ItemCount);
            if result~=0,   error('Can''t get neural data from data file');     end
            % add neural data:
            for itd=1:ns_ENTITYINFO(ite).ItemCount
                [result, nsObj] = ns_AddNeuralEventData(nsObj, ID, val(itd));
                if result~=0,   error('Can''t add neural data to Neuroshare file');     end
            end
            % clear:
            clear ns_NEURALINFO nsa_NEURALINFO val
        otherwise
            fprintf('Unknown\n');
    end
end


%% Close file:
% data file:
result = ns_CloseFile(hFile);
if result~=0,   error('Can''t close data file');        end

% Neuroshare file:
result = ns_CloseFile(nsObj);
if result~=0,   error('Can''t close Neuroshare file');      end


