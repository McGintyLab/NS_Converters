function num_data = AddAnalogData(fid, data, samp_rate, ch_name)
% add Analog data into preexisted nsn file
%
% Created  By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/04/19
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Calculate length in bytes of the following data:
[num_samp, num_ch] = size(data);
elength            = 32+4*2 + 8*10+16*3+4*2+128 + 8+4+8*num_samp;


%% Make EntityLabel:
elabel = [ch_name{1} blanks(32)];
elabel = elabel(1:32);


%% Write header and data:
for itc=1:num_ch
    % write ns_TAGELEMENT:
    fwrite(fid, 2, 'uint32');           % ElemType (Analog = 2)
    fwrite(fid, elength, 'uint32');     % ElemLength
    
    % write ns_ENTITYINFO:
    fwrite(fid, elabel);                % EntityLabel
    fwrite(fid, 2, 'uint32');           % EntityType
    fwrite(fid, num_samp, 'uint32');    % ItemCount
    
    % write ns_ANALOGINFO:
    fwrite(fid, samp_rate(itc), 'double');      % SampleRate
    fwrite(fid, min(data(:,itc)), 'double');    % MinVal
    fwrite(fid, max(data(:,itc)), 'double');    % MaxVal
    fwrite(fid, blanks(16));                    % Units
    fwrite(fid, 0, 'double');                   % Resolution
    fwrite(fid, 0, 'double');                   % LocationX
    fwrite(fid, 0, 'double');                   % LocationY
    fwrite(fid, 0, 'double');                   % LocationZ
    fwrite(fid, 0, 'double');                   % LocationUser
    fwrite(fid, 0, 'double');                   % HighFreqCorner
    fwrite(fid, 0, 'uint32');                   % HighFreqOrder
    fwrite(fid, blanks(16));                    % HighFilterType
    fwrite(fid, 0, 'double');                   % LowFreqCorner
    fwrite(fid, 0, 'uint32');                   % LowFreqOrder
    fwrite(fid, blanks(16));                    % LowFilterType
    probeinf = [ch_name{itc+1} blanks(128)];
    fwrite(fid, probeinf(1:128));               % ProbeInfo
    
    % write data:
    fwrite(fid, 0, 'double');               % Timestamp
    fwrite(fid, num_samp, 'uint32');        % DataCount
    fwrite(fid, data(:,itc), 'double');     % AnalogValue
end

num_data = num_ch;
