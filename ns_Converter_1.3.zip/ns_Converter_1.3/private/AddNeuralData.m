function num_data = AddNeuralData(fid, data, ch_name)
% add Neural event data into preexisted nsn file
%
% Created  By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/04/19
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Calculate length in bytes of the following data:
elength = 32+4*2 + 4*2+128;


%% Make EntityLabel:
elabel = [ch_name{1} blanks(32)];
elabel = elabel(1:32);


%% Write header and data:
num_ch = length(data);
for itc=1:num_ch
    num_samp = length(data{itc});
    
    % write ns_TAGELEMENT:
    fwrite(fid, 4, 'uint32');                   % ElemType (NeuralEvent = 4)
    fwrite(fid, elength+8*num_samp, 'uint32');  % ElemLength
    
    % write ns_ENTITYINFO:
    fwrite(fid, elabel);                % EntityLabel
    fwrite(fid, 4, 'uint32');           % EntityType
    fwrite(fid, num_samp, 'uint32');    % ItemCount
    
    % write ns_NEURALINFO:
    fwrite(fid, 0, 'uint32');           % SourceEntityID
    fwrite(fid, 0, 'uint32');           % SourceUnitID
    probeinf = [ch_name{itc+1} blanks(128)];
    fwrite(fid, probeinf(1:128));       % ProbeInfo
    
    % write data:
    fwrite(fid, data{itc}, 'double');   % Timestamp
end

num_data = num_ch;
