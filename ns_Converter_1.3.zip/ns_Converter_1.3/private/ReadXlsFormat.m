function [data, samp_rate, ch_name, ch_desc, date, file_type, file_desc] = ReadXlsFormat(xls_filename)
% reads XLS-format file, and makes input-args of SimpleConverter
% [data, samp_rate, ch_name] = ReadXlsFormat(xls_filename)
%
% Input:
%   xls_filename - XLS filename; if absent, you should put by dialog
%
% Output:
%   data      - brain activity and behavioral data, {[time x space], ...}
%   samp_rate - sampring rate, [1 x channel]
%   ch_name   - channel name, {1 x channel}
%   ch_desc   - description of each channel, {1 x channel}
%   date      - date of experiment, [yyyy, mm, dd, HH, MM, SS]
%   file_type - explanation of this file/experiment
%   file_desc - comment of this file/experiment
%
% Created  By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/01/13
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/03/01
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  11/03/30
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Check args:
if ~exist('xls_filename','var') || isempty(xls_filename)
    [file, path] = uigetfile({'*.xls','Microsoft Office Excel Book (*.xls)'}, 'Select XLS file');
    if isnumeric(file) && file==0
        error('XLS filename should be specified');
    end
    xls_filename = fullfile(path, file);
end


%% Read file:
msgh = msgbox({'Read xls file in dialog';'Select each data from xls file'},'NOTICE');
uiwait(msgh);

try
    % date:
    msgh     = msgbox('Select ''DATE''','Date');
    uiwait(msgh);
    date     = readStrFromXls(xls_filename, 'DATE');
    if isempty(date)
        warning('''DATE'' isn''t specified, use NOW');
            date   = clock;
    else
        date = textscan(date, '%f/%f/%f %f:%f:%f');
        if ~isempty(find(cellfun(@isempty,date),1))
            error('format of ''DATE'' is wrong');
        end
        date = cell2mat(date);
    end
    
    % file_type:
    msgh      = msgbox('Select ''TITLE of Experiment''','Title');
    uiwait(msgh);
    file_type = readStrFromXls(xls_filename, 'TITLE');
    
    % file_comment:
    msgh      = msgbox('Select ''DESCRIPTION of Experiment''','Description');
    uiwait(msgh);
    file_desc = readStrFromXls(xls_filename, 'DESCRIPTION');
    
    % ch_name:
    msgh    = msgbox('Select ''CHANNEL NAME''','Channel Name');
    uiwait(msgh);
    ch_name = readCellStrFromXls(xls_filename, 'CHANNEL NAME');
    
    % ch_desc:
    msgh    = msgbox('Select ''CHANNEL SUPPL''','Channel Suppl');
    uiwait(msgh);
    ch_desc = readCellStrFromXls(xls_filename, 'CHANNEL SUPPL');
    
    
    % sampling_rate:
    msgh              = msgbox('Select ''SAMPLING RATE''','Sampling Rate');
    uiwait(msgh);
    [nouse, txt, raw] = xlsread(xls_filename, -1);
    if ~isempty(txt)
        if find(ismember(lower(txt),'nan')==0,1)
            error('''SAMPLING RATE'' should be number');
        end
    end
    if iscell(raw),     samp_rate = cell2mat(raw);
    else               samp_rate = raw;                end
    
    % data:
    msgh                = msgbox('Select ''DATA''','Data');
    uiwait(msgh);
    [nouse, nouse, raw] = xlsread(xls_filename, -1);
    data                = cell(1,size(raw,2));
    for itc=1:size(raw,2)
        data{1,itc}     = deleteExtraNan(raw(:,itc));
    end
    
catch ME
    ExceptionDisp(ME);
    rethrow(ME);
end


%% Arrange data:
num_ch = length(data);

% data:
for itc=1:num_ch
    if isempty(data{itc})
        data{itc} = [];
    elseif ~iscellstr(data{itc})
        data{itc} = cell2mat(data{itc});
    end
end

% file_type:
if isempty(file_type)
    [nouse, filename] = fileparts(xls_filename);
    file_type         = filename;
end

% ch_name:
if isempty(ch_name)
    ch_name  = [repmat('ch',num_ch,1) num2str((1:num_ch)')];
    ch_name  = mat2cell(ch_name,ones(num_ch,1),size(ch_name,2))';
elseif numel(ch_name)~=num_ch
    num_name = numel(ch_name);
    temp     = [repmat('ch',num_ch-num_name,1) num2str((num_name+1:num_ch)')];
    temp     = mat2cell(temp,ones(num_ch-num_name,1),size(temp,2));
    ch_name  = [ch_name temp'];
end
for itc=1:numel(ch_name)
    if isempty(ch_name{itc})
        ch_name{itc} = ['ch' num2str(itc)];
    end
end

% ch_desc:
if isempty(ch_desc)
    ch_desc = repmat(cellstr(''),1,num_ch);
elseif numel(ch_desc)~=num_ch
    ch_desc(end+1:num_ch) = cellstr('');
end

% samp_rate:
if numel(samp_rate)~=num_ch
    samp_rate(end+1:num_ch) = NaN;
end

% timestamp+event (event), value+id (segment):
is_event   = zeros(size(ch_name));
is_segment = zeros(size(ch_name));
for itc=2:length(ch_name)
    if strcmp(ch_name{itc}(1),'#') && strcmpi(ch_name{itc}(2:end),ch_name{itc-1})
        is_event(itc) = 1;
    elseif strcmp(ch_name{itc}(1),'%') && strcmpi(ch_name{itc}(2:end),ch_name{itc-1})
        is_segment(itc) = 1;
    end
end
ind = find(is_event | is_segment);
if ~isempty(ind)
    for iti=1:length(ind)
        data{ind(iti)-1} = {data{ind(iti)-1} data{ind(iti)}};
    end
    data(ind)      = [];
    ch_name(ind)   = [];
    ch_desc(ind)   = [];
    samp_rate(ind) = [];
end





%% ---------------------------------------------------------------------------------------
function str = readStrFromXls(xls_filename, str_name)
% read string from XLS file

[numeric, txt] = xlsread(xls_filename, -1);
if isempty(txt)
    if ~isempty(numeric)
        error(['''' str_name ''' should be text']);
    else
        str = '';
    end
elseif numel(txt)~=1
    error('select only 1 cell');
else
    str = txt{1};
end



%% ---------------------------------------------------------------------------------------
function str = readCellStrFromXls(xls_filename, str_name)
% read strings in cell from XLS file

[numeric, txt] = xlsread(xls_filename, -1);
if isempty(txt)
    if ~isempty(numeric)
        error(['''' str_name ''' should be text']);
    else
        str = '';
    end
else
    str = txt;
end



%% ----------------------------------------------------------------------------
function data = deleteExtraNan(data)
% delete extra 'NaN' from data

if isempty(data)
    data      = {};
elseif isnan(data{end})
    data(end) = [];
    data      = deleteExtraNan(data);
end
