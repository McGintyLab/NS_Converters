function [csv_file, xls_file, nsn_file] = SeparateFiles(files)
% returns filename of each file type
%
% Created  By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/04/20
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


num_files = length(files);
csv_file  = cell(num_files,1);
xls_file  = cell(num_files,1);
nsn_file  = cell(num_files,1);

for itf=1:num_files
    [path, file, ext] = fileparts(files{itf});
    switch ext
        case '.csv'
            csv_file{itf} = fullfile(path, [file ext]);
        case '.xls'
            xls_file{itf} = fullfile(path, [file ext]);
        case '.nsn'
            nsn_file{itf} = fullfile(path, [file ext]);
        otherwise
            error('file: %s isn''t usable type', [file ext]);
    end
end

ind           = cellfun('isempty',csv_file);
csv_file(ind) = [];
ind           = cellfun('isempty',xls_file);
xls_file(ind) = [];
ind           = cellfun('isempty',nsn_file);
nsn_file(ind) = [];
