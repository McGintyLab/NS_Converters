function [data, samp_rate, ch_name, ch_desc, date, file_type, file_desc] = ReadCsvFormat(csv_filename)
% reads CSV-format file, and makes input-args of SimpleConverter
% [data, samp_rate, ch_name, ch_desc, date, file_type, file_desc] = ReadCsvFormat(csv_filename)
%
% Input:
%   csv_filename - CSV filename; if absent, you should put by dialog
%
% Output:
%   data      - brain activity and behavioral data, {[time x space], ...}
%   samp_rate - sampring rate, [1 x channel]
%   ch_name   - channel name, {1 x channel}
%   ch_desc   - description of each channel, {1 x channel}
%   date      - date of experiment, [yyyy, mm, dd, HH, MM, SS]
%   file_type - explanation of this file/experiment
%   file_desc - comment of this file/experiment
%
% Created  By: Satoshi MURATA (1),  satoshi-m@atr.jp  09/12/18
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/03/01
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  11/03/25
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Check arg:
if ~exist('csv_filename','var') || isempty(csv_filename)
    [file, path] = uigetfile({'*.csv','CSV (Comma Separated Values) (*.csv)'}, 'Select CSV file');
    if isnumeric(file) && file==0
        error('CSV filename should be specified');
    end
    csv_filename = fullfile(path, file);
end


%% Read file:
fp = fopen(csv_filename);

% date:
temp = separateData(fgetl(fp));
if length(temp)>1
    error('CSV Format ERROR: 1st row must contain only ''date''');
end
date = temp{1};

% explanation, comment:
temp = separateData(fgetl(fp));
if length(temp)>2
    error('CSV Format ERROR: 2nd row must contain only ''file_type'' and ''file_description''');
elseif length(temp)<2
    file_desc = '';
else
    file_desc = temp{2};
end
file_type = temp{1};

% ch_inf:
ch_name   = separateData(fgetl(fp));
ch_desc   = separateData(fgetl(fp));

% samp_rate:
samp_rate = str2double(separateData(fgetl(fp)));

% data:
data = {};
while 1
    temp = fgetl(fp);
    if isequal(temp,-1),    break;      end
    temp = separateData(temp);
    data(size(data,1)+1,1:length(temp)) = temp;
end
fclose(fp);
temp = cell(1,size(data,2));
for itc=1:length(temp)
    temp{itc} = data(:,itc);
end
data = temp;
data = cellfun(@deleteExtraEmpty,data,'UniformOutput',0);


%% Arrange data:
num_ch = size(data,2);

% data:
for itc=1:num_ch
    if isempty(data{itc})
        data{itc} = [];
    else
        temp = str2num(strvcat(data{itc}{:}));
        if ~isempty(temp)
            data{itc} = temp;
        end
    end
end

% date:
if isempty(date)
    date = fix(clock);
else
    date = textscan(date, '%f/%f/%f %f:%f:%f');
    if ~isempty(find(cellfun(@isempty,date),1))
        error('format of ''date'' is wrong');
    end
    date = cell2mat(date);
end

% explanation:
if isempty(file_type)
    [nouse, filename] = fileparts(csv_filename);
    file_type         = filename;
end

% ch_name:
if isempty(ch_name)
    ch_name  = [repmat('ch',num_ch,1) num2str((1:num_ch)')];
    ch_name  = mat2cell(ch_name,ones(num_ch,1),size(ch_name,2))';
elseif length(ch_name)~=num_ch
    num_name = length(ch_name);
    temp     = [repmat('ch',num_ch-num_name,1) num2str((num_name+1:num_ch)')];
    temp     = mat2cell(temp,ones(num_ch-num_name,1),size(temp,2));
    ch_name  = [ch_name temp'];
end
for itc=1:length(ch_name)
    if isempty(ch_name{itc})
        ch_name{itc} = ['ch' num2str(itc)];
    end
end

% ch_desc:
if isempty(ch_desc)
    ch_desc = repmat(cellstr(''),1,num_ch);
elseif length(ch_desc)~=num_ch
    ch_desc(end+1:num_ch) = cellstr('');
end

% samp_rate:
if length(samp_rate)~=num_ch
    samp_rate(end+1:num_ch) = NaN;
end

% timestamp+event (event), value+id (segment):
is_event   = zeros(size(ch_name));
is_segment = zeros(size(ch_name));
for itc=2:length(ch_name)
    if strcmp(ch_name{itc}(1),'#') && strcmpi(ch_name{itc}(2:end),ch_name{itc-1})
        is_event(itc) = 1;
    elseif strcmp(ch_name{itc}(1),'%') && strcmpi(ch_name{itc}(2:end),ch_name{itc-1})
        is_segment(itc) = 1;
    end
end
ind = find(is_event | is_segment);
if ~isempty(ind)
    for iti=1:length(ind)
        data{ind(iti)-1} = {data{ind(iti)-1} data{ind(iti)}};
    end
    data(ind)      = [];
    ch_name(ind)   = [];
    ch_desc(ind)   = [];
    samp_rate(ind) = [];
end





%% ----------------------------------------------------------------------------
function sep_data = separateData(data, dlm)
% separates data by dlm

if isempty(data)
    sep_data = {};
    return;
end

if ~exist('dlm','var') || isempty(dlm)
    dlm = ',';
end

data = deleteExtraDelimiter(data, dlm);

ind_dq = strfind(data,'"');
ind    = strfind(data,dlm);

if ~isempty(ind_dq)
    for itd=1:length(ind_dq)/2
        ind((ind_dq((itd-1)*2+1)<ind)&(ind<(ind_dq(itd*2)))) = [];
    end
end

num      = length(ind)+1;
ind      = [0 ind length(data)+1];
sep_data = cell(1,num);

for itd=1:num
    sep_data{itd} = deleteDoubleQuotation(data(ind(itd)+1:ind(itd+1)-1));
end



%% ----------------------------------------------------------------------------
function str = deleteDoubleQuotation(str)
% delete '"' in str

ind      = strfind(str,'"');
str(ind) = [];



%% ----------------------------------------------------------------------------
function str = deleteExtraDelimiter(str, dlm)
% delete extra dlm in str

if ~exist('dlm','var') || isempty(dlm)
    dlm = ',';
end

if isempty(str)
    str = '';
elseif strcmp(str(end),dlm)
    str = str(1:end-1);
    str = deleteExtraDelimiter(str,dlm);
end



%% ----------------------------------------------------------------------------
function data = deleteExtraZero(data)
% delete extra '0'

if isempty(data)
    data = [];
elseif isequal(data(end),0)
    data(end) = [];
    data      = deleteExtraZero(data);
end



%% ----------------------------------------------------------------------------
function data = deleteExtraEmpty(data)
% delete extra empty

if isempty(data)
    data = '';
elseif (iscell(data(end)) && isempty(data{end})) || isempty(data(end))
    data(end) = [];
    data      = deleteExtraEmpty(data);
end
