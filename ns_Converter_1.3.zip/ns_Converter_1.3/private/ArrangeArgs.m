function [data, samp_rate, ch_name, date] = ArrangeArgs(data, samp_rate, ch_name, date)
% arrange input args of ns_Converter
%
% Created  By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/04/19
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


num_cell = length(data);

%% Data:


%% Sampling rate:
for itc=1:num_cell
    if isempty(samp_rate{itc}) || length(samp_rate{itc})==1
        samp_rate{itc} = repmat(samp_rate{itc},1,size(data{itc},2));
    elseif length(samp_rate{itc})~=size(data{itc},2)
        error('number of channel in ''data{%d}'' and length of ''samp_rate{%d}'' are different', itc, itc);
    end
end


%% Channel name:
for itc=1:num_cell
    if ~iscell(ch_name{itc})
        ch_name{itc} = ch_name(itc);
    end
    if length(ch_name{itc})==1      % only equipment name
        num_ch       = size(data{itc},2);
        temp         = [repmat('ch',num_ch,1) num2str((1:num_ch)')];
        temp         = mat2cell(temp,ones(num_ch,1),size(temp,2));
        ch_name{itc} = [ch_name{itc}, temp'];
    elseif length(ch_name{itc})==size(data{itc},2)      % only channel name
        ch_name{itc} = [{['measure' num2str(itc)]}, ch_name{itc}];
    elseif length(ch_name{itc})~=size(data{itc},2)+1    % error
        error('number of channel in ''data{%d}'' and length of ''ch_name{%d}'' are different', itc, itc);
    end
end


%% Date:

