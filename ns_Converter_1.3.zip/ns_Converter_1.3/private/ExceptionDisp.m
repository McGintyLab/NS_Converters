function ExceptionDisp(mException)
% exceptionDisp - Display Exception Messages.
% exceptionDisp( mException )
%
% Inputs:
%   mException      - [struct] - MException object includes information of Exception.
% 
% Outputs:
%   Nothing.
%
% Created  By: Keiji HARADA (1),    kharada@atr.jp    10/06/25
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/06/25 
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  11/03/03
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

%   Show Exception Message.
disp(mException.message);

%   Show File Links.
%   exam. : :::[ NeuroshareConverter at 126 ]:::
for ii=1:length(mException.stack)
    [nouse, filename] = fileparts(mException.stack(ii).file);
%     fileLinkPre = strcat('<a href="matlab:edit');
%     fileLinkAft = strcat(filename,ext,'">',filename,'</a>');
%     disp([':::[' blanks(1) fileLinkPre blanks(1) fileLinkAft  blanks(1) 'at' blanks(1) num2str(mException.stack(ii).line) blanks(1) ']:::']);

disp([':::[ <a href="matlab:opentoline(''' mException.stack(ii).file ''',' num2str(mException.stack(ii).line) ')">' filename ' at ' num2str(mException.stack(ii).line) '</a> ]:::']);
end