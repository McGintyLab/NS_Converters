function result = MakeNsnFile(data, samp_rate, ch_name, ch_desc, date, file_type, file_desc, filename)
% makes NSN format file
% result = MakeNsnFile(data, samp_rate, ch_name, ch_desc, date, file_type, file_desc, filename)
%
% Created  By: Satoshi MURATA (1),  satoshi-m@atr.jp  09/12/22
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/03/01
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/04/12
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  11/03/25
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Add path (if needed):
str = which('ns_CreateFile');
if isempty(str)
    dirname = uigetdir(pwd,'Select ''ns_CreateFile'' directory');
    if ~ischar(dirname)
        error('''ns_Create Library'' can''t find');
    end
    addpath(dirname);
end


%% Set pars:
num_ch = length(data);


%% Create file:
[result nsObj] = ns_CreateFile(filename);
if result~=0,   return;     end


%% Set file-info
[result ns_FILEINFO]         = ns_GetFileInfo(nsObj);
if result~=0,   return;     end
ns_FILEINFO.szFileType       = file_type;
ns_FILEINFO.szAppName        = 'ns_Converter';
ns_FILEINFO.dwTime_Year      = date(1);
ns_FILEINFO.dwTime_Month     = date(2);
ns_FILEINFO.dwTime_Day       = date(3);
ns_FILEINFO.dwTime_DayOfWeek = weekday(datenum(date(1),date(2),date(3))) -1; 
ns_FILEINFO.dwTime_Hour      = date(4);
ns_FILEINFO.dwTime_Min       = date(5);
ns_FILEINFO.dwTime_Sec       = date(6);
ns_FILEINFO.szFileComment    = file_desc;
[result nsObj]               = ns_SetFileInfo(nsObj, ns_FILEINFO);
if result~=0,   return;     end

%% Put data:
for itc=1:num_ch
    if isnan(samp_rate(itc))
        if iscell(data{itc})    % Event data
            [result, nsObj, DataID]  = ns_NewEventData(nsObj, ch_name{itc});
            if result~=0,   return;     end
            [result, nsEVENTINFO]    = ns_GetEventInfo(nsObj, DataID);
            if result~=0,   return;     end
            nsEVENTINFO.szCSVDesc    = ch_desc{itc};
            [result, nsObj]          = ns_SetEventInfo(nsObj, DataID, nsEVENTINFO);
            if result~=0,   return;     end
            for itt=1:length(data{itc}{1})
                time = data{itc}{1}(itt);
                if iscell(data{itc}{2})
                    event = data{itc}{2}{itt};
                else
                    event = data{itc}{2}(itt);
                end
                [result, nsObj]      = ns_AddEventData(nsObj, DataID, time, event);
            end
            
        else                    % Time Stamp data
            [result, nsObj, DataID]  = ns_NewNeuralEventData(nsObj, ch_name{itc});
            if result~=0,   return;     end
            [result, nsNEURALINFO]   = ns_GetNeuralInfo(nsObj, DataID);
            if result~=0,   return;     end
            nsNEURALINFO.szProbeInfo = ch_desc{itc};
            [result, nsObj]          = ns_SetNeuralInfo(nsObj, DataID, nsNEURALINFO);
            if result~=0,   return;     end
            for itt=1:length(data{itc})
                [result, nsObj]      = ns_AddNeuralEventData(nsObj, DataID, data{itc}(itt));
                if result~=0,   return;     end
            end
        end
        
    else
        if iscell(data{itc})    % Timeseries data with ID
            [result, nsObj, DataID]     = ns_NewSegmentData(nsObj, ch_name{itc});
            if result~=0,   return;     end
            [result, nsSEGMENTINFO]     = ns_GetSegmentInfo(nsObj, DataID);
            nsSEGMENTINFO.dSampleRate   = samp_rate(itc);
            ind_s                       = strfind(ch_desc{itc},'[');
            if ~isempty(ind_s)
                ind_e                   = strfind(ch_desc{itc},']');
                nsSEGMENTINFO.szUnits   = ch_desc{itc}(ind_s(1)+1:ind_e(1)-1);
            end
            [result, nsObj]             = ns_SetSegmentInfo(nsObj, DataID, nsSEGMENTINFO);
            if result~=0,   return;     end
            [result, nsSEGSOURCEINFO]   = ns_GetSegmentSourceInfo(nsObj, DataID, 1);
            if result~=0,   return;     end
            nsSEGSOURCEINFO.szProbeInfo = ch_desc{itc};
            ind_s                       = strfind(ch_desc{itc},'(');
            if ~isempty(ind_s)
                ind_e                   = strfind(ch_desc{itc},')');
                temp                    = ch_desc{itc}(ind_s(1)+1:ind_e(1)-1);
                ind                     = strfind(temp,',');
                if length(ind)==2
                    nsSEGSOURCEINFO.dLocationX = str2double(temp(1:ind(1)-1));
                    nsSEGSOURCEINFO.dLocationY = str2double(temp(ind(1)+1:ind(2)-1));
                    nsSEGSOURCEINFO.dLocationZ = str2double(temp(ind(2)+1:end));
                end
            end
            [result, nsObj]             = ns_SetSegmentSourceInfo(nsObj, DataID, 1, nsSEGSOURCEINFO);
            if result~=0,   return;     end
            
            ind   = find(diff(data{itc}{2}))';
            ind_s = [1 ind+1];
            ind_s(isnan(data{itc}{2}(ind_s))) = [];
            ind_e = [ind length(data{itc}{2})];
            ind_e(isnan(data{itc}{2}(ind_e))) = [];
            for itd=1:length(ind_s)
                [result, nsObj] = ns_AddSegmentData(nsObj, DataID, (ind_s(itd)-1)/samp_rate(itc), data{itc}{2}(ind_s(itd)), data{itc}{1}(ind_s(itd):ind_e(itd))');
            end
            
        else                    % Timeseries data only
            [result, nsObj, DataID]  = ns_NewAnalogData(nsObj, ch_name{itc});
            if result~=0,   return;     end
            [result, nsANALOGINFO]   = ns_GetAnalogInfo(nsObj, DataID);
            if result~=0,   return;     end
            nsANALOGINFO.dSampleRate = samp_rate(itc);
            nsANALOGINFO.szProbeInfo = ch_desc{itc};
            ind_s                    = strfind(ch_desc{itc},'[');
            if ~isempty(ind_s)
                ind_e                = strfind(ch_desc{itc},']');
                nsANALOGINFO.szUnits = ch_desc{itc}(ind_s(1)+1:ind_e(1)-1);
            end
            ind_s                    = strfind(ch_desc{itc},'(');
            if ~isempty(ind_s)
                ind_e                = strfind(ch_desc{itc},')');
                temp                 = ch_desc{itc}(ind_s(1)+1:ind_e(1)-1);
                ind                  = strfind(temp,',');
                if length(ind)==2
                    nsANALOGINFO.dLocationX = str2double(temp(1:ind(1)-1));
                    nsANALOGINFO.dLocationY = str2double(temp(ind(1)+1:ind(2)-1));
                    nsANALOGINFO.dLocationZ = str2double(temp(ind(2)+1:end));
                end
            end
            [result, nsObj]          = ns_SetAnalogInfo(nsObj, DataID, nsANALOGINFO);
            if result~=0,   return;     end
            [result, nsObj]          = ns_AddAnalogData(nsObj, DataID, 0, data{itc}');
            if result~=0,   return;     end
        end
    end
end


%% Close file:
result = ns_CloseFile(nsObj);
if result~=0,   return;     end


