function Result = NeuroshareConverter(inputFileName, outputFileName)
% NeuroshareConverter - Create a Neuroshare file.
% NeuroshareConverter(inputFileName, outputFileName)
%
% Inputs:
%   inputFileName   - [char] - input file name with full path.(exam. C:\temp\input\test.plx)
%   outputFileName  - [char] - output file name with full path.(exam. C:\temp\output\test.nsn)
% 
% Outputs:
%   Result          - [double] - COMPLETE or ERROR value. 0 : COMPLETE -1 : ERROR
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    2010/06/14
% Modified By: Keiji HARADA (1),    kharada@atr.jp    2010/06/25
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  2010/10/06
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

%disp(':::NEUROSHARE CONVERTER:::');

%   Global variable.
global Data;

% Add path (if need):
% Matlab-Import-Filter
str = which('ns_SetLibrary');
if isempty(str)
    str  = which(mfilename);
    path = fileparts(str);
    addpath(fullfile(path(1:end-8),'Matlab-Import-Filter_2_5'));
end

% DLLs
if ~exist('nsPlxLibrary.dll','file')
    str  = which(mfilename);
    path = fileparts(str);
    addpath(fullfile(path(1:end-8),'dll'));
end

% ns_CreateFile library
str = which('ns_CreateFile');
if isempty(str)
    dirname = uigetdir(pwd,'Select ''ns_CreateFile'' directory');
    if ~ischar(dirname)
        error('''ns_Create Library'' can''t find');
    end
    addpath(dirname);
end


Result = 0;
try

    %   Check file existence.
    %   Output file.
    %   Delete the Neuroshare file if it exists already.
    if 0 ~= exist(outputFileName,'file');
        %   Delete it.
        delete(outputFileName);
        %warning('System deletes the Neuroshare file which exists already.');
    end

    %   Check file existence.
    %   Input file.
    %   Check existing of the data file.
    if 0 == exist(inputFileName,'file');
        %   No existing error.
        error('Can not find the data file.');
    end

    %   Check file extension.
    %   Output file.
    %   Get output file extension.
    [outDir, outFileName, outExtension, outVersn] = fileparts(outputFileName);

    %   Check file extension.
    if 1 == strcmp(outExtension,'');
        %   null, then add '.nsn'.
        outputFileName = strcat(outputFileName,'.nsn');
        [outDir, outFileName, outExtension, outVersn] = fileparts(outputFileName);
    end
    if 1 ~= strcmp(outExtension,'.nsn');
        %   Wrong extension error.
        error('Can not set extension of the output file other than .nsn.');
    end

    %   Check file extension.
    %   Input file.
    %   Get input file extension.(for choosing sequence below.)
    [inDir, inFileName, inExtension, inVersn] = fileparts(inputFileName);

    %   Not needed.
    clear outFileName outVersn;
    clear inFileName inVersn;

    %   Choose sequence.
    %   .map : OK    : Choose nsAOLibrary.dll as Neuroshare DLL file.
    %   .plx : OK    : Choose nsPlxLibrary.dll as Neuroshare DLL file.
    %   .mcd : OK    : Choose nsMCDLibrary.dll as Neuroshare DLL file.
    %   .nex : OK    : Choose NeuroExplorerNeuroShareLibrary.dll as Neuroshare DLL file.
    %   .stb : OK    : Choose nsTDTLib.dll as Neuroshare DLL file.
    %   .nev : OK    : Choose nsNEVLibrary.dll as Neuroshare DLL file. (and .ns1, .ns2, .ns3, .ns4, .ns5)
    %   .csv : DO OTHER SEQUENCE : Execute SimpleConverterF.m.
    %   .xls : DO OTHER SEQUENCE : Execute SimpleConverterF.m.
    %   .nsn : ERROR : Nothing to do.
    %   .*** : ERROR : Can't find the Neuroshare DLL.
    switch inExtension
        case '.map'
            % Alpha Omega data format.
            dllFile = 'nsAOLibrary.dll';

        case '.plx'
            % Plexon data format.
            dllFile = 'nsPlxLibrary.dll';

        case '.mcd'
            % Multi Channel Systems
            dllFile = 'nsMCDLibrary.dll';

        case '.nex'
            % Nex Technologies (NeuroExplorer)
            dllFile = 'NeuroExplorerNeuroShareLibrary.dll';

        case '.stb'
            % Tucker-Davis
            dllFile = 'nsTDTLib.dll';

        case {'.nev','.ns1','.ns2','.ns3','.ns4','.ns5'}
            % Cyberkinetics Inc., Library for Cerebus file group
            dllFile = 'nsNEVLibrary.dll';

        case '.csv'

            % Execute SimpleConverterF.m
            result = SimpleConverterF(inputFileName, outputFileName);
            return;

        case '.xls'

            % Execute SimpleConverterF.m
            result = SimpleConverterF(inputFileName, outputFileName);
            return;

        case '.nsn'
            % Neuroshare data format.
            error('The file is .nsn already.');

        otherwise
            % No defined data format.
            error('Can not find the DLL file for its data format.');
    end

    %   The data format is needed to use Neuroshare DLL.

    %   Set DLL file.
    % if 0 ~= ns_SetLibrary(dllFile);
    if 0 ~= ns_SetLibrary(which(dllFile));
        error('Can not open or find the DLL file for its data format.');
    end

    %   Open the data file.
    [nsRFResult, hFile] = ns_OpenFile(inputFileName);
    if 0 ~= nsRFResult;
        error('Can not open the data file.');
    end

    %   Create File Class - can create Neuroshare file.
    %   nsObj : is the object of create file class.
    %         : includes Neuroshare data.
    [nsCFResult nsObj] = ns_CreateFile(outputFileName);
    if 0 ~= nsCFResult;
        error('Can not create the Neuroshare file.');
    end

    %   Get ns_FILEINFO from the data file.
    [nsRFResult, nsFileInfo] = ns_GetFileInfo(hFile);
    if 0 ~= nsRFResult;
        error('Can not see the data file. Is the data format correct?');
    end

    %   Get ns_FILEINFO from the object to set ns_FILEINFO.
    [nsCFResult nsa_FILEINFO ] = ns_GetFileInfo(nsObj);
    if 0 ~= nsCFResult;
        error('Can not get structure.');
    end

    %   Modify nsa_FILEINFO.
    nsa_FILEINFO.szFileType = nsFileInfo.FileType;
    nsa_FILEINFO.dTimeStampResolution = nsFileInfo.TimeStampResolution;
    nsa_FILEINFO.dTimeSpan = nsFileInfo.TimeSpan;
    nsa_FILEINFO.szAppName = nsFileInfo.AppName;
    nsa_FILEINFO.dwTime_Year = nsFileInfo.Time_Year;
    nsa_FILEINFO.dwTime_Month = nsFileInfo.Time_Month;
    %   Calculate day of week.
    %   And -1 is needed. Because Neuroshare treats 0 as Sunday.(MATLAB function weekday returns 1 if the date is sunday.)
    nsa_FILEINFO.dwTime_DayOfWeek = weekday(datenum(nsFileInfo.Time_Year,nsFileInfo.Time_Month,nsFileInfo.Time_Day)) -1; 
    nsa_FILEINFO.dwTime_Day = nsFileInfo.Time_Day;
    nsa_FILEINFO.dwTime_Hour = nsFileInfo.Time_Hour;
    nsa_FILEINFO.dwTime_Min = nsFileInfo.Time_Min;
    nsa_FILEINFO.dwTime_Sec = nsFileInfo.Time_Sec;
    nsa_FILEINFO.dwTime_MilliSec = nsFileInfo.Time_MilliSec;
    nsa_FILEINFO.szFileComment = nsFileInfo.FileComment;

    %   Set nsa_FILEINFO to the object.
    [nsCFResult nsObj] = ns_SetFileInfo(nsObj, nsa_FILEINFO);
    if 0 ~= nsCFResult;
        error('Can not set structure. Does the structure include correct members?');
    end

    %   Read EntityInfo.
    [nsRFResult, Data.EntityInfo] = ns_GetEntityInfo(hFile, 1:nsFileInfo.EntityCount);
    if 0 ~= nsRFResult;
        error('Can not see the data file. Is the data format correct?');
    end


    for ii = 1:length(Data.EntityInfo)
        switch Data.EntityInfo(ii).EntityType
            case 0
                %   Unknown entity
                %disp('Unknown');
            case 1
                %   Event entity
                %disp('Event');

                %   Get ns_EVENTINFO from the data file.
                [nsRFResult tempEventInfo] = ns_GetEventInfo(hFile, ii);
                if 0 ~= nsRFResult;
                    error('Can not see the data file. Is the data format correct?');
                end

                %   Create Event Entity.
                [nsCFResult nsObj EventID] = ns_NewEventData(nsObj, Data.EntityInfo(ii).EntityLabel);
                if 0 ~= nsCFResult;
                    error('Can not create new event entity.');
                end

                %   Get nsa_EVENTINFO from the object to set nsa_EVENTINFO.
                [nsCFResult nsa_EVENTINFO] = ns_GetEventInfo(nsObj, EventID);
                if 0 ~= nsCFResult;
                    error('Can not get structure.');
                end

                %   Modify nsa_EVENTINFO.
                nsa_EVENTINFO.szCSVDesc = tempEventInfo.CSVDesc;

                %   Set nsa_EVENTINFO to the object.
                [nsCFResult nsObj] = ns_SetEventInfo(nsObj, EventID, nsa_EVENTINFO);
                if 0 ~= nsCFResult;
                    error('Can not set structure. Does the structure include correct members?');
                end

                %   No need to get Data if the entity does not include records.
                if 0 == Data.EntityInfo(ii).ItemCount;
                    continue;
                end

                %   Get EventData
                [nsRFResult, TimeStamp, Value, ValueSize] = ns_GetEventData(hFile,ii,1:Data.EntityInfo(ii).ItemCount);
                if 0 ~= nsRFResult;
                    error('Can not see the data file. Is the data format correct?');
                end

                %   Add EventData to the object.
                %   NOTICE : TimestampT is transposed vector of Value.
                %   NOTICE : ValueT is transposed vector of Value.
                TimeStampT = TimeStamp';
                len = length(TimeStampT);
                ValueT = Value';
                for jj=1:len
                    tempTime = TimeStampT(jj);
                    tempValue = ValueT(jj);
                    [nsCFResult nsObj] = ns_AddEventData(nsObj, EventID, tempTime, tempValue);
                    if 0 ~= nsCFResult;
                        error('Can not add data.');
                    end
                end
                clear TimeStamp Value ValueSize;
                clear TimeStampT len ValueT;


            case 2
                %   Analog entity
                %disp('Analog');

                %   Get ns_ANALOGINFO from the data file.
                [nsRFResult tempAnalogInfo] = ns_GetAnalogInfo(hFile, ii);
                if 0 ~= nsRFResult;
                    error('Can not see the data file. Is the data format correct?');
                end

                %   Create Analog Entity.
                [nsCFResult nsObj AnalogID] = ns_NewAnalogData(nsObj, Data.EntityInfo(ii).EntityLabel);
                if 0 ~= nsCFResult;
                    error('Can not create new analog entity.');
                end

                %   Get nsa_ANALOGINFO from the object to set nsa_ANALOGINFO.
                [nsCFResult nsa_ANALOGINFO] = ns_GetAnalogInfo(nsObj, AnalogID);
                if 0 ~= nsCFResult;
                    error('Can not get structure.');
                end

                %   Modify nsa_ANALOGINFO.
                nsa_ANALOGINFO.dSampleRate = tempAnalogInfo.SampleRate;
                nsa_ANALOGINFO.dMinVal = tempAnalogInfo.MinVal;
                nsa_ANALOGINFO.dMaxVal = tempAnalogInfo.MaxVal;
                nsa_ANALOGINFO.szUnits = tempAnalogInfo.Units;
                nsa_ANALOGINFO.dResolution = tempAnalogInfo.Resolution;
                nsa_ANALOGINFO.dLocationX = tempAnalogInfo.LocationX;
                nsa_ANALOGINFO.dLocationY = tempAnalogInfo.LocationY;
                nsa_ANALOGINFO.dLocationZ = tempAnalogInfo.LocationZ;
                nsa_ANALOGINFO.dLocationUser = tempAnalogInfo.LocationUser;
                nsa_ANALOGINFO.dHighFreqCorner = tempAnalogInfo.HighFreqCorner;
                nsa_ANALOGINFO.dwHighFreqOrder = tempAnalogInfo.HighFreqOrder;
                nsa_ANALOGINFO.szHighFilterType = tempAnalogInfo.HighFilterType;
                nsa_ANALOGINFO.dLowFreqCorner = tempAnalogInfo.LowFreqCorner;
                nsa_ANALOGINFO.dwLowFreqOrder = tempAnalogInfo.LowFreqOrder;
                nsa_ANALOGINFO.szLowFilterType = tempAnalogInfo.LowFilterType;
                nsa_ANALOGINFO.szProbeInfo = tempAnalogInfo.ProbeInfo;

                %   Set nsa_ANALOGINFO to the object.
                [nsCFResult nsObj] = ns_SetAnalogInfo(nsObj, AnalogID, nsa_ANALOGINFO);
                if 0 ~= nsCFResult;
                    error('Can not set structure. Does the structure include correct members?');
                end

                %   No need to get Data if the entity does not include records.
                if 0 == Data.EntityInfo(ii).ItemCount;
                    continue;
                end

                %   Get AnalogValue
                [nsRFResult, ContCount, Value] = ns_GetAnalogData(hFile,ii,1,Data.EntityInfo(ii,1).ItemCount);
                if 0 ~= nsRFResult;
                    error('Can not see the data file. Is the data format correct?');
                end

                %   Add AnalogValue to the object.
                %   NOTICE : dTimeStamp is 0. Because DLL can not get it.
                %   NOTICE : Value' is transposed vector of Data.
                [nsCFResult nsObj] = ns_AddAnalogData(nsObj, AnalogID, 0, Value');
                if 0 ~= nsCFResult;
                    error('Can not add data.');
                end

                clear ContCount;
                clear Value;

            case 3
                %   Segment entity
                %disp('Segment');

                %   Get ns_SEGMENTINFO from the data file.
                [nsRFResult tempSegmentInfo] = ns_GetSegmentInfo(hFile, ii);
                if 0 ~= nsRFResult;
                    error('Can not see the data file. Is the data format correct?');
                end

                %   Create Segment Entity.
                [nsCFResult nsObj SegmentID] = ns_NewSegmentData(nsObj, Data.EntityInfo(ii).EntityLabel);
                if 0 ~= nsCFResult;
                    error('Can not create new segment entity.');
                end

                %   Get nsa_SEGMENTINFO from the object to set nsa_SEGMENTINFO.
                [nsCFResult nsa_SEGMENTINFO] = ns_GetSegmentInfo(nsObj, SegmentID);
                if 0 ~= nsCFResult;
                    error('Can not get structure.');
                end

                %   Modify nsa_SEGMENTINFO.
                nsa_SEGMENTINFO.dSampleRate = tempSegmentInfo.SampleRate;
                %   Can not set szUnits. Because DLL does not return Units.
                %nsa_SEGMENTINFO.szUnits = tempSegmentInfo.Units;

                %   Set nsa_SEGMENTINFO to the object.
                [nsCFResult nsObj] = ns_SetSegmentInfo(nsObj, SegmentID, nsa_SEGMENTINFO);
                if 0 ~= nsCFResult;
                    error('Can not set structure. Does the structure include correct members?');
                end

                %   No need to get Data if the entity does not include records.
                if 0 == Data.EntityInfo(ii).ItemCount;
                    continue;
                end

                %   Get SegmentData
                [nsRFResult, TimeStamp, Value, SampleCount, UnitID] = ns_GetSegmentData(hFile,ii,1:(Data.EntityInfo(ii).ItemCount));
                if 0 ~= nsRFResult;
                    error('Can not see the data file. Is the data format correct?');
                end

                len = length(TimeStamp);
                for jj=1:len

                    %   Add Segment Value to the object.
                    tempTimeStamp = TimeStamp(jj);
                    tempValue = Value(:,jj);
                    tempUnitID = UnitID(jj);
                    [nsCFResult nsObj SegSourceID] = ns_AddSegmentData(nsObj, SegmentID, tempTimeStamp, tempUnitID, tempValue');
                    if 0 ~= nsCFResult;
                        error('Can not add data.');
                    end

                    %   Get ns_SEGSSOURCEINFO from the data file.
                    [nsRFResult tempSegSourceInfo] = ns_GetSegmentSourceInfo(hFile, ii, jj);
                    if 0 ~= nsRFResult && -6 ~= nsRFResult;
                        error('Can not see the data file. Is the data format correct?');
                    end
                    if -6 == nsRFResult;
                        %warning('Number of SegmentSource does not correspond to channels of Segment Value. System set default value to the SegmentSourceInfo .');
                        continue;
                    end

                    %   Get nsa_SEGSOURCEINFO from the object to set nsa_SEGSOURCEINFO.
                    [nsCFResult nsa_SEGSOURCEINFO] = ns_GetSegmentSourceInfo(nsObj, SegmentID, SegSourceID);
                    if 0 ~= nsCFResult;
                        error('Can not get structure.');
                    end

                    %   Modify nsa_SEGSOURCEINFO.
                    nsa_SEGSOURCEINFO.dMinVal = tempSegSourceInfo.MinVal;
                    nsa_SEGSOURCEINFO.dMaxVal = tempSegSourceInfo.MaxVal;
                    nsa_SEGSOURCEINFO.dResolution = tempSegSourceInfo.Resolution;
                    nsa_SEGSOURCEINFO.dSubSampleShift = tempSegSourceInfo.SubSampleShift;
                    nsa_SEGSOURCEINFO.dLocationX = tempSegSourceInfo.LocationX;
                    nsa_SEGSOURCEINFO.dLocationY = tempSegSourceInfo.LocationY;
                    nsa_SEGSOURCEINFO.dLocationZ = tempSegSourceInfo.LocationZ;
                    nsa_SEGSOURCEINFO.dLocationUser = tempSegSourceInfo.LocationUser;
                    nsa_SEGSOURCEINFO.dHighFreqCorner = tempSegSourceInfo.HighFreqCorner;
                    nsa_SEGSOURCEINFO.dwHighFreqOrder = tempSegSourceInfo.HighFreqOrder;
                    nsa_SEGSOURCEINFO.szHighFilterType = tempSegSourceInfo.HighFilterType;
                    nsa_SEGSOURCEINFO.dLowFreqCorner = tempSegSourceInfo.LowFreqCorner;
                    nsa_SEGSOURCEINFO.dwLowFreqOrder = tempSegSourceInfo.LowFreqOrder;
                    nsa_SEGSOURCEINFO.szLowFilterType = tempSegSourceInfo.LowFilterType;
                    nsa_SEGSOURCEINFO.szProbeInfo = tempSegSourceInfo.ProbeInfo;

                    %   Set nsa_SEGSOURCEINFO to the object.
                    [nsCFResult nsObj] = ns_SetSegmentSourceInfo(nsObj, SegmentID, SegSourceID, nsa_SEGSOURCEINFO);
                    if 0 ~= nsCFResult;
                        error('Can not set structure. Does the structure include correct members?');
                    end

                end

                clear TimeStamp Value SampleCount UnitID;
                clear tempTimeStamp tempValue tempUnitID;
                clear len;

            case 4
                %   Neural event entity
                %disp('Neural Event');

                %   Get ns_NEURALINFO from the data file.
                [nsRFResult tempNeuralInfo] = ns_GetNeuralInfo(hFile, ii);
                if 0 ~= nsRFResult;
                    error('Can not see the data file. Is the data format correct?');
                end

                %   Create Neural Event Entity.
                [nsCFResult nsObj NeuralID] = ns_NewNeuralEventData(nsObj, Data.EntityInfo(ii).EntityLabel);
                if 0 ~= nsCFResult;
                    error('Can not create new neural event entity.');
                end

                %   Get nsa_NEURALINFO from the object to set nsa_NEURALINFO.
                [nsCFResult nsa_NEURALINFO] = ns_GetNeuralInfo(nsObj, NeuralID);
                if 0 ~= nsCFResult;
                    error('Can not get structure.');
                end

                %   Modify nsa_NEURALINFO.
                nsa_NEURALINFO.dwSourceEntityID = tempNeuralInfo.SourceEntityID;
                nsa_NEURALINFO.dwSourceUnitID = tempNeuralInfo.SourceUnitID;
                nsa_NEURALINFO.szProbeInfo = tempNeuralInfo.ProbeInfo;

                %   Set nsa_NEURALINFO to the object.
                [nsCFResult nsObj] = ns_SetNeuralInfo(nsObj, NeuralID, nsa_NEURALINFO);
                if 0 ~= nsCFResult;
                    error('Can not set structure. Does the structure include correct members?');
                end

                %   No need to get Data if the entity does not include records.
                if 0 == Data.EntityInfo(ii).ItemCount;
                    continue;
                end

                %   Get Neural Event Value
%                [nsRFResult, Value] = ns_GetNeuralData(hFile,ii-1,0,Data.EntityInfo(ii,1).ItemCount);
                [nsRFResult, Value] = ns_GetNeuralData(hFile,ii,1,Data.EntityInfo(ii,1).ItemCount);
                if 0 ~= nsRFResult;
                    error('Can not see the data file. Is the data format correct?');
                end

                %   Add Neural Event Value to the object.
                %   NOTICE : ValueT is transposed vector of Value.
                ValueT = Value';
                len = length(ValueT);
                for jj=1:len
                    tempValue = ValueT(jj);
                    [nsCFResult nsObj] = ns_AddNeuralEventData(nsObj, NeuralID, tempValue);
                    if 0 ~= nsCFResult;
                        error('Can not add data.');
                    end
                end

                clear Value;
                clear len ValueT;

            otherwise
                %   Undefined entity
                error('Invalid entity exists!');
        end
    end

    %   Close the data file.
    [nsRFResult] = ns_CloseFile(hFile);
    if 0 ~= nsRFResult;
        error('Can not close the data file.');
    end

    %   Create the Neuroshare file.
    [nsCFResult] = ns_CloseFile(nsObj);
    if 0 ~= nsCFResult;
        error('Can not create the Neuroshare file.');
    end

catch ME

    Result = -1;

    %   Display Exception Messages.
    exceptionDisp(ME);

    %   Close the data file if it was defined.
    if 0 ~= exist('hFile','var');
        [nsRFResult] = ns_CloseFile(hFile);
        if 0 ~= nsRFResult;
            error('Can not close the data file.');
        end
    end
    
    %   Close all files if it was opened.
    fclose('all');

    %   Delete the intermediate files.
    
    %   Save latest workingDir.
    workingDir = pwd;
    
    %   Change Directory which includes intermediate files.
    [outDir, outFileName, outExtension, outVersn] = fileparts(outputFileName);
    cd(outDir);
    
    %   Delete the intermediate files ( save as _01_******.*** ).
    delete('_01_*.*');
    cd(workingDir);
    
end