function label_new = ResampleLabel(label_old, sr_new, sr_old)
% resamples label to correspond to new sampling rate
% label_new = ResampleLabel(label_old, sr_new, sr_old)
%
% Input:
%   label_old - labels corresponding to 'sr_old', [time x type]
%   sr_new    - sampling rate that this function resamples with [Hz]
%   sr_old    - sampling rate of 'label_old' (default: 1[Hz])
%
% Output:
%   label_new - resampled labels
%
% Created By: Satoshi MURATA (1),  satoshi-m@atr.jp  09/10/05
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Check args:
if exist('label_old','var')==0 || isempty(label_old)
    label_new = [];
    return
end

if exist('sr_new','var')==0 || isempty(sr_new)
    error('''sr_new'' should be specified');
end

if exist('sr_old','var')==0 || isempty(sr_old)
    sr_old = 1;
end


%% Resample:
% n times:
if mod(sr_new,sr_old)==0
    resamp_times = sr_new / sr_old;
    label_new    = cell(1,size(label_old,1));
    for itl=1:size(label_old,1)
        label_new{itl} = repmat(label_old(itl,:),resamp_times,1)';
    end
    label_new = [label_new{:}]';

% 1/n times:
elseif mod(sr_old,sr_new)==0
    resamp_times = sr_old / sr_new;
    ind_select   = 1:resamp_times:size(label_old,1);
    label_new    = label_old(ind_select,:);

% not divisible:
else
    num_old = size(label_old,1);
    time    = num_old / sr_old;
    num_new = floor(time * sr_new);
    ind_old = 0:1/sr_old:time;
    ind_new = 0:1/sr_new:time;
    
    label_new = zeros(num_new,size(label_old,2));
    point_old = 1;
    point_new = 1;
    while point_old<=num_old && point_new<=num_new
        if ind_old(point_old)<=ind_new(point_new) && ind_new(point_new)<ind_old(point_old+1)
            label_new(point_new,:) = label_old(point_old,:);
            point_new              = point_new + 1;
        else
            point_old              = point_old + 1;
        end
    end
end
