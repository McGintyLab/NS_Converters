function mat2nsnConverter( matFilePath )
% Convert mat file to neurshare file. (save as nsn file.)
%
% Inputs:
%   matFilePath - [char] - Mat for Brainliner format filename with path;
%
% Outputs:
%
% Created By : Keiji HARADA (1),  kharada@atr.jp  12/06/27
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Define file i/o, Initialization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Check args:
if exist('matFilePath','var')==0 || isempty(matFilePath)
    error('''matFilePath'' must be specified');
elseif ~ischar(matFilePath)
    error('''matFilePath'' must be char-type');
elseif ~exist(matFilePath,'file')
    error(' matFile must exist');
end

% Load data file.
load(matFilePath);

[pathstr, name, ext] = fileparts(matFilePath);
ext = '.nsn';
nsnfilename = strcat(name,ext);
nsnFilePath = fullfile(pathstr, nsnfilename);

% Delete nsn file if already exist.
warning off all;
delete(nsnFilePath);
warning on all;

%  timeStampResolution.
timeStampResolution=-1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Check mat whether mat is convertable or not.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if 1 ~= exist('chData', 'var')
    error('Wrong Format MAT file. chData does not exist.')
end
if 1 ~= exist('chHeader', 'var')
    error('Wrong Format MAT file. chHeader does not exist.')
end
if 1 ~= exist('fileInfo', 'var')
    error('Wrong Format MAT file. fileInfo does not exist.')
end
if 1 ~= isfield(chData, 'ch1')
    error('Wrong Format MAT file. chData.ch1 does not exist.')
end
if 1 ~= isfield(chHeader, 'ch1')
    error('Wrong Format MAT file. chHeader.ch1 does not exist.')
end
if 1 ~= isfield(fileInfo, 'date') || 1 ~= isfield(fileInfo, 'title') || 1 ~= isfield(fileInfo, 'description')
    error('Wrong Format MAT file. fileInfo does not include date,title,description.')
end
if size(fieldnames(chData)) ~= size(fieldnames(chHeader))
    error('Wrong Format MAT file. Channels of chData do not match channels of chHeader.')
end

% Ch is size of data.
ch=size(fieldnames(chData),1);
checker=ones(ch);
for ii=1:ch
    oneData=getfield(chData,strcat('ch', num2str(ii)));
    oneHeader=getfield(chHeader,strcat('ch', num2str(ii)));
    if ~isfield(oneHeader,'neuroshareType')
        error(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. Header does not include neuroshareType.'));
    end
    neuroshareType=getfield(oneHeader,'neuroshareType');
    try
        if ~isnumeric(neuroshareType)
            neuroshareType=str2num(neuroshareType);
        end
    catch e
        error(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. neuroshareType in header must be num or string [1-4].'));
    end
    switch neuroshareType
        case 1
            %   Event Entity
            %   Check chHeader
            if ~isfield(oneHeader,'chType') || ~isfield(oneHeader,'comment') || ~isfield(oneHeader,'title') || ~isfield(oneHeader,'description')
                warning(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. Header does not include chType, comment, title, or description.'));
                checker(ii)=0;
                continue;
            end
            %   Check chData
            if ~isfield(oneData,'timeStamp') || ~isfield(oneData,'value')
                warning(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. Data does not include timeStamp or value.'));
                checker(ii)=0;
                continue;
            end
            %   Check chData
            if ~isnumeric(oneData.timeStamp)
                warning(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. Data.timeStamp is not numeric.'));
                checker(ii)=0;
                continue;
            end
            if size(oneData.value,2) ~= size(oneData.timeStamp,2)
                warning(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. Number of Data.timeStamp is not equal to num of Data.value.'));
                checker(ii)=0;
                continue;
            end
            
        case 2
            % Analog Entity
            %   Check chHeader
            if ~isfield(oneHeader,'chType') || ~isfield(oneHeader,'comment') || ~isfield(oneHeader,'title') || ~isfield(oneHeader,'description') || ~isfield(oneHeader,'samplingRate') || ~isfield(oneHeader,'unitOfData') || ~isfield(oneHeader,'locationX') || ~isfield(oneHeader,'locationY') || ~isfield(oneHeader,'locationZ') || ~isfield(oneHeader,'locationUserDef') || ~isfield(oneHeader,'highFreqCutoff') || ~isfield(oneHeader,'highFreqCutoffOrder') || ~isfield(oneHeader,'highFreqCutoffFilterType') || ~isfield(oneHeader,'lowFreqCutoff') || ~isfield(oneHeader,'lowFreqCutoffOrder') || ~isfield(oneHeader,'lowFreqCutoffFilterType')
                warning(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. Header does not include chType, comment, title, description, samplingRate, unitOfData, locationX, locationY, locationZ, loationUserDef, highFreqCutoff, highFreqCutoffOrder, highFreqCutoffFilterType, lowFreqCutoff, lowFreqCutoffOrder or lowFreqCutoffFilterType.'));
                checker(ii)=0;
                continue;
            end
            %   Check chData
            if ~isfield(oneData,'startTime') || ~isfield(oneData,'value')
                warning(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. Data does not include startTime or value.'));
                checker(ii)=0;
                continue;
            end
            %   Check chHeader
            if ~isnumeric(oneHeader.samplingRate)
                warning(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. Header.samplingRate is not numeric.'));
                checker(ii)=0;
                continue;
            end
            %   Check chData
            if ~isnumeric(oneData.startTime) || ~isnumeric(oneData.value)
                warning(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. Data.startTime, Data.value is/are not numeric.'));
                checker(ii)=0;
                continue;
            end
            if size(oneData.value,1) ~= size(oneData.startTime,1)
                warning(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. Number of Data.startTime is not equal to num of Data.value.'));
                checker(ii)=0;
                continue;
            end
            
        case 3
            %   Segment Entity
            %   Check chHeader
            if ~isfield(oneHeader,'chType') || ~isfield(oneHeader,'comment') || ~isfield(oneHeader,'title') || ~isfield(oneHeader,'unitOfData') || ~isfield(oneHeader,'samplingRate') || ~isfield(oneHeader,'headerBySource')
                warning(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. Header does not include chType, comment, title, unitOfData, samplingRate or headerBySource.'));
                checker(ii)=0;
                continue;
            end
            %   Check headerBySource
            sources=oneHeader.headerBySource;
            if ~isfield(sources,'source1')
                warning(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. Header does not include any sources.'));
                checker(ii)=0;
                continue;
            end
            for jj=1:size(fieldnames(sources))
                oneSource=getfield(sources,strcat('source', num2str(jj)));
                if ~isfield(oneSource,'locationX') || ~isfield(oneSource,'locationY') || ~isfield(oneSource,'locationZ') || ~isfield(oneSource,'locationUserDef') || ~isfield(oneSource,'highFreqCutoff') || ~isfield(oneSource,'highFreqCutoffOrder') || ~isfield(oneSource,'highFreqCutoffFilterType') || ~isfield(oneSource,'lowFreqCutoff') || ~isfield(oneSource,'lowFreqCutoffOrder') || ~isfield(oneSource,'lowFreqCutoffFilterType') || ~isfield(oneSource,'description')
                    warning(strcat('ch',num2str(ii),'(source',num2str(jj),')cannot convert to Neuroshare format. Source header does not include locationX, locationY, locationZ, locationUserDef, highFreqCutoff, highFreqCutoffOrder, highFreqCutoffFilterType, lowFreqCutoff, lowFreqCutoffOrder, lowFreqCutoffFilterType or description.'));
                    checker(ii)=0;
                    continue;
                end
            end
            %   Check chData
            if ~isfield(oneData,'startTime') || ~isfield(oneData,'unitId') || ~isfield(oneData,'value')
                warning(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. Data does not include startTime, unitId or value.'));
                checker(ii)=0;
                continue;
            end
            %   Check chHeader
            if ~isnumeric(oneHeader.samplingRate)
                warning(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. Header.samplingRate is not numeric.'));
                checker(ii)=0;
                continue;
            end
            %   Check chData
            if ~isnumeric(oneData.startTime) || ~isnumeric(oneData.unitId) || ~isnumeric(oneData.value)
                warning(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. Data.startTime, Data.unitId, Data.value is/are not numeric.'));
                checker(ii)=0;
                continue;
            end
            if size(oneData.value,1) ~= size(oneData.startTime,1) || size(oneData.value,1) ~= size(oneData.unitId,1)
                warning(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. Number of Data.startTime, Data.unitId  is not equal to num of Data.value.'));
                checker(ii)=0;
                continue;
            end
            
            
        case 4
            %   Neural Event Entity
            %   Check chHeader
            if ~isfield(oneHeader,'chType') || ~isfield(oneHeader,'comment') || ~isfield(oneHeader,'title') || ~isfield(oneHeader,'description') || ~isfield(oneHeader,'sourceId') || ~isfield(oneHeader,'unitId')
                warning(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. Header does not include chType, comment, title, description, sourceId or unitId.'));
                checker(ii)=0;
                continue;
            end
            %   Check chData
            if ~isfield(oneData,'timeStamp')
                warning(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. Data does not include timeStamp.'));
                checker(ii)=0;
                continue;
            end
            %   Check chData
            if ~isnumeric(oneData.timeStamp)
                warning(strcat('ch',num2str(ii),' cannot convert to Neuroshare format. Data.timeStamp is not numeric.'));
                checker(ii)=0;
                continue;
            end
            
        case 5
            %   File Info
            %   Skip
            checker(ii)=0;
            
        otherwise
            %   Skip
            checker(ii)=0;
            warning(strcat('ch',num2str(ii),' cannot convert to Neuroshare format'));
    end
    
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Create Neuroshare file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%	Create nsObj which has Neuroshare header info.
[ns_Result nsObj] = ns_CreateFile( nsnFilePath );		%	[OK]	If nsFile's extension is not '.nsn' or ''(Blank), then return ns_WRONGLABEL.
if 0 ~= ns_Result
    return;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Convert mat to the Neuroshare file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for ii=1:ch
    
    %   Skip
    if ~checker(ii)
        continue;
    end
    
    oneData=getfield(chData,strcat('ch', num2str(ii)));
    oneHeader=getfield(chHeader,strcat('ch', num2str(ii)));
    neuroshareType=getfield(oneHeader,'neuroshareType');
    if ~isnumeric(neuroshareType)
        neuroshareType=str2num(neuroshareType);
    end
    
    switch neuroshareType
        case 1
            %   Event Entity
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %	Initialize Event Data
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %	Create event entity. ( Create new entity ID and initialize headers. )
            [ ns_Result nsObj EventID ] = ns_NewEventData( nsObj, oneHeader.title, oneHeader.chType, oneHeader.comment );		%	[OK]	Set ns_ENTITYINFO.szEntityLabel, chType, chComment.
            if 0 ~= ns_Result
                return;
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %	Modify Event Entity Specific Infomation Header[ ns_EVENTINFO ]
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %	Get header.
            [ ns_Result nsa_EVENTINFO ] = ns_GetEventInfo( nsObj, EventID );	%	[OK]    Get nsa_EVENTINFO from ns_EVENTINFO.
            if 0 ~= ns_Result
                return;
            end
            
            %	Modify members.
            %	Comment out members which you do not want to modify.
            nsa_EVENTINFO.szCSVDesc = oneHeader.description;
            
            %	Set header.
            [ ns_Result nsObj] = ns_SetEventInfo( nsObj, EventID, nsa_EVENTINFO );					%	[OK]	If nsa_EVENTINFO includes wrong name of members, then return ns_WRONGINFO, nsObj.
            if 0 ~= ns_Result
                return;
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %	Add Event Data
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %	Add Event Data
            for row = 1:size( oneData.timeStamp, 2 )
                Time  = oneData.timeStamp( 1,row );
                
                if iscell(oneData.value(1,row))
                    Value = oneData.value{1,row};
                else
                    Value = oneData.value(1,row);
                end
                
                %	Add Event Data [ Write to the intermediate file and Update ns_EVENTINFO ]
                [ ns_Result nsObj ] = ns_AddEventData( nsObj, EventID, Time, Value );						%	[OK]    If there is difference between type of Value and ever registed it, then ERROR. Return ns_WRONGDATA, nsObj.
                if 0 ~= ns_Result
                    return;
                end
            end
            
            %	Clear Event Data
            clear nsa_EVENTINFO;
            clear Time Value row;
            
            
        case 2
            % Analog Entity
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %	Initialize Analog Data
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %	Create analog entity. ( Create new entity ID and initialize headers. )
            [ ns_Result nsObj AnalogID ] = ns_NewAnalogData( nsObj, oneHeader.title, oneHeader.chType, oneHeader.comment );	%	[OK]	Set ns_ENTITYINFO.szEntityLabel, chType, chComment.
            if 0 ~= ns_Result
                return;
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %	Modify Analog Entity Specific Infomation Header[ ns_ANALOGINFO ]
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %	Get header.
            [ ns_Result nsa_ANALOGINFO ] = ns_GetAnalogInfo( nsObj, AnalogID );			%	[OK]    Get nsa_ANALOGINFO from ns_ANALOGINFO.
            if 0 ~= ns_Result
                return;
            end
            
            %	Modify members.
            %	Comment out members which you do not want to modify.
            nsa_ANALOGINFO.dSampleRate      = oneHeader.samplingRate;
            nsa_ANALOGINFO.szUnits          = oneHeader.unitOfData;
            nsa_ANALOGINFO.dResolution      = 1/oneHeader.samplingRate;
            if timeStampResolution==-1 || timeStampResolution < 1/oneHeader.samplingRate
                timeStampResolution=1/oneHeader.samplingRate;
            end
            nsa_ANALOGINFO.dLocationX       = oneHeader.locationX;
            nsa_ANALOGINFO.dLocationY       = oneHeader.locationY;
            nsa_ANALOGINFO.dLocationZ       = oneHeader.locationZ;
            nsa_ANALOGINFO.dLocationUser    = oneHeader.locationUserDef;
            nsa_ANALOGINFO.dHighFreqCorner  = oneHeader.highFreqCutoff;
            nsa_ANALOGINFO.dwHighFreqOrder  = oneHeader.highFreqCutoffOrder;
            nsa_ANALOGINFO.szHighFilterType = oneHeader.highFreqCutoffFilterType;
            nsa_ANALOGINFO.dLowFreqCorner   = oneHeader.lowFreqCutoff;
            nsa_ANALOGINFO.dwLowFreqOrder   = oneHeader.lowFreqCutoffOrder;
            nsa_ANALOGINFO.szLowFilterType  = oneHeader.lowFreqCutoffFilterType;
            nsa_ANALOGINFO.szProbeInfo      = oneHeader.description;
            
            %	Set header.
            [ ns_Result nsObj ] = ns_SetAnalogInfo( nsObj, AnalogID, nsa_ANALOGINFO );				%	[OK]	If nsa_ANALOGINFO includes wrong name of members, then return ns_WRONGINFO, nsObj.
            if 0 ~= ns_Result
                return;
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %	15.Add Analog Data
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %	Add Analog Data
            for row = 1:size( oneData.startTime, 1 )
                
                Time = oneData.startTime(row,1);
                DummyValue = oneData.value(row,:);
                Value = DummyValue(find(~isnan(DummyValue)));
                
                %	Add Analog Data [ Write to the intermediate file and Update ns_ANALOGINFO ]
                [ns_Result nsObj] = ns_AddAnalogData( nsObj, AnalogID, Time, Value );						%	[OK]
                if 0 ~= ns_Result
                    return;
                end
            end
            
            %	Clear Analog Data
            clear nsa_ANALOGINFO;
            clear Time Value DummyValue row;
            
        case 3
            %   Segment Entity
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %	Initialize Segment Data
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %	Create segment entity. ( Create new entity SegmentID and initialize headers. )
            [ ns_Result nsObj SegmentID ] = ns_NewSegmentData( nsObj, oneHeader.title, oneHeader.chType,oneHeader.comment );	%	[OK]	Set ns_ENTITYINFO.szEntityLabel, chType, chComment.
            if 0 ~= ns_Result
                return;
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %	Modify Segment Entity Specific Infomation Header[ ns_SEGMENTINFO ]
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %	Get header.
            [ ns_Result nsa_SEGMENTINFO ] = ns_GetSegmentInfo( nsObj, SegmentID );		%	[OK]    Get nsa_SEGMENTINFO from ns_SEGMENTINFO.
            if 0 ~= ns_Result
                return;
            end
            
            %	Modify members.
            %	Comment out members which you do not want to modify.
            nsa_SEGMENTINFO.dSampleRate			 = oneHeader.samplingRate;
            nsa_SEGMENTINFO.szUnits				 = oneHeader.unitOfData;
            if timeStampResolution==-1 || timeStampResolution < 1/oneHeader.samplingRate
                timeStampResolution=1/oneHeader.samplingRate;
            end
            
            %	Set header.
            [ ns_Result nsObj] = ns_SetSegmentInfo( nsObj, SegmentID, nsa_SEGMENTINFO );			%	[OK]	If nsa_SEGMENTINFO includes wrong name of members, then return ns_WRONGINFO, nsObj.
            if 0 ~= ns_Result
                return;
            end
            
            %   Add Segment Data
            if size( oneData.timeStamp,1) >= 1
                for row = 1:size( oneData.startTime, 1 )
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    %	Add Segment Data
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    
                    Time = oneData.startTime( row, 1 );
                    UnitID = oneData.unitId( row, 1 );
                    DummyValue = oneData.value( row, : );
                    Value = DummyValue(find(~isnan(DummyValue)));
                    
                    %	Add Segment Data [ Write to the intermediate file, Create ns_SEGSOURCEINFO, Update ns_SEGMENTINFO&ns_SEGSOURCEINFO ]
                    [ ns_Result nsObj ] = ns_AddSegmentData( nsObj, SegmentID, Time, UnitID, Value );						%	[OK]
                    if 0 ~= ns_Result
                        return;
                    end
                    
                end
            end
            %   Set Segment Source
            for row = 1:size( fieldnames(oneHeader.headerBySource))
                oneSource=getfield(sources,'source1');
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %	Modify Segment Source Entity Specific Infomation Header[ ns_SEGSOURCEINFO ]
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                %   SegmentSource must be one.(ns_CreateFile's specification)
                
                %	Get header.
                [ ns_Result nsa_SEGSOURCEINFO ] = ns_GetSegmentSourceInfo( nsObj, SegmentID, 1 );		%	[OK]    Get nsa_SEGSOURCEINFO from ns_SEGSOURCEINFO.
                if 0 ~= ns_Result
                    return;
                end
                
                %	Modify members.
                %	Comment out members which you do not want to modify.
                nsa_SEGSOURCEINFO.dResolution               = 1/oneHeader.samplingRate;
                nsa_SEGSOURCEINFO.dSubSampleShift           = 0;
                nsa_SEGSOURCEINFO.dLocationX                = oneSource.locationX;
                nsa_SEGSOURCEINFO.dLocationY                = oneSource.locationY;
                nsa_SEGSOURCEINFO.dLocationZ                = oneSource.locationZ;
                nsa_SEGSOURCEINFO.dLocationUser             = oneSource.locationUserDef;
                nsa_SEGSOURCEINFO.dHighFreqCorner           = oneSource.highFreqCutoff;
                nsa_SEGSOURCEINFO.dwHighFreqOrder           = oneSource.highFreqCutoffOrder;
                nsa_SEGSOURCEINFO.szHighFilterType          = oneSource.highFreqCutoffFilterType;
                nsa_SEGSOURCEINFO.dLowFreqCorner            = oneSource.lowFreqCutoff;
                nsa_SEGSOURCEINFO.dwLowFreqOrder            = oneSource.lowFreqCutoffOrder;
                nsa_SEGSOURCEINFO.szLowFilterType           = oneSource.lowFreqCutoffFilterType;
                nsa_SEGSOURCEINFO.szProbeInfo               = oneSource.description;
                
                if isempty(nsa_SEGSOURCEINFO.dwHighFreqOrder) || isempty(nsa_SEGSOURCEINFO.dwLowFreqOrder)
                    continue;
                end
                
                %	Set header.
                [ ns_Result nsObj] = ns_SetSegmentSourceInfo( nsObj, SegmentID, 1, nsa_SEGSOURCEINFO );			%	[OK]	If nsa_SEGSOURCEINFO includes wrong name of members, then return ns_WRONGINFO, nsObj.
                if 0 ~= ns_Result
                    return;
                end
                
                
            end
            
            %	Clear Segment Data
            clear nsa_SEGMENTINFO;
            clear nsa_SEGSOURCEINFO;
            clear segmentData;
            clear Time UnitID Value DummyValue row;
            
            
        case 4
            %   Neural Event Entity
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %	Initialize Neural Event Data
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %	Create neural event entity. ( Create new entity ID and initialize headers. )
            [ ns_Result nsObj NeuralEventID ] = ns_NewNeuralEventData( nsObj, oneHeader.title, oneHeader.chType, oneHeader.comment  );	%	[OK]	Set ns_ENTITYINFO.szEntityLabel, chType, chComment.
            if 0 ~= ns_Result
                return;
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %	Modify Neural Event Entity Specific Infomation Header[ ns_NEURALINFO ]
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %	Get header.
            [ ns_Result nsa_NEURALINFO ] = ns_GetNeuralInfo( nsObj, NeuralEventID );	%	[OK]    Get nsa_NEURALINFO from ns_NEURALINFO.
            if 0 ~= ns_Result
                return;
            end
            
            %	Modify members.
            %	Comment out members which you do not want to modify.
            nsa_NEURALINFO.dwSourceEntityID	 = oneHeader.sourceId;
            nsa_NEURALINFO.dwSourceUnitID	 = oneHeader.unitId;
            nsa_NEURALINFO.szProbeInfo		 = oneHeader.description;
            
            %	Set header.
            [ ns_Result nsObj] = ns_SetNeuralInfo( nsObj, NeuralEventID, nsa_NEURALINFO );		%	[OK]	If nsa_NAURALINFO includes wrong name of members, then return ns_WRONGINFO, nsObj.
            if 0 ~= ns_Result
                return;
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %	Add Neural Event Data
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %	Add Neural Event Data
            if size( oneData.timeStamp,1) == 1
                for row = 1:size( oneData.timeStamp,2)
                    
                    Time = oneData.timeStamp( row );
                    
                    %	Add Neural Event Data [ Write to the intermediate file and Update ns_NEURALINFO ]
                    [ ns_Result nsObj ] = ns_AddNeuralEventData( nsObj, NeuralEventID, Time );					%	[OK]
                    if 0 ~= ns_Result
                        return;
                    end
                end
            end
            
            %	Clear Neural Event Data
            clear nsa_NEURALINFO;
            clear Time row;
            
        case 5
            %   File Info
            %   Skip
            
        otherwise
            %   Skip
    end
    
    
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Modify File Infomation Header[ ns_FILEINFO ]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%	Get header.
[ ns_Result nsa_FILEINFO ] = ns_GetFileInfo( nsObj );
if 0 ~= ns_Result
    return;
end

%	Modify members.
%	Comment out members which you do not want to modify.
nsa_FILEINFO.szFileType				 = fileInfo.title;
if timeStampResolution==-1
    timeStampResolution=0;
end
nsa_FILEINFO.dTimeStampResolution	 = timeStampResolution;
nsa_FILEINFO.dTimeSpan				 = 0;
nsa_FILEINFO.szAppName				 = 'ATR_BrainlinerMattoNSNConverter';
nsa_FILEINFO.dwTime_Year			 =  str2double(datestr(fileInfo.date,'yyyy'));
nsa_FILEINFO.dwTime_Month			 =  str2double(datestr(fileInfo.date,'mm'));
week = weekday(fileInfo.date) - 1;
nsa_FILEINFO.dwTime_DayOfWeek		 = week;
nsa_FILEINFO.dwTime_Day				 = str2double(datestr(fileInfo.date,'dd'));
nsa_FILEINFO.dwTime_Hour			 = str2double(datestr(fileInfo.date,'HH'));
nsa_FILEINFO.dwTime_Min				 = str2double(datestr(fileInfo.date,'MM'));
nsa_FILEINFO.dwTime_Sec				 = str2double(datestr(fileInfo.date,'SS'));
nsa_FILEINFO.dwTime_MilliSec		 = 0;
nsa_FILEINFO.szFileComment			 = fileInfo.description;

%	Set header.
[ ns_Result nsObj ] = ns_SetFileInfo( nsObj, nsa_FILEINFO );				%	[OK]	If nsa_FILEINFO includes wrong name of members, then return ns_WRONGINFO, nsObj.
if 0 ~= ns_Result
    return;
end

%	Clear nsa_FILEINFO
clear week nsa_FILEINFO;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Integrate all intermediate files.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%	Integrate all files.
ns_Result = ns_CloseFile( nsObj );
if 0 ~= ns_Result
    return;
end

end