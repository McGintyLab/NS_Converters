function result = ns_Converter(source_file, target_file)
% makes NSN format file from other format file
% result = ns_Converter(source_file, target_file)
%
% Input:
%   source_file - input filename with path;
%                 if absent, you should select by dialog
%   target_file - output filename with path;
%                 if absent, 'source_filenae' is used with '.nsn' extension
% Output:
%   result      - return result
%
% Created  By: Keiji Harada (1),    kharada@atr.jp    10/06/24
% Modified By: Keiji Harada (1),    kharada@atr.jp    13/03/22
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Initialize:
appformat = {'*.map','Alpha Omega format file (*.map)';...
             '*.bdf','Biosemi format file (*.bdf)';...
             '*.nev;*.ns1;*.ns2;*.ns3;*.ns4;*.ns5','Blackrock Microsystems format file (*.nev, *.ns1, *.ns2, *.ns3, *.ns4, *.ns5';...
             '*.vhdr','Brainvision format file (*.vhdr)';...
             '*.csv','Comma Separated Values file (*.csv)';...
             '*.rdf','ERPSS format file (*.rdf)';...
             '*.edf','European data format file (*.edf)';...
             '*.mat','MAT-files (*.mat)';...
             '*.xls','Microsoft Excel file (*.xls)';...
             '*.mcd','Multi Channel Systems format file (*.mcd)';...
             '*.cnt','Neuroscan format file (*.cnt)';...
             '*.nex','Nex Technologies (NeuroExplorer) format file (*.nex)';...
             '*.plx','Plexon format file (*.plx)';...
             '*.sma','Snapmaster format file (*.sma)'};


%% Check and get pars:
if ~exist('source_file','var') || isempty(source_file)
    allext = cellfun(@(x) sprintf('%s;',x), appformat(:,1)', 'UniformOutput', false);
    allext = [allext{:}];
    
    [file, path] = uigetfile([{allext},{'All Applicable format file'}; appformat],...
                             'Select data file');
    if isequal(file,0)
        error('''source_file'' should be specified');
    end
    source_file = fullfile(path, file);
end

if ~exist('target_file','var') || isempty(target_file)
    [path, file] = fileparts(source_file);
    target_file  = fullfile(path, [file '.nsn']);
else
    [path, file, ext] = fileparts(target_file);
    if ~strcmp(ext,'.nsn')
        warning('extension of ''target_file'' should be ''.nsn''');
        target_file = fullfile(path, [file '.nsn']);
    end
end


%% Add path (if need):
% ns_CreateFile library
str = which('ns_CreateFile');
if isempty(str)
    dirname = uigetdir(pwd,'Select ''ns_CreateFile'' directory');
    if ~ischar(dirname)
        error('''ns_Create Library'' can''t be found');
    end
    addpath(dirname);
end

% EEGLAB
[nouse, nouse, ext] = fileparts(source_file);
if ismember(lower(ext),{'.bdf','.vhdr','.rdf','.edf','.cnt','.sma'})
    str = which('eeglab');
    if isempty(str)
        dirname = uigetdir(pwd, 'Select ''EEGLAB'' directory');
        if ~ischar(dirname)
            error('''EEGLAB'' can''t be found');
        end
        addpath(genpath(dirname));
    end
end


%% Make NSN file:
try
    [nouse, nouse, ext] = fileparts(source_file);
    ext = lower(ext);
    if ismember(ext, {'.mat','.csv','.xls'})
        % read data:
        switch ext
            case '.mat'
                mat2nsnConverter(source_file);
            case '.csv'
                [data, srate, ch_name, ch_desc, date, file_type, file_desc] = ReadCsvFormat(source_file);
                % make NSN file:
                result = MakeNsnFile(data, srate, ch_name, ch_desc, date, file_type, file_desc, target_file);
            case '.xls'
                [data, srate, ch_name, ch_desc, date, file_type, file_desc] = ReadXlsFormat(source_file);
                % make NSN file:
                result = MakeNsnFile(data, srate, ch_name, ch_desc, date, file_type, file_desc, target_file);
        end
        
    elseif ismember(ext, {'.bdf','.vhdr','.rdf','.edf','.cnt','.sma'})    % use EEGLAB
        switch ext
            case {'.bdf', '.edf'}
                EEG = pop_biosig(source_file);
            case '.vhdr'
                [path, file] = fileparts(source_file);
                EEG = pop_loadbv(path, [file '.vhdr']);
            case '.rdf'
                EEG = pop_read_erpss(source_file);
            case '.cnt'
                EEG = pop_loadcnt(source_file);
            case '.sma'
                EEG = pop_snapread(source_file);
        end
        result = MakeNsnFromEEG(EEG, target_file);
        
    else
        % can run only on win 32bit:
        pc_inf = computer;
        if ~strcmpi(pc_inf,'PCWIN') && ~strcmpi(pc_inf,'PCWIN64')
            error('''%s'' file conversion needs windows machine',ext);
        end
        % select library:
        switch lower(ext(2:end))
            case 'map'      % Alpha Omega
                dll_file = 'nsAOLibrary.dll';
            case {'nev','ns1','ns2','ns3','ns4','ns5'}  % Blackrock Microsystems
                dll_file = 'nsNEVLibrary.dll';
            case  'mcd'     % Multi Channel Systems
                dll_file = 'nsMCDLibrary.dll';
            case 'nex'      % Nex Technologies
                dll_file = 'NeuroExplorerNeuroShareLibrary.dll';
            case 'plx'      % Plexon
                dll_file = 'nsPlxLibrary.dll';
            otherwise
                error('This converter can''t convert ''%s'' format file',ext);
        end
        % convert file:
        result = ConvertFileWithDll(source_file, target_file, dll_file);
    end
    
catch ME
    % set output:
    result = -1;
    
    % display exception message:
    ExceptionDisp(ME);
    
    % close all files:
    fclose('all');
    
    % delete intermediate files:
    [path, file] = fileparts(target_file);
    files        = dir(fullfile(path, ['_01_*', file]));
    if ~isempty(files)
        delete(files.name);
    end
end

