function nsTagElement = ns_ReadTagElement(hFile)
%
% Created By: Satoshi MURATA (1),  satoshi-m@atr.jp  09/02/25
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/05/08
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


nsTagElement = struct(...
    'ElemType',     fread(hFile, 1, 'uint32'),...
    'ElemLength',   fread(hFile, 1, 'uint32')...
);
