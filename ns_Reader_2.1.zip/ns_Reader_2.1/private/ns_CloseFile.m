function result = ns_CloseFile(hFile)
% Closes a neural data file
% result = ns_CloseFile(hFile)
%
% Inputs:
%   hFile  - handle/identification number to an opened file
% Outputs:
%   result - 0: the file is successfully closed, -1: error
%
% Created By: Satoshi MURATA (1),  satoshi-m@atr.jp  09/02/24
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/05/08
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Check args:
if exist('hFile','var')==0 || isempty(hFile)
    error('''hFile'' must be specified');
elseif ~isnumeric(hFile)
    error('''hFile'' must be double-type');
elseif ~isfloat(hFile)
    hFile = double(hFile);
end


%% Close file:
result = fclose(hFile);
