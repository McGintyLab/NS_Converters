function hFile = ns_OpenFile(filename)
% Opens a neural data file
% hFile = ns_OpenFile(filename)
%
% Inputs:
%   filename  - the name of the file to open
% Outputs:
%   hFile     - handle/identification number to the opened file
%
% Created By: Satoshi MURATA (1),  satoshi-m@atr.jp  09/02/24
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/05/08
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Check args:
if exist('filename','var')==0 || isempty(filename)
    error('''filename'' must be specified');
elseif ~ischar(filename)
    error('''filename'' must be char-type');
end


%% Open file:
hFile = fopen(filename);
if hFile==-1
    error('file:%s cannot be opened', filename);
end
