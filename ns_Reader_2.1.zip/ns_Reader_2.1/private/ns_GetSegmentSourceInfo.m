function nsSegmentSourceInfo = ns_GetSegmentSourceInfo(hFile, EntityID, SourceID)
% Retrieves information about the sources that generated the segment data
% nsSegmentSourceInfo = ns_GetSegmentSourceInfo(hFile, EntityID, SourceID)
%
% Inputs:
%   hFile               - handle/identification number to an open file
%   EntityID            - identification number of the Segment Entity
%   SourceID            - identification number of the Segment Entity source
% Outputs:
%   nsSegmentSourceInfo - ns_SEGSOURCEINFO structure that receives information about the source
%
% Created By: Satoshi MURATA (1),  satoshi-m@atr.jp  09/02/25
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/05/08
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Check args:
if exist('hFile','var')==0 || isempty(hFile)
    error('''hFile'' must be specified');
elseif ~isnumeric(hFile)
    error('''hFile'' must be double-type');
elseif ~isfloat(hFile)
    hFile = double(hFile);
end

if exist('EntityID','var')==0 || isempty(EntityID)
%    error('''EntityID'' must be specified');
    warning('''EntityID'' isn''t specified. Get information from all entities');
    EntityID = [];
elseif ~isnumeric(EntityID)
    error('''EntityID'' must be numeric-type');
elseif ~isempty(find(EntityID<1,1))
    warning('''EntityID'' has too small number');
end

if exist('SourceID','var')==0 || isempty(SourceID)
%    error('''SourceID'' must be specified');
    warning('''SourceID'' isn''t specified. Get information from all sources');
    SourceID = [];
elseif ~isnumeric(SourceID)
    error('''SourceID'' must be numeric-type');
elseif ~isempty(find(SourceID<1,1))
    warning('''SourceID'' has too small number');
end


%% Get file-information:
nsFileInfo = ns_GetFileInfo(hFile);

if isempty(EntityID)
    EntityID = 1:nsFileInfo.EntityCount;
elseif ~isempty(find(EntityID>nsFileInfo.EntityCount,1))
    warning('''EntityID'' has too large number');
end


%% Get ns_SegmentSourceInfo:
nsSegmentSourceInfo = cell(length(EntityID),1);
for ite=1:min(max(EntityID),nsFileInfo.EntityCount)
    nsTagElement = ns_ReadTagElement(hFile);
    
    ind = find(EntityID==ite);
    if isempty(ind)
        fseek(hFile,nsTagElement.ElemLength,'cof');
    else
        if nsTagElement.ElemType~=3         % ns_ENTITY_SEGMENT = 3
            warning('EntityID:%d isn''t ''Segment Entity''', ite);
            fseek(hFile,nsTagElement.ElemLength,'cof');
        else
            fseek(hFile,32+4+4,'cof');      % skip ns_ENTITYINFO
            SourceCount = fread(hFile,1,'uint32');
            fseek(hFile,4+4+8+32,'cof');
            if isempty(SourceID)
                SourceID = 1:SourceCount;
            elseif ~isempty(find(SourceID>SourceCount,1))
                warning('''SourceID'' has too large number');
            end
            
            nsSEGMENTSOURCEINFO_cell = cell(length(SourceID),15);
            for its=1:SourceCount
                ind_s = find(SourceID==its);
                if isempty(ind_s)
                    fseek(hFile,8+8+8+8+8+8+8+8+8+4+16+8+4+16+128,'cof');
                else
                    nsSEGMENTSOURCEINFO_cell(ind_s,:) = struct2cell(ns_ReadSegmentSourceInfo(hFile))';
                end
            end
            nsSegmentSourceInfo{ind} = cell2struct(nsSEGMENTSOURCEINFO_cell,...
                                                  {'MinVal','MaxVal','Resolution','SubSampleShift',...
                                                   'LocationX','LocationY','LocationZ','LocationUser',...
                                                   'HighFreqCorner','HighFreqOrder','HighFilterType',...
                                                   'LowFreqCorner','LowFreqOrder','LowFilterType',...
                                                   'ProbeInfo'},...
                                                   2);
            fseek(hFile, nsTagElement.ElemLength-(32+4*2)-(4*3+8+32)-(8*10+4*2+16*2+128)*SourceCount, 'cof');
        end
    end
end






%% ---------------------------------------------------------------
function nsSegmentSourceInfo = ns_ReadSegmentSourceInfo(hFile)

nsSegmentSourceInfo = struct(...
    'MinVal',           fread(hFile,  1,'double'),...
    'MaxVal',           fread(hFile,  1,'double'),...
    'Resolution',       fread(hFile,  1,'double'),...
    'SubSampleShift',   fread(hFile,  1,'double'),...
    'LocationX',        fread(hFile,  1,'double'),...
    'LocationY',        fread(hFile,  1,'double'),...
    'LocationZ',        fread(hFile,  1,'double'),...
    'LocationUser',     fread(hFile,  1,'double'),...
    'HighFreqCorner',   fread(hFile,  1,'double'),...
    'HighFreqOrder',    fread(hFile,  1,'uint32'),...
    'HighFilterType',   fread(hFile, 16,'uint8=>char')',...
    'LowFreqCorner',    fread(hFile,  1,'double'),...
    'LowFreqOrder',     fread(hFile,  1,'uint32'),...
    'LowFilterType',    fread(hFile, 16,'uint8=>char')',...
    'ProbeInfo',        fread(hFile,128,'uint8=>char')'...
);

nsSegmentSourceInfo = ns_InfoTrim(nsSegmentSourceInfo);
