function [TimeStamp, Data, DataSize] = ns_GetEventData(hFile, EntityID, Index)
% Retrieves event data by index
% [TimeStamp, Data, DataSize] = ns_GetEventData(hFile, EntityID, Index)
%
% Inputs:
%   hFile     - handle/identification number to an opened file
%   EntityID  - identification number of the entity in the data file
%   Index     - the index number of the requested Event data item
% Outputs:
%   TimeStamp - the timestamp of the Event data item
%   Data      - the data for the Event entry
%               the format is specified by EventType in ns_EVENTINFO
%   DataSize  - the actual number of bytes of data retrieved in the data buffer
%
% Created By: Satoshi MURATA (1),  satoshi-m@atr.jp  09/02/25
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/05/08
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Check args:
if exist('hFile','var')==0 || isempty(hFile)
    error('''hFile'' must be specified');
elseif ~isnumeric(hFile)
    error('''hFile'' must be double-type');
elseif ~isfloat(hFile)
    hFile = double(hFile);
end

if exist('EntityID','var')==0 || isempty(EntityID)
%    error('''EntityID'' must be specified');
    warning('''EntityID'' isn''t specified. Get data from all entities');
    EntityID = [];
elseif ~isnumeric(EntityID)
    error('''EntityID'' must be numeric-type');
elseif ~isempty(find(EntityID<1,1))
    warning('''EntityID'' has too small number');
end

if exist('Index','var')==0 || isempty(Index)
%    error('''Index'' must be specified');
    warning('''Index'' isn''t specified. Get data from all indexes');
    Index = [];
elseif ~isnumeric(Index)
    error('''Index'' must be numeric-type');
elseif ~isempty(find(Index<1,1))
    warning('''Index'' has too small number');
end


%% Get file-information:
nsFileInfo = ns_GetFileInfo(hFile);

if isempty(EntityID)
    EntityID = 1:nsFileInfo.EntityCount;
elseif ~isempty(find(EntityID>nsFileInfo.EntityCount,1))
    warning('''EntityID'' has too large number');
end


%% Get Event Data:
TimeStamp = cell(length(EntityID),1);
Data      = cell(length(EntityID),1);
DataSize  = cell(length(EntityID),1);
Index_org = Index;
for ite=1:min(max(EntityID),nsFileInfo.EntityCount)
    nsTagElement = ns_ReadTagElement(hFile);
    
    ind = find(EntityID==ite);
    if isempty(ind)
        fseek(hFile, nsTagElement.ElemLength, 'cof');
    else
        if nsTagElement.ElemType~=1         % ns_ENTITY_EVENT = 1
            warning('EntityID:%d isn''t ''Event Entity''', ite);
            fseek(hFile, nsTagElement.ElemLength, 'cof');
        else
            nsEntityInfo = ns_ReadEntityInfo(hFile);
            if isempty(Index)
                Index = 1:nsEntityInfo.ItemCount;
            elseif ~isempty(find(Index<1,1))
                warning('''Index'' has too large number in EntityID:%d', ite);
            end
            EventType = fread(hFile,1,'uint32');
            fseek(hFile,4+4+128,'cof');     % skip ns_EVENTINFO
            [TimeStamp{ind}, Data{ind}, DataSize{ind}] = ns_ReadEventData(hFile,Index,EventType);
        end
    end
    
    Index = Index_org;
end





%% ---------------------------------------------------------------
function [TimeStamp, Data, DataSize] = ns_ReadEventData(hFile, Index, EventType)

TimeStamp = zeros(length(Index),1);
DataSize  = zeros(length(Index),1);
Data      = cell(length(Index),1);
for itd=1:max(Index)
    ind = find(Index==itd);
    if isempty(ind)
        fseek(hFile,8,'cof');       % skip Timestamp
        dsize = fread(hFile,1,'uint32');
        fseek(hFile,dsize,'cof');   % skip EventValue
    else
        TimeStamp(ind) = fread(hFile,1,'double');
        DataSize(ind)  = fread(hFile,1,'uint32');
        switch EventType
            case 2              % 2: BYTE
                Data{ind} = fread(hFile,1,'int8');
            case 3              % 3: WORD
                Data{ind} = fread(hFile,1,'int16');
            case 4              % 4: DWORD
                Data{ind} = fread(hFile,1,'int32');
            otherwise           % 0: TEXT, 1: CSV
                Data{ind} = fread(hFile,DataSize(ind),'uint8=>char')';
        end
    end
end

if EventType==2 || EventType==3
    Data = cell2mat(Data);
end
