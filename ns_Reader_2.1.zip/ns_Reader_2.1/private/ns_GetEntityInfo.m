function nsEntityInfo = ns_GetEntityInfo(hFile, EntityID)
% Retrieves general entity information and type
% nsEntityInfo = ns_GetEntityInfo(hFile, EntityID)
%
% Inputs:
%   hFile        - handle/identification number to an opened file
%   EntityID     - identification number of the entity in the data file
% Outputs:
%   nsEntityInfo - ns_ENTITYINFO structure to receive entity information
%
% Created By : Satoshi MURATA (1),  satoshi-m@atr.jp  09/02/24
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  11/11/09
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/05/08
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Check args:
if exist('hFile','var')==0 || isempty(hFile)
    error('''hFile'' must be specified');
elseif ~isnumeric(hFile)
    error('''hFile'' must be double-type');
elseif ~isfloat(hFile)
    hFile = double(hFile);
end

if exist('EntityID','var')==0 || isempty(EntityID)
%    error('''EntityID'' must be specified');
    warning('''EntityID'' isn''t specified. Get information from all entities');
    EntityID = [];
elseif ~isnumeric(EntityID)
    error('''EntityID'' must be numeric-type');
elseif ~isempty(find(EntityID<1,1))
    warning('''EntityID'' has too small number');
end


%% Get file-information:
nsFileInfo = ns_GetFileInfo(hFile);

if isempty(EntityID)
    EntityID = 1:nsFileInfo.EntityCount;
elseif ~isempty(find(EntityID>nsFileInfo.EntityCount,1))
    warning('''EntityID'' has too large number');
end


%% Get ns_ENTITYINFO:
nsENTITYINFO_cell = cell(length(EntityID),3);
for ite=1:min(max(EntityID),nsFileInfo.EntityCount)
    nsTagElement = ns_ReadTagElement(hFile);
    
    if ~ismember(nsTagElement.ElemType,1:4)     % 0: Unknown, 5: File info
        fseek(hFile, nsTagElement.ElemLength, 'cof');
    else
        ind = find(EntityID==ite);
        if isempty(ind)
            fseek(hFile, nsTagElement.ElemLength, 'cof');
        else
            nsENTITYINFO_cell(ind,:) = struct2cell(ns_ReadEntityInfo(hFile))';
            fseek(hFile, nsTagElement.ElemLength-(32+4*2), 'cof');
        end
    end
end

nsEntityInfo = cell2struct(nsENTITYINFO_cell,{'EntityLabel','EntityType','ItemCount'},2);
