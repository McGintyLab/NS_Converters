function nsAnalogHeader = ns_ModAnalogHeader(chInfo, entityInfo, analogInfo)
% Modify analog data header
% nsAnalogHeader = ns_ModAnalogHeader(chInfo,analogInfo)
%
% Inputs:
%   chInfo        - struct - information of the channel
%   entityInfo        - struct - NSN header information of the entity (ns_ENTITYINFO)
%   analogInfo        - struct - NSN header information of the entity (ns_ANALOGINFO)
% Outputs:
%   nsAnalogHeader - struct - data header for analog entity
%
% Created By: Keiji HARADA (1),  kharada@atr.jp  12/04/13
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/04/25
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/05/08
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/06/27
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

if isfield(chInfo, 'chType')
    nsAnalogHeader.chType = chInfo.chType;
else
    nsAnalogHeader.chType = 'undefined';
end

if isfield(chInfo, 'comment')
    nsAnalogHeader.comment = chInfo.comment;
else
    nsAnalogHeader.comment = '';
end

if isfield(chInfo, 'chName')
    nsAnalogHeader.title = chInfo.chName;
else
    nsAnalogHeader.title = entityInfo.EntityLabel;
end

nsAnalogHeader.neuroshareType = entityInfo.EntityType;

nsAnalogHeader.description = analogInfo.ProbeInfo;
nsAnalogHeader.samplingRate = analogInfo.SampleRate;
nsAnalogHeader.unitOfData = analogInfo.Units;
nsAnalogHeader.locationX = analogInfo.LocationX;
nsAnalogHeader.locationY = analogInfo.LocationY;
nsAnalogHeader.locationZ = analogInfo.LocationZ;
nsAnalogHeader.locationUserDef = analogInfo.LocationUser;
nsAnalogHeader.highFreqCutoff = analogInfo.HighFreqCorner;
nsAnalogHeader.highFreqCutoffOrder = analogInfo.HighFreqOrder;
nsAnalogHeader.highFreqCutoffFilterType = analogInfo.HighFilterType;
nsAnalogHeader.lowFreqCutoff = analogInfo.LowFreqCorner;
nsAnalogHeader.lowFreqCutoffOrder = analogInfo.LowFreqOrder;
nsAnalogHeader.lowFreqCutoffFilterType = analogInfo.LowFilterType;
