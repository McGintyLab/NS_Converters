function nsAnalogInfo = ns_GetAnalogInfo(hFile, EntityID)
% Retrieves information specific to analog entities
% nsAnalogInfo = ns_GetAnalogInfo(hFile, EntityID)
%
% Inputs:
%   hFile        - handle/identification number to an opened file
%   EntityID     - identification number of the entity in the data file
% Outputs:
%   nsAnalogInfo - ns_ANALOGINFO structure to receive the Analog Entity information
%
% Created By: Satoshi MURATA (1),  satoshi-m@atr.jp  09/02/26
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/05/08
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Check args:
if exist('hFile','var')==0 || isempty(hFile)
    error('''hFile'' must be specified');
elseif ~isnumeric(hFile)
    error('''hFile'' must be double-type');
elseif ~isfloat(hFile)
    hFile = double(hFile);
end

if exist('EntityID','var')==0 || isempty(EntityID)
%    error('''EntityID'' must be specified');
    warning('''EntityID'' isn''t specified. Get information from all entities');
    EntityID = [];
elseif ~isnumeric(EntityID)
    error('''EntityID'' must be numeric-type');
elseif ~isempty(find(EntityID<1,1))
    warning('''EntityID'' has too small number');
end


%% Get file-information:
nsFileInfo = ns_GetFileInfo(hFile);

if isempty(EntityID)
    EntityID = 1:nsFileInfo.EntityCount;
elseif ~isempty(find(EntityID>nsFileInfo.EntityCount,1))
    warning('''EntityID'' has too large number');
end


%% Get ns_ANALOGINFO:
nsANALOGINFO_cell = cell(length(EntityID),16);
for ite=1:min(max(EntityID),nsFileInfo.EntityCount)
    nsTagElement = ns_ReadTagElement(hFile);
    
    ind = find(EntityID==ite);
    if isempty(ind)
        fseek(hFile, nsTagElement.ElemLength, 'cof');
    else
        if nsTagElement.ElemType~=2         % ns_ENTITY_ANALOG = 2
            warning('EntityID:%d isn''t ''Analog Entity''', ite);
            fseek(hFile, nsTagElement.ElemLength, 'cof');
        else
            fseek(hFile, 32+4*2, 'cof');    % skip 'ns_ENTITYINFO'
            nsANALOGINFO_cell(ind,:) = struct2cell(ns_ReadAnalogInfo(hFile))';
            fseek(hFile, nsTagElement.ElemLength-(32+4*2)-(8*10+4*2+16*3+128), 'cof');
        end
    end
end

nsAnalogInfo = cell2struct(nsANALOGINFO_cell,...
                          {'SampleRate','MinVal','MaxVal','Units','Resolution','LocationX','LocationY',...
                           'LocationZ','LocationUser','HighFreqCorner','HighFreqOrder','HighFilterType',...
                           'LowFreqCorner','LowFreqOrder','LowFilterType','ProbeInfo'},...
                           2);





%% ----------------------------------------------------------------------------
function nsAnalogInfo = ns_ReadAnalogInfo(hFile)


nsAnalogInfo = struct(...
    'SampleRate',       fread(hFile,   1, 'double'),...
    'MinVal',           fread(hFile,   1, 'double'),...
    'MaxVal',           fread(hFile,   1, 'double'),...
    'Units',            fread(hFile,  16, 'uint8=>char')',...
    'Resolution',       fread(hFile,   1, 'double'),...
    'LocationX',        fread(hFile,   1, 'double'),...
    'LocationY',        fread(hFile,   1, 'double'),...
    'LocationZ',        fread(hFile,   1, 'double'),...
    'LocationUser',     fread(hFile,   1, 'double'),...
    'HighFreqCorner',   fread(hFile,   1, 'double'),...
    'HighFreqOrder',    fread(hFile,   1, 'uint32'),...
    'HighFilterType',   fread(hFile,  16, 'uint8=>char')',...
    'LowFreqCorner',    fread(hFile,   1, 'double'),...
    'LowFreqOrder',     fread(hFile,   1, 'uint32'),...
    'LowFilterType',    fread(hFile,  16, 'uint8=>char')',...
    'ProbeInfo',        fread(hFile, 128, 'uint8=>char')'...
);

nsAnalogInfo = ns_InfoTrim(nsAnalogInfo);
