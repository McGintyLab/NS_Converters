function nsEventInfo = ns_GetEventInfo(hFile, EntityID)
% Retrieves information specific to event entities
% nsEventInfo = ns_GetEventInfo(hFile, EntityID)
%
% Inputs:
%   hFile       - handle/identification number to an opened file
%   EntityID    - identification number of the entity in the data file
% Outputs:
%   nsEventInfo - ns_EVENTINFO structure to receive the Event Entity information
%
% Created By: Satoshi MURATA (1),  satoshi-m@atr.jp  09/02/25
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/05/08
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Check args:
if exist('hFile','var')==0 || isempty(hFile)
    error('''hFile'' must be specified');
elseif ~isnumeric(hFile)
    error('''hFile'' must be double-type');
elseif ~isfloat(hFile)
    hFile = double(hFile);
end

if exist('EntityID','var')==0 || isempty(EntityID)
%    error('''EntityID'' must be specified');
    warning('''EntityID'' isn''t specified. Get information from all entities');
    EntityID = [];
elseif ~isnumeric(EntityID)
    error('''EntityID'' must be numeric-type');
elseif ~isempty(find(EntityID<1,1))
    warning('''EntityID'' has too small number');
end


%% Get file-information:
nsFileInfo = ns_GetFileInfo(hFile);

if isempty(EntityID)
    EntityID = 1:nsFileInfo.EntityCount;
elseif ~isempty(find(EntityID>nsFileInfo.EntityCount,1))
    warning('''EntityID'' has too large number');
end


%% Get ns_EVENTINFO:
nsEVENTINFO_cell = cell(length(EntityID),4);
for ite=1:min(max(EntityID),nsFileInfo.EntityCount)
    nsTagElement = ns_ReadTagElement(hFile);
    
    ind = find(EntityID==ite);
    if isempty(ind)
        fseek(hFile, nsTagElement.ElemLength, 'cof');
    else
        if nsTagElement.ElemType~=1         % ns_ENTITY_EVENT = 1
            warning('EntityID:%d isn''t ''Event Entity''', ite);
            fseek(hFile, nsTagElement.ElemLength, 'cof');
        else
            fseek(hFile, 32+4*2, 'cof');    % skip 'ns_ENTITYINFO'
            nsEVENTINFO_cell(ind,:) = struct2cell(ns_ReadEventInfo(hFile))';
            fseek(hFile, nsTagElement.ElemLength-(32+4*2)-(4*3+128), 'cof');
        end
    end
end

nsEventInfo = cell2struct(nsEVENTINFO_cell,{'EventType','MinDataLength','MaxDataLength','CSVDesc'},2);





%% ----------------------------------------------------------------------------
function nsEventInfo = ns_ReadEventInfo(hFile)


nsEventInfo = struct(...
    'EventType',        fread(hFile,   1, 'uint32'),...
    'MinDataLength',    fread(hFile,   1, 'uint32'),...
    'MaxDataLength',    fread(hFile,   1, 'uint32'),...
    'CSVDesc',          fread(hFile, 128, 'uint8=>char')'...
);

nsEventInfo = ns_InfoTrim(nsEventInfo);
