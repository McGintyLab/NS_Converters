function nsEventHeader = ns_ModEventHeader(chInfo, entityInfo, eventInfo)
% Modify event data header
% nsEventHeader = ns_ModEventHeader(chInfo,eventInfo)
%
% Inputs:
%   chInfo        - struct - information of the channel
%   entityInfo        - struct - NSN header information of the entity (ns_ENTITYINFO)
%   eventInfo        - struct - NSN header information of the entity (ns_EVENTINFO)
% Outputs:
%   nsEventHeader - struct - data header for event entity
%
% Created By: Keiji HARADA (1),  kharada@atr.jp  12/04/13
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/04/25
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/05/08
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/06/27
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

if isfield(chInfo, 'chType')
    nsEventHeader.chType = chInfo.chType;
else
    nsEventHeader.chType = 'undefined';
end

if isfield(chInfo, 'comment')
    nsEventHeader.comment = chInfo.comment;
else
    nsEventHeader.comment = '';
end

if isfield(chInfo, 'chName')
    nsEventHeader.title = chInfo.chName;
else
    nsEventHeader.title = entityInfo.EntityLabel;
end

nsEventHeader.neuroshareType = entityInfo.EntityType;

nsEventHeader.description = eventInfo.CSVDesc;
