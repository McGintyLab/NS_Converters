function nsSegmentInfo = ns_GetSegmentInfo(hFile, EntityID)
% Retrieves information specific to segment entities
% nsSegmentInfo = ns_GetSegmentInfo(hFile, EntityID)
%
% Inputs:
%   hFile         - handle/identification number to an opened file
%   EntityID      - identification number of the entity in the data file
% Outputs:
%   nsSegmentInfo - ns_SEGMENTINFO structure that receives segment information for the requested
%                   Segment Entity
%
% Created By: Satoshi MURATA (1),  satoshi-m@atr.jp  09/02/27
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/05/08
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Check args:
if exist('hFile','var')==0 || isempty(hFile)
    error('''hFile'' must be specified');
elseif ~isnumeric(hFile)
    error('''hFile'' must be double-type');
elseif ~isfloat(hFile)
    hFile = double(hFile);
end

if exist('EntityID','var')==0 || isempty(EntityID)
%    error('''EntityID'' must be specified');
    warning('''EntityID'' isn''t specified. Get information from all entities');
    EntityID = [];
elseif ~isnumeric(EntityID)
    error('''EntityID'' must be numeric-type');
elseif ~isempty(find(EntityID<1,1))
    warning('''EntityID'' has too small number');
end


%% Get file-information:
nsFileInfo = ns_GetFileInfo(hFile);

if isempty(EntityID)
    EntityID = 1:nsFileInfo.EntityCount;
elseif ~isempty(find(EntityID>nsFileInfo.EntityCount,1))
    warning('''EntityID'' has too large number');
end


%% Get ns_SEGMENTINFO:
nsSEGMENTINFO_cell = cell(length(EntityID),5);
for ite=1:min(max(EntityID),nsFileInfo.EntityCount)
    nsTagElement = ns_ReadTagElement(hFile);
    
    ind = find(EntityID==ite);
    if isempty(ind)
        fseek(hFile, nsTagElement.ElemLength, 'cof');
    else
        if nsTagElement.ElemType~=3         % ns_ENTITY_SEGMENT = 3
            warning('EntityID:%d isn''t ''Segment Entity''', ite);
            fseek(hFile, nsTagElement.ElemLength, 'cof');
        else
            fseek(hFile, 32+4*2, 'cof');    % skip 'ns_ENTITYINFO'
            nsSEGMENTINFO_cell(ind,:) = struct2cell(ns_ReadSegmentInfo(hFile))';
            fseek(hFile, nsTagElement.ElemLength-(32+4*2)-(4*3+8+32), 'cof');
        end
    end
end

nsSegmentInfo = cell2struct(nsSEGMENTINFO_cell,...
                           {'SourceCount','MinSampleCount','MaxSampleCount','SampleRate','Units'},...
                           2);





%% ----------------------------------------------------------------------------
function nsSegmentInfo = ns_ReadSegmentInfo(hFile)


nsSegmentInfo = struct(...
    'SourceCount',      fread(hFile,  1, 'uint32'),...
    'MinSampleCount',   fread(hFile,  1, 'uint32'),...
    'MaxSampleCount',   fread(hFile,  1, 'uint32'),...
    'SampleRate',       fread(hFile,  1, 'double'),...
    'Units',            fread(hFile, 32, 'uint8=>char')'...
);

nsSegmentInfo = ns_InfoTrim(nsSegmentInfo);
