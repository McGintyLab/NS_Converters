function ChInfo = ns_GetChInfo(hFile)
% Retrieves channel information
% ChInfo = ns_GetChInfo(hFile)
%
% Inputs:
%   hFile  - handle/identification number to an open file
% Outputs:
%   ChInfo - channel information
%
% Created By: Satoshi MURATA (1),  satoshi-m@atr.jp  11/12/12
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/05/08
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


ChInfo = [];

%% Check args:
if exist('hFile','var')==0 || isempty(hFile)
    error('''hFile'' must be specified');
elseif ~isnumeric(hFile)
    error('''hFile'' must be double-type');
elseif ~isfloat(hFile)
    hFile = double(hFile);
end


%% Get file-information:
nsFileInfo = ns_GetFileInfo(hFile);

fpath='';

%% Get ChInfo:
for ite=1:nsFileInfo.EntityCount
    nsTagElement = ns_ReadTagElement(hFile);
    
    if nsTagElement.ElemType~=5     % ns_INFO_FILE = 5
        fseek(hFile, nsTagElement.ElemLength, 'cof');
    else
        data = fread(hFile, nsTagElement.ElemLength);
        dirName = strcat('chxml_', num2str(int32(100000*rand)));
        mkdir(dirName);
        fpath = strcat(dirName,'/chInfo.xml');
        zfpath = strcat(dirName,'/chInfo.xml.zip');
        fid  = fopen(zfpath,'wb');
        fwrite(fid, data);
        fclose(fid);
        gunzip(zfpath);
        break;
    end
end

if  strcmpi(fpath,'')
    warning('This file doesn''t contain the chInfo');
    return;
end
xml = parseXML(fpath);
rmdir(dirName,'s');

if ~strcmpi(xml.Name,'chInfo')
    warning('chInfo of this file is wrong');
    return;
end

for itc=1:length(xml.Children)
    ChInfo(itc).chNum = xml.Children(itc).Attributes.Value;
    for itf=1:length(xml.Children(itc).Children)
        if ~isempty(xml.Children(itc).Children(itf).Children)
            ChInfo(itc).(xml.Children(itc).Children(itf).Name) =  xml.Children(itc).Children(itf).Children.Data;
        end
    end
end

