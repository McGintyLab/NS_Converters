function inf_str = ns_InfoTrim(inf_str)
% delete non-important space from string field of 'inf_str'
%
% Created By: Satoshi MURATA (1),  satoshi-m@atr.jp  09/11/11
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/05/08
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


fname = fieldnames(inf_str);
for itf=1:length(fname)
    if ischar(inf_str.(fname{itf}))
        inf_str.(fname{itf}) = strtrim(inf_str.(fname{itf}));
    end
end

