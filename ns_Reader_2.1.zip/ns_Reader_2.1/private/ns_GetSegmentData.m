function [TimeStamp, Data, SampleCount, UnitID] = ns_GetSegmentData(hFile, EntityID, Index)
% Retrieves segment data by index
% [TimeStamp, Data, SampleCount, UnitID] = ns_GetSegmentData(hFile, EntityID, Index)
%
% Inputs:
%   hFile       - handle/identification number to an open file
%   EntityID    - identification number of the entity in the data file
%   Index       - index number of the requested Segment data item
% Outputs:
%   TimeStamp   - time stamp of the requested Segment data item
%   Data        - variable to receive the requested data
%   SampleCount - number of samples returned in the data variable
%   UnitID      - unit classification code for the Segment Entity
%
% Created  By: Satoshi MURATA (1),  satoshi-m@atr.jp  09/02/25
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  11/03/30
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/05/08
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Check args:
if exist('hFile','var')==0 || isempty(hFile)
    error('''hFile'' must be specified');
elseif ~isnumeric(hFile)
    error('''hFile'' must be double-type');
elseif ~isfloat(hFile)
    hFile = double(hFile);
end

if exist('EntityID','var')==0 || isempty(EntityID)
%    error('''EntityID'' must be specified');
    warning('''EntityID'' isn''t specified. Get data from all entities');
    EntityID = [];
elseif ~isnumeric(EntityID)
    error('''EntityID'' must be numeric-type');
elseif ~isempty(find(EntityID<1,1))
    warning('''EntityID'' has too small number');
end

if exist('Index','var')==0 || isempty(Index)
%    error('''Index'' must be specified');
    warning('''Index'' isn''t specified. Get data from all indexes');
    Index = [];
elseif ~isnumeric(Index)
    error('''Index'' must be numeric-type');
elseif Index<0
    warning('''Index'' must be >=0. Get data from all indexes');
    Index = [];
end


%% Get file-information:
nsFileInfo = ns_GetFileInfo(hFile);

if isempty(EntityID)
    EntityID = 1:nsFileInfo.EntityCount;
elseif ~isempty(find(EntityID>nsFileInfo.EntityCount,1))
    warning('''EntityID'' has too large number');
end


%% Get Segment Data:
TimeStamp   = cell(length(EntityID),1);
Data        = cell(length(EntityID),1);
SampleCount = cell(length(EntityID),1);
UnitID      = cell(length(EntityID),1);
Index_org   = Index;
for ite=1:min(max(EntityID),nsFileInfo.EntityCount)
    nsTagElement = ns_ReadTagElement(hFile);
    
    ind = find(EntityID==ite);
    if isempty(ind)
        fseek(hFile,nsTagElement.ElemLength,'cof');
    else
        if nsTagElement.ElemType~=3         % ns_ENTITY_SEGMENT = 3
            warning('EntityID:%d isn''t ''Segment Entity''', ite);
            fseek(hFile,nsTagElement.ElemLength,'cof');
        else
            nsEntityInfo = ns_ReadEntityInfo(hFile);
           SourceCount = fread(hFile,1,'uint32');
           fseek(hFile,4+4+8+32,'cof');
           if isempty(Index)
               Index = 1:nsEntityInfo.ItemCount;
           elseif ~isempty(find(Index>nsEntityInfo.ItemCount,1))
               warning('''Index'' has too large number');
           end
           
           for its=1:SourceCount
               fseek(hFile,8+8+8+8+8+8+8+8+8+4+16+8+4+16+128,'cof');    % skip ns_SEGSOURCEINFO
           end

           TimeStamp{ind}   = zeros(length(Index),1);
           Data{ind}        = cell(length(Index),1);
           SampleCount{ind} = zeros(length(Index),1);
           UnitID{ind}      = zeros(length(Index),1);
           for its=1:nsEntityInfo.ItemCount
               ind_s = find(Index==its);
               if isempty(ind_s)
                   samplecount = fread(hFile,1,'uint32');
                   fseek(hFile,8+4+8*samplecount,'cof');
               else
                   [TimeStamp{ind}(ind_s), Data{ind}{ind_s}, SampleCount{ind}(ind_s), UnitID{ind}(ind_s)]...
                       = ns_ReadSegmentData(hFile);
               end
           end
        end
    end
    
    Index = Index_org;
end





%% ---------------------------------------------------------------
function [TimeStamp, Data, SampleCount, UnitID] = ns_ReadSegmentData(hFile)

SampleCount = fread(hFile,1,'uint32');
TimeStamp   = fread(hFile,1,'double');
UnitID      = fread(hFile,1,'uint32');

Data        = fread(hFile,SampleCount,'double');
