function nsNeuralHeader = ns_ModNeuralHeader(chInfo, entityInfo, neuralInfo)
% Modify neural data header
% nsNeuralHeader = ns_ModNeuralHeader(chInfo,neuralInfo)
%
% Inputs:
%   chInfo        - struct - information of the channel
%   entityInfo        - struct - NSN header information of the entity (ns_ENTITYINFO)
%   neuralInfo        - struct - NSN header information of the entity (ns_NEURALINFO)
% Outputs:
%   nsNeuralHeader - struct - data header for neural entity
%
% Created By: Keiji HARADA (1),  kharada@atr.jp  12/04/13
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/04/25
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/05/08
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/06/27
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

if isfield(chInfo, 'chType')
    nsNeuralHeader.chType = chInfo.chType;
else
    nsNeuralHeader.chType = 'undefined';
end

if isfield(chInfo, 'comment')
    nsNeuralHeader.comment = chInfo.comment;
else
    nsNeuralHeader.comment = '';
end

if isfield(chInfo, 'chName')
    nsNeuralHeader.title = chInfo.chName;
else
    nsNeuralHeader.title = entityInfo.EntityLabel;
end

nsNeuralHeader.neuroshareType = entityInfo.EntityType;

nsNeuralHeader.description = neuralInfo.ProbeInfo;
nsNeuralHeader.sourceId = neuralInfo.SourceEntityID;
nsNeuralHeader.unitId = neuralInfo.SourceUnitID;
