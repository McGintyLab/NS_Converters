function [ContCount, StartTime, Data] = ns_GetAnalogData(hFile, EntityID, StartIndex, IndexCount)
% Retrieves analog data by index
% [ContCount, Data] = ns_GetAnalogData(hFile, EntityID, StartIndex, IndexCount)
%
% Inputs:
%   hFile      - handle/identification number to an open file
%   EntityID   - identification number of the Analog Entity in the data file
%   StartIndex - starting index number of the analog data item
%   IndexCount - number of analog values to retrieve
% Outputs:
%   ContCount  - number of continuous data values starting with
%   StartTime    - array of double start time
%   Data       - array of double precisionvalues to receive the analog data
%
% Created By: Satoshi MURATA (1),  satoshi-m@atr.jp  09/02/25
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/04/10
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Check args:
if exist('hFile','var')==0 || isempty(hFile)
    error('''hFile'' must be specified');
elseif ~isnumeric(hFile)
    error('''hFile'' must be double-type');
elseif ~isfloat(hFile)
    hFile = double(hFile);
end

if exist('EntityID','var')==0 || isempty(EntityID)
%    error('''EntityID'' must be specified');
    warning('''EntityID'' isn''t specified. Get data from all entities');
    EntityID = [];
elseif ~isnumeric(EntityID)
    error('''EntityID'' must be numeric-type');
elseif ~isempty(find(EntityID<1,1))
    warning('''EntityID'' has too small number');
end

if exist('StartIndex','var')==0 || isempty(StartIndex)
%    error('''Index'' must be specified');
    warning('''StartIndex'' isn''t specified. Get data from first');
    StartIndex = 1;
elseif ~isnumeric(StartIndex)
    error('''StartIndex'' must be numeric-type');
elseif StartIndex<0
    warning('''StartIndex'' must be >= 0. Get data from first');
    StartIndex = 1;
end

if exist('IndexCount','var')==0 || isempty(IndexCount)
%    error('''IndexCount'' must be specified');
    warning('''IndexCount'' isn''t specified. Get data to end');
    IndexCount = [];
elseif ~isnumeric(IndexCount)
    error('''IndexCount'' must be numeric-type');
elseif IndexCount<0
    warning('''IndexCount'' must be >=0. Get data to end');
    IndexCount = [];
end


%% Get file-information:
nsFileInfo = ns_GetFileInfo(hFile);

if isempty(EntityID)
    EntityID = 1:nsFileInfo.EntityCount;
elseif ~isempty(find(EntityID>nsFileInfo.EntityCount,1))
    warning('''EntityID'' has too large number');
end


%% Get Analog Data:
ContCount      = cell(length(EntityID),1);
StartTime      = cell(length(EntityID),1);
Data           = cell(length(EntityID),1);
IndexCount_org = IndexCount;
for ite=1:min(max(EntityID),nsFileInfo.EntityCount)
    nsTagElement = ns_ReadTagElement(hFile);
    
    ind = find(EntityID==ite);
    if isempty(ind)
        fseek(hFile,nsTagElement.ElemLength,'cof');
    else
        if nsTagElement.ElemType~=2     % ns_ENTITY_ANALOG = 2
            warning('EntityID:%d isn''t ''Analog Entity''', ite);
            fseek(hFile,nsTagElement.ElemLength,'cof');
        else
            nsEntityInfo = ns_ReadEntityInfo(hFile);
            if isempty(IndexCount)
                IndexCount = nsEntityInfo.ItemCount - StartIndex + 1;
            elseif StartIndex+IndexCount-1>nsEntityInfo.ItemCount
                warning('''IndexCount'' has too large number');
                IndexCount = nsEntityInfo.ItemCount - StartIndex + 1;
            end
            fseek(hFile,8+8+8+16+8+8+8+8+8+8+4+16+8+4+16+128,'cof');    % skip ns_ANALOGINFO
            [ContCount{ind}, StartTime{ind}, Data{ind}] = ns_ReadAnalogData(hFile,StartIndex,IndexCount);
        end
    end
    
    IndexCount = IndexCount_org;
end





%% ---------------------------------------------------------------
function [ContCount, StartTime, Data] = ns_ReadAnalogData(hFile,StartIndex,IndexCount)

ContCount = [];
num_read  = 0;
row_Count =1;
while IndexCount>num_read
    
    % TimeStamp -> StartTime
    st = fread(hFile,1,'double');
    StartTime(row_Count) = st;

    % DataCount
    dc = fread(hFile,1,'uint32');
    DataCount(row_Count) = dc;
    
    if StartIndex>dc
        fseek(hFile,8*dc,'cof');
        StartIndex = StartIndex - DataCount;
        continue;
    end
    
    temp = fread(hFile,dc,'double');
    if IndexCount>=DataCount-StartIndex+1
        tempData{row_Count}(1:1+dc-StartIndex) = temp(StartIndex:end);
    else
        tempData{row_Count}(1:IndexCount)  = temp(StartIndex:StartIndex+IndexCount-1);
    end
    num_read = num_read + dc - StartIndex + 1;
    
    if num_read>1 && isempty(ContCount)
        ContCount = dc - StartIndex + 1;
        if ContCount>IndexCount
            ContCount = IndexCount;
        end
    end
    
    StartIndex = 1;
    row_Count = row_Count+1;
end

row_Count = row_Count -1;
Data = NaN(row_Count, max(DataCount));

for ii = 1:row_Count
    if tempData{ii}(:) ~= NaN
        for jj = 1:length(tempData{ii})
            Data(ii,jj) = tempData{ii}(jj);
        end
    end
end

StartTime = StartTime';





