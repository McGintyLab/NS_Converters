function Data = ns_GetNeuralData(hFile, EntityID, StartIndex, IndexCount)
% Retrieves neural event data by index
% Data = ns_GetNeuralData(hFile, EntityID, StartIndex, IndexCount)
%
% Inputs:
%   hFile      - handle/identification number to an open file
%   EntityID   - identification number of the entity in the data file
%   StartIndex - first index number of the requested Neural Events timestamp
%   IndexCount - number of timestamps to retrieve
% Outputs:
%   Data       - array of double precision timestamps
%
% Created By: Satoshi MURATA (1),  satoshi-m@atr.jp  09/02/25
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/05/08
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Check args:
if exist('hFile','var')==0 || isempty(hFile)
    error('''hFile'' must be specified');
elseif ~isnumeric(hFile)
    error('''hFile'' must be double-type');
elseif ~isfloat(hFile)
    hFile = double(hFile);
end

if exist('EntityID','var')==0 || isempty(EntityID)
%    error('''EntityID'' must be specified');
    warning('''EntityID'' isn''t specified. Get data from all entities');
    EntityID = [];
elseif ~isnumeric(EntityID)
    error('''EntityID'' must be numeric-type');
elseif ~isempty(find(EntityID<1,1))
    warning('''EntityID'' has too small number');
end

if exist('StartIndex','var')==0 || isempty(StartIndex)
%    error('''Index'' must be specified');
    warning('''StartIndex'' isn''t specified. Get data from first');
    StartIndex = 1;
elseif ~isnumeric(StartIndex)
    error('''StartIndex'' must be numeric-type');
elseif StartIndex<0
    warning('''StartIndex'' must be >= 0. Get data from first');
    StartIndex = 1;
end

if exist('IndexCount','var')==0 || isempty(IndexCount)
%    error('''IndexCount'' must be specified');
    warning('''IndexCount'' isn''t specified. Get data to end');
    IndexCount = [];
elseif ~isnumeric(IndexCount)
    error('''IndexCount'' must be numeric-type');
elseif IndexCount<0
    warning('''IndexCount'' must be >=0. Get data to end');
    IndexCount = [];
end


%% Get file-information:
nsFileInfo = ns_GetFileInfo(hFile);

if isempty(EntityID)
    EntityID = 1:nsFileInfo.EntityCount;
elseif ~isempty(find(EntityID>nsFileInfo.EntityCount,1))
    warning('''EntityID'' has too large number');
end


%% Get Neural Data:
Data           = cell(length(EntityID),1);
IndexCount_org = IndexCount;
for ite=1:min(max(EntityID),nsFileInfo.EntityCount)
    nsTagElement = ns_ReadTagElement(hFile);
    
    ind = find(EntityID==ite);
    if isempty(ind)
        fseek(hFile,nsTagElement.ElemLength,'cof');
    else
        if nsTagElement.ElemType~=4     % ns_ENTITY_NEURAL = 4
            warning('EntityID:%d isn''t ''Neural Entity''', ite);
            fseek(hFile,nsTagElement.ElemLength,'cof');
        else
            nsEntityInfo = ns_ReadEntityInfo(hFile);
            if isempty(IndexCount)
                IndexCount = nsEntityInfo.ItemCount - StartIndex + 1;
            elseif StartIndex+IndexCount-1>nsEntityInfo.ItemCount
                warning('''IndexCount'' has too large number');
                IndexCount = nsEntityInfo.ItemCount - StartIndex + 1;
            end
            fseek(hFile,4+4+128,'cof');     % skip ns_NEURALINFO
            Data{ind} = ns_ReadNeuralData(hFile,StartIndex,IndexCount);
        end
    end
    
    IndexCount = IndexCount_org;
end





%% ---------------------------------------------------------------
function Data = ns_ReadNeuralData(hFile, StartIndex, IndexCount)

temp = fread(hFile,StartIndex+IndexCount-1,'double');
Data = temp(StartIndex:StartIndex+IndexCount-1);
