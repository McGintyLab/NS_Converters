function nsSegmentHeader = ns_ModSegmentHeader(chInfo, entityInfo, segmentInfo, segSourceInfo)
% Modify segment data header
% nsSegmentHeader = ns_ModSegmentHeader(chInfo,segmentInfo, segSourceInfo)
%
% Inputs:
%   chInfo        - struct - information of the channel
%   entityInfo        - struct - NSN header information of the entity (ns_ENTITYINFO)
%   segmentInfo        - struct - NSN header information of the entity (ns_SEGMENTINFO)
%   segSourceInfo        - struct - NSN header information of the entities (ns_SEGSOURCEINFO)
% Outputs:
%   nsSegmentHeader - struct - data header for segment entity
%
% Created By: Keiji HARADA (1),  kharada@atr.jp  12/04/19
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/04/25
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/05/08
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/06/27
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

if isfield(chInfo, 'chType')
    nsSegmentHeader.chType = chInfo.chType;
else
    nsSegmentHeader.chType = 'undefined';
end

if isfield(chInfo, 'comment')
    nsSegmentHeader.comment = chInfo.comment;
else
    nsSegmentHeader.comment = '';
end

if isfield(chInfo, 'chName')
    nsSegmentHeader.title = chInfo.chName;
else
    nsSegmentHeader.title = entityInfo.EntityLabel;
end

nsSegmentHeader.neuroshareType = entityInfo.EntityType;

nsSegmentHeader.unitOfData = segmentInfo.Units;
nsSegmentHeader.samplingRate = segmentInfo.SampleRate;
nsSegmentHeader.headerBySource = cell(length(segSourceInfo),1);

segSourceLabel=cell(1,length(segSourceInfo));
for ii = 1:length(segSourceInfo)
    segSourceLabel{ii} = sprintf('source%d', ii);
end

for jj = 1:length(segSourceInfo)
    sh.locationX      = segSourceInfo(jj).LocationX;
    sh.locationY      = segSourceInfo(jj).LocationY;
    sh.locationZ      = segSourceInfo(jj).LocationZ;
    sh.locationUserDef      = segSourceInfo(jj).LocationUser;
    sh.highFreqCutoff        = segSourceInfo(jj).HighFreqCorner;
    sh.highFreqCutoffOrder = segSourceInfo(jj).HighFreqOrder;
    sh.highFreqCutoffFilterType        = segSourceInfo(jj).HighFilterType;
    sh.lowFreqCutoff        = segSourceInfo(jj).LowFreqCorner;
    sh.lowFreqCutoffOrder = segSourceInfo(jj).LowFreqOrder;
    sh.lowFreqCutoffFilterType        = segSourceInfo(jj).LowFilterType;
    sh.description          = segSourceInfo(jj).ProbeInfo;

    nsSegmentHeader.headerBySource{jj} = sh;
    clear sh;
        
end

nsSegmentHeader.headerBySource = cell2struct(nsSegmentHeader.headerBySource, segSourceLabel, 1);
