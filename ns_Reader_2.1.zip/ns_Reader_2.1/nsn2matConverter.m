function nsn2matConverter( neuroshareFilePath )
% Convert neuroshare file to mat variables.(save as mat file.)
%
% Inputs:
%   neuroshareFilePath - [char] - NSN format filename with path;
%
% Outputs:
%
% Created By : Keiji HARADA (1),  kharada@atr.jp  12/04/23
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/04/25
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

%% Check args:
if exist('neuroshareFilePath','var')==0 || isempty(neuroshareFilePath)
    error('''neuroshareFilePath'' must be specified');
elseif ~ischar(neuroshareFilePath)
    error('''neuroshareFilePath'' must be char-type');
end

% Get file name.
[pathstr, name, ext] = fileparts(neuroshareFilePath);
ext = '.mat';
filename = strcat(name,ext);
matFilePath = fullfile(pathstr, filename);

% Delete mat file if already exist.
warning off all;
delete(matFilePath);
warning on all;

% Convert neuroshare file to mat variables.
[chData, chHeader, fileInfo] = ns_Reader(neuroshareFilePath);

% Save as mat file.
save(matFilePath, 'chData', 'chHeader', 'fileInfo', '-v7.3');

end
