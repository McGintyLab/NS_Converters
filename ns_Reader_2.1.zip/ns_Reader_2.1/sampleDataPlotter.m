%% SamleDataPlotter
% This script do below.
%
% 1. Read Sample data (Use Only TIME SERIES 1ch.)
% 2. Re-align Sample data to plot data
% 3. Plot Sample data
%
% If success, you can see sample data as plot window. [X - time, Y - value]
%
% Created By : Keiji HARADA (1),  kharada@atr.jp  12/04/23
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% 1. Read Sample data (Use Only TIME SERIES 1ch.)
[AllChData, AllChDataHeader, FileInfo] = ns_Reader('sampleData/sampleneurosharefile.nsn');
oneChData = AllChData.ch1;
oneChDataHeader = AllChDataHeader.ch1;

% 2. Re-align Sample data to plot data
% time(n) = startTime + (n-1) / samplingRate   [datacount n = 1,2,3...]
% dataHeader has samplingRate of the data (if neuroshareType was 2 [2 means TIME SERIES data] ).
if oneChDataHeader.neuroshareType == 2

    samplingRate = oneChDataHeader.samplingRate;
    time = NaN(1, length(oneChData.value));
    for jj =1:length(oneChData.value)
        time(jj) = oneChData.startTime + (jj-1) / samplingRate;
    end
    
else
    error('Sample Data is not TIME SERIES data. Quit to show.');
end

% 3. Plot Sample data
% dataHeader has unit of data.
plot(time, oneChData.value);
xlabel('time [sec]');
ylabel(strcat('value ', oneChDataHeader.unitOfData));
title(oneChDataHeader.title);
