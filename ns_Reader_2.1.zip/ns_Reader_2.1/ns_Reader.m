function [chData, chHeader, fileInfo] = ns_Reader(filename)
% reads data from NSN format file
% [chData, chHeader, fileInfo] = ns_Reader(filename)
%
% Inputs:
%   filename - [char]<OPTIONAL> - NSN format filename with path;
%              if absent, you should select by dialog
% Outputs:
%   chData     - [1*1 struct] - neural data and behavioral data
%              including 'ch1', 'ch2', ...'chn'
%   chHeader - [1*1 struct] - information of each channel which include with the NSN header data
%              including 'ch1', 'ch2', ...'chn'
%   file_inf - [1*1 struct] - information of the NSN format file
%              including 'title', 'date'  and 'description'
%
%   *** n : number of channels(entities) except for 'chInfo'.
%
% Created By : Keiji HARADA (1),  kharada@atr.jp  12/04/23
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/06/27
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


%% Check and get args:
if ~exist('filename','var') || isempty(filename)
    [file, path] = uigetfile({'*.nsn','NeuroshareNative format file (*.nsn)'}, 'Select NSN file');
    if isequal(file,0)
        error('NSN file should be specified');
    end
    filename = fullfile(path, file);
end


%% Read NSN file:
warning('off');

% open file:
hFile = ns_OpenFile(filename);

% check file:
nsFILEINFO = ns_GetFileInfo(hFile);
if isempty(strfind(nsFILEINFO.AppName,'SimpleConverter')) && isempty(strfind(nsFILEINFO.AppName,'ns_Converter'))...
        && isempty(strfind(nsFILEINFO.AppName,'ATR')) && isempty(strfind(nsFILEINFO.FileComment,'ATR'))
    warning('on');
    warning('This NSN file would not be made by ATR tools');
    warning('off');
end

% get date:
fileInfo.date = sprintf('%04d/%02d/%02d %02d:%02d:%02d',...
    nsFILEINFO.Time_Year, nsFILEINFO.Time_Month, nsFILEINFO.Time_Day,...
    nsFILEINFO.Time_Hour, nsFILEINFO.Time_Min,   nsFILEINFO.Time_Sec);

% get description:
fileInfo.title       = nsFILEINFO.FileType;
fileInfo.description = nsFILEINFO.FileComment;

% initialize:
nsENTITYINFO = ns_GetEntityInfo(hFile);
num_ch       = length(nsENTITYINFO);
chData         = cell(num_ch, 1);
chHeader        = cell(num_ch, 1);
chInfo = cell(num_ch, 1);
eventCount=0;
analogCount=0;
segmentCount=0;
neuraleventCount=0;
chInfoExistence=false;

% get data:
nsANALOGINFO              = ns_GetAnalogInfo(hFile);
[nouse, TSAnalog, AnalogData]       = ns_GetAnalogData(hFile);
nsNEURALINFO              = ns_GetNeuralInfo(hFile);
NeuralData                = ns_GetNeuralData(hFile);
nsEVENTINFO               = ns_GetEventInfo(hFile);
[TStamp, EventData]       = ns_GetEventData(hFile);
nsSEGMENTINFO             = ns_GetSegmentInfo(hFile);
nsSEGSOURCEINFO           = ns_GetSegmentSourceInfo(hFile);
[TSseg, SegData, sc, UID] = ns_GetSegmentData(hFile);


for ite=1:length(nsENTITYINFO)
    
    if isempty(nsENTITYINFO(ite).EntityType)    % ns_INFO_FILE
        chInfo   = ns_GetChInfo(hFile)';
        chEntNum = ite;
        chInfoExistence=true;
        continue;
    end
    if nsENTITYINFO(ite).EntityType==1
        eventCount=eventCount+1;
    elseif nsENTITYINFO(ite).EntityType==2
        analogCount=analogCount+1;
    elseif nsENTITYINFO(ite).EntityType==3
        segmentCount=segmentCount+1;
    elseif nsENTITYINFO(ite).EntityType==4
        neuraleventCount=neuraleventCount+1;
    end
end

%   Realign chInfo's order as same as nsENTITYINFO
if chInfoExistence
    eventCounter=0;
    analogCounter=0;
    segmentCounter=0;
    neuraleventCounter=0;
    for jj=1:length(chInfo)
        
        if ischar(chInfo(jj).neuroshareType);
            nT=str2num(chInfo(jj).neuroshareType);
        else
            nT=chInfo(jj).neuroshareType;
        end
        
        if nT==1
            %   Event
            eventCounter=eventCounter+1;
            tempE(eventCounter)=chInfo(jj);
        elseif nT==2
            %   Analog
            analogCounter=analogCounter+1;
            tempA(analogCounter)=chInfo(jj);
        elseif nT==3
            %   Segment
            segmentCounter=segmentCounter+1;
            tempS(segmentCounter)=chInfo(jj);
        elseif nT==4
            %   NeuralEvent
            neuraleventCounter=neuraleventCounter+1;
            tempN(neuraleventCounter)=chInfo(jj);
        else
            %   Noting to do.
        end
    end
    
    if eventCount > 0
        tempMarge(1:eventCount)=tempE(:);
    end
    
    if analogCount > 0
        tempMarge(eventCount+1:eventCount+analogCount)=tempA(:);
    end
    
    if segmentCount > 0
        tempMarge(eventCount+analogCount+1:eventCount+analogCount+segmentCount)=tempS(:);
    end
    
    if neuraleventCount > 0
        tempMarge(eventCount+analogCount+segmentCount+1:eventCount+analogCount+segmentCount+neuraleventCount)=tempN(:);
    end
    
    chInfo(:,1)=tempMarge(1,:);
end
clear nT tempMarge tempE tempA tempS tempN;
clear eventCount analogCount segmentCount neuraleventCount;
clear eventCounter analogCounter segmentCounter neuraleventCounter;

for ite=1:length(nsENTITYINFO)
    
    if isempty(nsENTITYINFO(ite).EntityType)    % ns_INFO_FILE
        continue;
    end
    
    switch nsENTITYINFO(ite).EntityType
        
        case 1      % Event Entity (EVENT)
            % header
            chHeader{ite} = ns_ModEventHeader(chInfo(ite), nsENTITYINFO(ite), nsEVENTINFO(ite));
            
            % data
            chData{ite}.timeStamp = TStamp{ite}';
            chData{ite}.value     = EventData{ite}';
            if nsEVENTINFO(ite).EventType~=0    % 0: text
                chData{ite}.value = cell2mat(chData{ite}.value);
            end
            
        case 2      % Analog Entity (TIME SERIES)
            % header
            chHeader{ite} = ns_ModAnalogHeader(chInfo(ite), nsENTITYINFO(ite), nsANALOGINFO(ite));
            
            % data
            chData{ite}.startTime    = TSAnalog{ite};
            chData{ite}.value           = AnalogData{ite};
            
        case 3      % Segment Entity
            % header
            chHeader{ite} = ns_ModSegmentHeader(chInfo(ite), nsENTITYINFO(ite), nsSEGMENTINFO(ite), nsSEGSOURCEINFO{ite});
            
            % data
            chData{ite}.startTime    = TSseg{ite};
            chData{ite}.unitId          = UID{ite};
            chData{ite}.value           = cell2mat(SegData{ite}')';
            
        case 4      % Neural Entity (SPIKE)
            % header
            chHeader{ite} = ns_ModNeuralHeader(chInfo(ite), nsENTITYINFO(ite), nsNEURALINFO(ite));
            
            % data
            chData{ite}.timeStamp           = NeuralData{ite}';
            
    end
end

ns_CloseFile(hFile);
warning('on');

if exist('chEntNum','var') && ~isempty(chEntNum)
    chData(chEntNum)   = [];
    chHeader(chEntNum)  = [];
    %   ch_inf(chEntNum) = [];
else
    chInfo = [];
end


% Cell 2 Struct
dataLabel=cell(1, length(chData));
dataHeaderLabel=cell(1, length(chHeader));
for kk=1:length(chData)
    dataLabel{kk}=sprintf('ch%d', kk);
end
for kk=1:length(chData)
    dataHeaderLabel{kk}=sprintf('ch%d', kk);
end


chData = cell2struct(chData,dataLabel,1);
chHeader = cell2struct(chHeader,dataHeaderLabel,1);
