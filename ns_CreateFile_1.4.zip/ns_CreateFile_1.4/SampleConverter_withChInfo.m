%	SCRIPT	Sample converte [with Channel Info] ( from dummy format data to Neuroshare )
%	FILE N.	SampleConverter_withChInfo.m
%	AUTHOR	K.Harada(ATR) 
%	DATE	2012/01/20
%
%	SampleConverter.m ( SC ) is a converter from dummy data to Neuroshare.
%	
%	Inputs of SC are dummy files on Input directory.
%	Output of SC is the Neuroshare file ( ***.nsn ). 
%   SC uses MATLAB Lib.[@ns_CreateFile] when converts input files.
%
%	If you want to use SC easily, see Tutorial below.
%	If you want to modify SC, see Guide below.
%
%   Enjoy it!
%
%	:::SC is based on GPL. You can modify this SC free.
%
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%	Tutorial
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%   If you want to use SC easily, do procedure below.
%
%	(1)
%		Set these on the same directory ( dir. A ).
%		[SampleConverter.m]             :	This file.
%		[folder : @ns_CreateFile]       :	MATLAB Lib.
%		[folder : InputFile]			:	Input directory. There are arbitrary format data files.
%											( If you want to see format, see below. )
%		[folder : OutputFile]			:	Output directory. '.nsn' file will be created here.
%
%	(2)
%		Start MATLAB, set dir. A as current directory.
%
%	(3)
%		Execute SampleConverter.
%		Creation of .nsn file is successful if ERROR messeage doesn't appear.
%
%	(4)
%		See OutputFile dir.
%		You can find 'Neuroshare_SampleData_001.nsn' file.
%
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%	Guide
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%   If you want to modify SC, these information will help you.
%
%	(1)
%       help {methodname} -- You can see how to use methods of [@ns_CreateFile] Lib.
%		Type it on Command Window [exam. : help ns_SetFileInfo]
%
%	(2)
%		copy and paste -- You can add anothor entity with copy and paste, please see comment below.
%
%	(3)
%		[ERROR] -- If you modify this source like this, the method(or SC itself) will return error value.
%
%	(4)
%		[WARNING] -- If you modify this source like this, the method(or SC itself) will display warning message. ( Return value is correct. )
%

%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%	SC source start
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	0.Initialize all
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%	Clear all.
clear all;
clear classes;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	1.Define file i/o
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%	Set output directory.
%outputDir = 'C:/NoExistDirectory';      	%	[ERROR]     You can not set output directory which doesn't exist.
%outputDir = 'C:\tmp\OutputFile';			%	[OK]        Absolute path with using \ as parser.(fullfile[MATLAB function])
%outputDir = 'C:/tmp/OutputFile';			%	[OK]    	Absolute path with using / as parser.(fullfile[MATLAB function])
%outputDir = './OutputFile';				%	[OK]        Relative path
outputDir = 'OutputFile';					%	[OK]        Relative path

%	Define output filename.
%nsFile = fullfile( outputDir, 'Neuroshare_SampleData_001.klo' );		%	[ERROR] Wrong extension
%nsFile = fullfile( outputDir, 'Neuroshare_SampleData_001.NSN' );		%	[ERROR]	Wrong extension
%nsFile = fullfile( outputDir, 'Neuroshare_SampleData_001.nsn' );		%	[OK]	Correct extension
nsFile = fullfile( outputDir, 'Neuroshare_SampleData_WithChInfo001' );			%	[OK]	No extension, system supplements extension '.nsn'

%	Set input directory.
%inputDir = 'C:/NoExistDirectory';      	%	[ERROR]     You can not set input directory which doesn't exist.
%inputDir = 'C:\tmp\InputFile';     		%	[OK]        Absolute path with using \ as parser.(fullfile[MATLAB function])
%inputDir = 'C:/tmp/InputFile';         	%	[OK]    	Absolute path with using / as parser.(fullfile[MATLAB function])
%inputDir = './InputFile';                  %	[OK]        Relative path
inputDir = 'InputFile';

%	Define EVENT entity file.
FileOfEvent_001 = fullfile( inputDir, 'SampleData_001.event' );
FileOfEvent_002 = fullfile( inputDir, 'SampleData_002.event' );

%	Define NEURALEVENT entity file.
FileOfNeuralEvent_001 = fullfile( inputDir, 'SampleData_001.neuralevent' );
FileOfNeuralEvent_002 = fullfile( inputDir, 'SampleData_002.neuralevent' );

%	Define ANALOG entity file.
FileOfAnalog_001 = fullfile( inputDir, 'SampleData_001.analog' );
FileOfAnalog_002 = fullfile( inputDir, 'SampleData_002.analog' );

%	Define SEGMENT entity file.
FileOfSegment_001 = fullfile( inputDir, 'SampleData_001.segment' );
FileOfSegment_002 = fullfile( inputDir, 'SampleData_002.segment' );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	2.Create Neuroshare file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%	Delete all Neuroshare file in the output directory.
warning('off');
delete(fullfile(outputDir,'*.nsn'));
warning('on');

%	Create nsObj which has Neuroshare header info.
%[ns_Result nsObj] = ns_CreateFile( 213 );			%	[ERROR] Wrong type of input arg. Return ns_WRONGLABEL and ''(Blank).
[ns_Result nsObj] = ns_CreateFile( nsFile );		%	[OK]	If nsFile's extension is not '.nsn' or ''(Blank), then return ns_WRONGLABEL.
if 0 ~= ns_Result
	return;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	3.Modify File Infomation Header[ ns_FILEINFO ]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   You can modify this with using Get/Set method.
%	:::Important : You can NOT modify value directly! Like this ... ( nsObj.ns_FILEINFO.szFileType = 'gobbledygook')

%	How to use ...
%		1.Get latest header (ns_FILEINFO) with using GET method.
%		2.Modify members you want.
%		3.Set new header with using SET method.
%
%		:::Important : You can not modify members written [Can not edit].

%	Get header.
[ ns_Result nsa_FILEINFO ] = ns_GetFileInfo( nsObj );
if 0 ~= ns_Result
	return;
end

%	Modify members.
%	Comment out members which you do not want to modify.
nsa_FILEINFO.szFileType				 = 'ATR_Sample_Data';
%	[Can not edit] dwEntityCount.	:::For consistency of data. ref. ns_SetFileInfo Method
nsa_FILEINFO.dTimeStampResolution	 = 0.00015;
nsa_FILEINFO.dTimeSpan				 = 1368.796875;
nsa_FILEINFO.szAppName				 = 'ATR_Sample_Converter_V1.00';
nsa_FILEINFO.dwTime_Year			 = 2008;
nsa_FILEINFO.dwTime_Month			 = 2;
nsa_FILEINFO.dwTime_DayOfWeek		 = 2;
nsa_FILEINFO.dwTime_Day				 = 17;
nsa_FILEINFO.dwTime_Hour			 = 16;
nsa_FILEINFO.dwTime_Min				 = 15;
nsa_FILEINFO.dwTime_Sec				 = 25;
nsa_FILEINFO.dwTime_MilliSec		 = 100;
nsa_FILEINFO.szFileComment			 = 'Sample Extended Comment';
%nsa_FILEINFO.abc					 = 1234;		%	[ERROR] 	Wrong name of member. Set method returns ns_WRONGINFO.
%nsa_FILEINFO.szFileComment          = 1234;		%	[WARNING]	Wrong type of member. Set method returns ns_OK, but, the value still remain. 

%	Set header.
%[ ns_Result nsObj ] = ns_SetFileInfo( nsObj, nsa_FILEINFO.szAppName );		%	[ERROR]	Wrong type of input args. Return ns_WRONGINFO, nsObj.
[ ns_Result nsObj ] = ns_SetFileInfo( nsObj, nsa_FILEINFO );				%	[OK]	If nsa_FILEINFO includes wrong name of members, then return ns_WRONGINFO, nsObj.
if 0 ~= ns_Result
	return;
end

%	Clear nsa_FILEINFO
clear nsa_FILEINFO;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	4.Initialize Event Data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   Copy and paste from ED1 to ED2, if you want to add another event data.
%	ED1

%	Create event entity. ( Create new entity ID and initialize headers. )
%[ ns_Result nsObj EventID ] = ns_NewEventData( nsObj, 3200 );				%	[ERROR] Wrong type of input args. Return ns_WRONGLABEL, nsObj, ''(Blank).
%[ ns_Result nsObj EventID ] = ns_NewEventData( nsObj );					%	[OK]    Set ''(Blank) as ns_ENTITYINFO.szEntityLabel.
%[ ns_Result nsObj EventID ] = ns_NewEventData( nsObj, 'Event_Sample' );		%	[OK]	Set this label as ns_ENTITYINFO.szEntityLabel.
[ ns_Result nsObj EventID ] = ns_NewEventData( nsObj, 'Event_Sample', 'Stimulus', 'stimulus event ch01' );		%	[OK]	Set ns_ENTITYINFO.szEntityLabel, chType, chComment.
if 0 ~= ns_Result
	return;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	5.Read Event Data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%	Read Event Data
eventData = textread( FileOfEvent_001, '', 'delimiter', '\t', 'emptyvalue', NaN );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	6.Modify Event Entity Specific Infomation Header[ ns_EVENTINFO ]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%	Get header.
%[ ns_Result nsa_EVENTINFO ] = ns_GetEventInfo( nsObj, 1.2 );		%	[ERROR] Wrong type of ID. The ID should be 0 or natural number. Return ns_WRONGID and ''(Blank).
%[ ns_Result nsa_EVENTINFO ] = ns_GetEventInfo( nsObj, 90 );		%	[ERROR] Wrong value of ID. The EVENT{ID} should exist. Return ns_WRONGID and ''(Blank).
[ ns_Result nsa_EVENTINFO ] = ns_GetEventInfo( nsObj, EventID );	%	[OK]    Get nsa_EVENTINFO from ns_EVENTINFO.
if 0 ~= ns_Result
	return;
end

%	Modify members.
%	Comment out members which you do not want to modify.
	%	[Can not edit] dwEventType.   	:::For consistency of data. ref. ns_SetEventInfo Method
	%	[Can not edit] dwMinDataLength.	:::For consistency of data. ref. ns_SetEventInfo Method
	%	[Can not edit] dwMaxDataLength.	:::For consistency of data. ref. ns_SetEventInfo Method
nsa_EVENTINFO.szCSVDesc = 'sample_comment'; 
%nsa_EVENTINFO.abc = 'sample_comment';								%	[ERROR] 	Wrong name of member. Set method returns ns_WRONGINFO.
	
%	Set header.
%[ ns_Result nsObj ] = ns_SetEventInfo( nsObj, 1.1, nsa_EVENTINFO );					%	[ERROR] Wrong type of ID. The ID should be 0 or natural number. Return ns_WRONGID, nsObj.
%[ ns_Result nsObj ] = ns_SetEventInfo( nsObj, 80, nsa_EVENTINFO );						%	[ERROR] Wrong value of ID. The EVENT{ID} should exist. Return ns_WRONGID, nsObj.
%[ ns_Result nsObj ] = ns_SetEventInfo( nsObj, EventID, nsa_EVENTINFO.szCSVDesc );		%	[ERROR]	Wrong type of input args. Return ns_WRONGINFO, nsObj.
[ ns_Result nsObj] = ns_SetEventInfo( nsObj, EventID, nsa_EVENTINFO );					%	[OK]	If nsa_EVENTINFO includes wrong name of members, then return ns_WRONGINFO, nsObj.
if 0 ~= ns_Result
	return;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	7.Add Event Data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%	Add Event Data
for row = 1:size( eventData, 1 )
    Time  = eventData( row, 1 );
    Value = eventData( row, 2 );
    
	%	Add Event Data [ Write to the intermediate file and Update ns_EVENTINFO ]
	%[ ns_Result nsObj ] = ns_AddEventData( nsObj, 1.1, Time, Value );							%	[ERROR] Wrong type of ID. The ID should be 0 or natural number. Return ns_WRONGID, nsObj.
	%[ ns_Result nsObj ] = ns_AddEventData( nsObj, 85, Time, Value );							%	[ERROR] Wrong value of ID. The EVENT{ID} should exist. Return ns_WRONGID, nsObj.
	%[ ns_Result nsObj ] = ns_AddEventData( nsObj, EventID, cast( Time, 'char'), Value );		%	[ERROR] Wrong type of Data. Return ns_WRONGDATA, nsObj.
	[ ns_Result nsObj ] = ns_AddEventData( nsObj, EventID, Time, Value );						%	[OK]    If there is difference between type of Value and ever registed it, then ERROR. Return ns_WRONGDATA, nsObj.
	if 0 ~= ns_Result
		return;
	end
end

%	Clear Event Data
clear nsa_EVENTINFO;
clear eventData;
clear Time Value row;

%	ED2


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	8.Initialize Neural Event Data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   Copy and paste from NED1 to NED2, if you want to add another neural event data.
%	NED1

%	Create neural event entity. ( Create new entity ID and initialize headers. )
%[ ns_Result nsObj NeuralEventID ] = ns_NewNeuralEventData( nsObj, 3200 );					%	[ERROR] Wrong type of input args. Return ns_WRONGLABEL, nsObj, ''(Blank).
%[ ns_Result nsObj NeuralEventID ] = ns_NewNeuralEventData( nsObj );						%	[OK]    Set ''(Blank) as ns_ENTITYINFO.szEntityLabel.
%[ ns_Result nsObj NeuralEventID ] = ns_NewNeuralEventData( nsObj, 'NeuralEvent_Sample' );	%	[OK]	Set this label as ns_ENTITYINFO.szEntityLabel.
[ ns_Result nsObj NeuralEventID ] = ns_NewNeuralEventData( nsObj, 'NeuralEvent_Sample', 'SPIKE', 'probe No.02'  );	%	[OK]	Set ns_ENTITYINFO.szEntityLabel, chType, chComment.
if 0 ~= ns_Result
	return;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	9.Read Neural Event Data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%	Read Neural Event Data
neuralEventData = textread( FileOfNeuralEvent_001, '', 'delimiter', '\t', 'emptyvalue', NaN );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	10.Modify Neural Event Entity Specific Infomation Header[ ns_NEURALINFO ]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%	Get header.
%[ ns_Result nsa_NEURALINFO ] = ns_GetNeuralInfo( nsObj, 1.2 );         	%	[ERROR] Wrong type of ID. The ID should be 0 or natural number. Return ns_WRONGID and ''(Blank).
%[ ns_Result nsa_NEURALINFO ] = ns_GetNeuralInfo( nsObj, 90 );              %	[ERROR] Wrong value of ID. The NEURALEVENT{ID} should exist. Return ns_WRONGID and ''(Blank).
[ ns_Result nsa_NEURALINFO ] = ns_GetNeuralInfo( nsObj, NeuralEventID );	%	[OK]    Get nsa_NEURALINFO from ns_NEURALINFO.
if 0 ~= ns_Result
	return;
end

%	Modify members.
%	Comment out members which you do not want to modify.
nsa_NEURALINFO.dwSourceEntityID	 = 5; 
nsa_NEURALINFO.dwSourceUnitID	 = 0; 
nsa_NEURALINFO.szProbeInfo		 = 'sample_comment';
%nsa_NEURALINFO.abc				 = 0;										%	[ERROR] 	Wrong name of member. Set method returns ns_WRONGINFO.
	
%	Set header.
%[ ns_Result nsObj ] = ns_SetNeuralInfo( nsObj, 1.1, nsa_NEURALINFO );				%	[ERROR] Wrong type of ID. The ID should be 0 or natural number. Return ns_WRONGID, nsObj.
%[ ns_Result nsObj ] = ns_SetNeuralInfo( nsObj, 80, nsa_NEURALINFO );				%	[ERROR] Wrong value of ID. The EVENT{ID} should exist. Return ns_WRONGID, nsObj.
%[ ns_Result nsObj ] = ns_SetNeuralInfo( nsObj, NeuralEventID, nsa_NeuralINFO.abc );%	[ERROR]	Wrong type of input args. Return ns_WRONGINFO, nsObj.
[ ns_Result nsObj] = ns_SetNeuralInfo( nsObj, NeuralEventID, nsa_NEURALINFO );		%	[OK]	If nsa_NAURALINFO includes wrong name of members, then return ns_WRONGINFO, nsObj.
if 0 ~= ns_Result
	return;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	11.Add Neural Event Data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%	Add Event Data
for row = 1:size( neuralEventData, 1 )

	Time = neuralEventData( row, 1 );
	
	%	Add Neural Event Data [ Write to the intermediate file and Update ns_NEURALINFO ]
	%[ ns_Result nsObj ] = ns_AddNeuralEventData( nsObj, 1.1, Time );							%	[ERROR] Wrong type of ID. The ID should be 0 or natural number. Return ns_WRONGID, nsObj.
	%[ ns_Result nsObj ] = ns_AddNeuralEventData( nsObj, 80, Time );							%	[ERROR] Wrong value of ID. The EVENT{ID} should exist. Return ns_WRONGID, nsObj.
	%[ ns_Result nsObj ] = ns_AddNeuralEventData( nsObj, NeuralEventID, cast( Time, 'char' ) );	%	[ERROR] Wrong type of Data. Return ns_WRONGDATA, nsObj.
	[ ns_Result nsObj ] = ns_AddNeuralEventData( nsObj, NeuralEventID, Time );					%	[OK]
	if 0 ~= ns_Result
		return;
	end
end

%	Clear Neural Event Data
clear nsa_NEURALINFO;
clear neuralEventData;
clear Time row;

%	NED2


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	12.Initialize Analog Data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   Copy and paste from AD1 to AD2, if you want to add another neural event data.
%	AD1

%	Create analog entity. ( Create new entity ID and initialize headers. )
%[ ns_Result nsObj AnalogID ] = ns_NewAnalogData( nsObj, 3200 );				%	[ERROR] Wrong type of input args. Return ns_WRONGLABEL, nsObj, ''(Blank).
%[ ns_Result nsObj AnalogID ] = ns_NewAnalogData( nsObj );						%	[OK]    Set ''(Blank) as ns_ENTITYINFO.szEntityLabel.
%[ ns_Result nsObj AnalogID ] = ns_NewAnalogData( nsObj, 'Analog_Sample_1' );	%	[OK]	Set this label as ns_ENTITYINFO.szEntityLabel.
[ ns_Result nsObj AnalogID ] = ns_NewAnalogData( nsObj, 'Analog_Sample_1', 'ecog','V1_ch03' );	%	[OK]	Set ns_ENTITYINFO.szEntityLabel, chType, chComment.
if 0 ~= ns_Result
	return;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	13.Read Analog Data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%	Read Analog Data
analogData = textread( FileOfAnalog_001, '', 'delimiter', '\t', 'emptyvalue', NaN );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	14.Modify Analog Entity Specific Infomation Header[ ns_ANALOGINFO ]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%	Get header.
%[ ns_Result nsa_ANALOGINFO ] = ns_GetAnalogInfo( nsObj, 1.1 );				%	[ERROR] Wrong type of ID. The ID should be 0 or natural number. Return ns_WRONGID and ''(Blank).
%[ ns_Result nsa_ANALOGINFO ] = ns_GetAnalogInfo( nsObj, 60 );				%	[ERROR] Wrong value of ID. The ANALOG{ID} should exist. Return ns_WRONGID and ''(Blank).
[ ns_Result nsa_ANALOGINFO ] = ns_GetAnalogInfo( nsObj, AnalogID );			%	[OK]    Get nsa_ANALOGINFO from ns_ANALOGINFO.
if 0 ~= ns_Result
	return;
end

%	Modify members.
%	Comment out members which you do not want to modify.
nsa_ANALOGINFO.dSampleRate      = 20;
nsa_ANALOGINFO.dMinVal          = -10;				%	Min value.
                                                    %   This member will be set by methods below.
                                                    %   - ns_SetAnalogInfo - set it manually.
                                                    %   - ns_AddAnalogData - calculated it by data automatically.
                                                    %   Latest min val is adopted.

nsa_ANALOGINFO.dMaxVal          = 1;				%	Max value.
                                                    %   This member will be set by methods below.
                                                    %   - ns_SetAnalogInfo - set it manually.
                                                    %   - ns_AddAnalogData - calculated it by data automatically.
                                                    %   Latest max val is adopted.
nsa_ANALOGINFO.szUnits          = 'volt';
nsa_ANALOGINFO.dResolution      = 0.0015;
nsa_ANALOGINFO.dLocationX       = 0;
nsa_ANALOGINFO.dLocationY       = 1;
nsa_ANALOGINFO.dLocationZ       = 0.5;
nsa_ANALOGINFO.dLocationUser    = 0.5;
nsa_ANALOGINFO.dHighFreqCorner  = 0;
nsa_ANALOGINFO.dwHighFreqOrder  = 5;
nsa_ANALOGINFO.szHighFilterType = 'Highcomment'; 
nsa_ANALOGINFO.dLowFreqCorner   = 0;  
nsa_ANALOGINFO.dwLowFreqOrder   = 2;
nsa_ANALOGINFO.szLowFilterType  = 'Lowcomment';
nsa_ANALOGINFO.szProbeInfo      = 'comment'; 
%nsa_ANALOGINFO.abce            = 0.0015;				%	[ERROR] 	Wrong name of member. Set method returns ns_WRONGINFO.
%nsa_ANALOGINFO.szProbeInfo     = 1234;                 %	[WARNING]	Wrong type of member. Set method returns ns_OK, but, the value still remain. 

%	Set header.
%[ ns_Result nsObj ] = ns_SetAnalogInfo( nsObj, 1.1, nsa_ANALOGINFO );					%	[ERROR] Wrong type of ID. The ID should be 0 or natural number. Return ns_WRONGID, nsObj.
%[ ns_Result nsObj ] = ns_SetAnalogInfo( nsObj, 80, nsa_ANALOGINFO );					%	[ERROR] Wrong value of ID. The EVENT{ID} should exist. Return ns_WRONGID, nsObj.
%[ ns_Result nsObj ] = ns_SetAnalogInfo( nsObj, AnalogID, nsa_ANALOGINFO.dLocationX );	%	[ERROR]	Wrong type of input args. Return ns_WRONGINFO, nsObj.
[ ns_Result nsObj ] = ns_SetAnalogInfo( nsObj, AnalogID, nsa_ANALOGINFO );				%	[OK]	If nsa_ANALOGINFO includes wrong name of members, then return ns_WRONGINFO, nsObj.
if 0 ~= ns_Result
	return;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	15.Add Analog Data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%	Add Analog Data
for row = 1:size( analogData, 1 )
	
	Time = analogData(row,1);
	DummyValue = analogData(row,2:end);
	Value = DummyValue(find(~isnan(DummyValue)));

    %	Add Analog Data [ Write to the intermediate file and Update ns_ANALOGINFO ]
	%[ns_Result nsObj] = ns_AddAnalogData( nsObj, 1.1, Time, Value );							%	[ERROR] Wrong type of ID. The ID should be 0 or natural number. Return ns_WRONGID, nsObj.
	%[ns_Result nsObj] = ns_AddAnalogData( nsObj, 33, Time, Value );							%	[ERROR] Wrong value of ID. The ANALOG{ID} should exist. Return ns_WRONGID, nsObj.
	%[ns_Result nsObj] = ns_AddAnalogData( nsObj, AnalogID, Time, cast( Value, 'char' ));		%	[ERROR] Wrong type of Data. Return ns_WRONGDATA, nsObj.
	%[ns_Result nsObj] = ns_AddAnalogData( nsObj, AnalogID, cast( Time, 'char' ), Value );		%	[ERROR] Wrong type of Data. Return ns_WRONGDATA, nsObj.
	[ns_Result nsObj] = ns_AddAnalogData( nsObj, AnalogID, Time, DummyValue );						%	[OK]
%	[ns_Result nsObj] = ns_AddAnalogData( nsObj, AnalogID, Time, Value );						%	[OK]
	if 0 ~= ns_Result
		return;
	end
end

%	Clear Analog Data
clear nsa_ANALOGINFO;
clear analogData;
clear Time Value DummyValue row;

%	AD2


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	16.Initialize Segment Data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   Copy and paste from SD1 to SD2, if you want to add another neural event data.
%	SD1

%	Create segment entity. ( Create new entity SegmentID and initialize headers. )
%[ ns_Result nsObj SegmentID ] = ns_NewSegmentData( nsObj, 3200 );				%	[ERROR] Wrong type of input args. Return ns_WRONGLABEL, nsObj, ''(Blank).
%[ ns_Result nsObj SegmentID ] = ns_NewSegmentData( nsObj );					%	[OK]    Set ''(Blank) as ns_ENTITYINFO.szEntityLabel.
%[ ns_Result nsObj SegmentID ] = ns_NewSegmentData( nsObj, 'Segment_Sample' );	%	[OK]	Set this label as ns_ENTITYINFO.szEntityLabel.
[ ns_Result nsObj SegmentID ] = ns_NewSegmentData( nsObj, 'Segment_Sample', 'Undefined','sample ch04' );	%	[OK]	Set ns_ENTITYINFO.szEntityLabel, chType, chComment.
if 0 ~= ns_Result
	return;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	17.Read Segment Data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%	Read Segment Data
segmentData = textread( FileOfSegment_001, '', 'delimiter', '\t', 'emptyvalue', NaN );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	18.Modify Segment Entity Specific Infomation Header[ ns_SEGMENTINFO ]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%	Get header.
%[ ns_Result nsa_SEGMENTINFO ] = ns_GetSegmentInfo( nsObj, 1.2 );			%	[ERROR] Wrong type of ID. The ID should be 0 or natural number. Return ns_WRONGID and ''(Blank).
%[ ns_Result nsa_SEGMENTINFO ] = ns_GetSegmentInfo( nsObj, 90 );			%	[ERROR] Wrong value of ID. The SEGMENT{ID} should exist. Return ns_WRONGID and ''(Blank).
[ ns_Result nsa_SEGMENTINFO ] = ns_GetSegmentInfo( nsObj, SegmentID );		%	[OK]    Get nsa_SEGMENTINFO from ns_SEGMENTINFO.
if 0 ~= ns_Result
	return;
end

%	Modify members.
%	Comment out members which you do not want to modify.
	%	[Can not edit] dwSourceCount.		:::For consistency of data. ref. ns_SetSegmentInfo Method
	%	[Can not edit] dwMinSampleCount.	:::For consistency of data. ref. ns_SetSegmentInfo Method
	%	[Can not edit] dwMaxSampleCount.	:::For consistency of data. ref. ns_SetSegmentInfo Method
nsa_SEGMENTINFO.dSampleRate			 = 49;
nsa_SEGMENTINFO.szUnits				 = 'volt';
%nsa_SEGMENTINFO.abc				 = 0;									%	[ERROR] 	Wrong name of member. Set method returns ns_WRONGINFO.

%	Set header.
%[ ns_Result nsObj ] = ns_SetSegmentInfo( nsObj, 1.1, nsa_SEGMENTINFO );				%	[ERROR] Wrong type of ID. The ID should be 0 or natural number. Return ns_WRONGID, nsObj.
%[ ns_Result nsObj ] = ns_SetSegmentInfo( nsObj, 80, nsa_SEGMENTINFO );					%	[ERROR] Wrong value of ID. The SEGMENT{ID} should exist. Return ns_WRONGID, nsObj.
%[ ns_Result nsObj ] = ns_SetSegmentInfo( nsObj, SegmentID, nsa_SEGMENTINFO.szUnits );	%	[ERROR]	Wrong type of input args. Return ns_WRONGINFO, nsObj.
[ ns_Result nsObj] = ns_SetSegmentInfo( nsObj, SegmentID, nsa_SEGMENTINFO );			%	[OK]	If nsa_SEGMENTINFO includes wrong name of members, then return ns_WRONGINFO, nsObj.
if 0 ~= ns_Result
	return;
end

%   Add Segment Data
for row = 1:size( segmentData, 1 )
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%	19.Add Segment Data
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	Time = segmentData( row, 1 );
	UnitID = segmentData( row, 2 );
	DummyValue = segmentData( row, 3:end );
	Value = DummyValue(find(~isnan(DummyValue)));
	
	%	Add Segment Data [ Write to the intermediate file, Create ns_SEGSOURCEINFO, Update ns_SEGMENTINFO&ns_SEGSOURCEINFO ]
	%[ ns_Result nsObj SegmentSourceID ] = ns_AddSegmentData( nsObj, 1.1, Time, UnitID, Value );							%	[ERROR] Wrong type of ID. The ID should be 0 or natural number. Return ns_WRONGID, nsObj, ''(Blank).
	%[ ns_Result nsObj SegmentSourceID ] = ns_AddSegmentData( nsObj, 80, Time, UnitID, Value );								%	[ERROR] Wrong value of ID. The SEGMENT{ID} should exist. Return ns_WRONGID, nsObj, ''(Blank).
	%[ ns_Result nsObj SegmentSourceID ] = ns_AddSegmentData( nsObj, SegmentID, cast( Time, 'char' ), UnitID, Value );		%	[ERROR] Wrong type of Data. Return ns_WRONGDATA, nsObj, ''(Blank).
	%[ ns_Result nsObj SegmentSourceID ] = ns_AddSegmentData( nsObj, SegmentID, Time, cast( UnitID, 'char' ), Value );		%	[ERROR] Wrong type of Data. Return ns_WRONGDATA, nsObj, ''(Blank).
	%[ ns_Result nsObj SegmentSourceID ] = ns_AddSegmentData( nsObj, SegmentID, Time, UnitID, cast( Value, 'char' ) );		%	[ERROR] Wrong type of Data. Return ns_WRONGDATA, nsObj, ''(Blank).
	[ ns_Result nsObj ] = ns_AddSegmentData( nsObj, SegmentID, Time, UnitID, Value );						%	[OK]
	if 0 ~= ns_Result
		return;
	end
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%	20.Modify Segment Source Entity Specific Infomation Header[ ns_SEGSOURCEINFO ]
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %	Get header.
	%[ ns_Result nsa_SEGSOURCEINFO ] = ns_GetSegmentSourceInfo( nsObj, 1.2, SegmentSourceID );			%	[ERROR] Wrong type of ID. The ID should be 0 or natural number. Return ns_WRONGID and ''(Blank).
	%[ ns_Result nsa_SEGSOURCEINFO ] = ns_GetSegmentSourceInfo( nsObj, 90, SegmentSourceID );			%	[ERROR] Wrong value of ID. The SEGMENT{ID} should exist. Return ns_WRONGID and ''(Blank).
	%[ ns_Result nsa_SEGSOURCEINFO ] = ns_GetSegmentSourceInfo( nsObj, SegmentID, 1.2 );				%	[ERROR] Wrong type of ID. The ID should be 0 or natural number. Return ns_WRONGID and ''(Blank).
	%[ ns_Result nsa_SEGSOURCEINFO ] = ns_GetSegmentSourceInfo( nsObj, SegmentID, 88 );					%	[ERROR] Wrong value of ID. The SEGMENT{ID}.ns_SEGSOURCEINFO(ID) should exist. Return ns_WRONGID and ''(Blank).
	[ ns_Result nsa_SEGSOURCEINFO ] = ns_GetSegmentSourceInfo( nsObj, SegmentID, 1 );		%	[OK]    Get nsa_SEGSOURCEINFO from ns_SEGSOURCEINFO.
	if 0 ~= ns_Result
		return;
	end
	
	%	Modify members.
	%	Comment out members which you do not want to modify.
	nsa_SEGSOURCEINFO.dResolution               = 0.0015;
	nsa_SEGSOURCEINFO.dMinVal                   = -1000;			%	Min value.
                                                                    %   This member will be set by methods below.
                                                                    %   - ns_SetSegmentSourceInfo - set it manually.
                                                                    %   - ns_AddSegmentData - calculated it by data automatically.
                                                                    %   Latest min val is adopted.
                                                                    
	nsa_SEGSOURCEINFO.dMaxVal                   = 15;				%	Max value.
                                                                    %   This member will be set by methods below.
                                                                    %   - ns_SetSegmentSourceInfo - set it manually.
                                                                    %   - ns_AddSegmentData - calculated it by data automatically.
                                                                    %   Latest max val is adopted.
	nsa_SEGSOURCEINFO.dSubSampleShift           = 0; 
	nsa_SEGSOURCEINFO.dLocationX                = 0; 
	nsa_SEGSOURCEINFO.dLocationY                = 1; 
	nsa_SEGSOURCEINFO.dLocationZ                = 0; 
	nsa_SEGSOURCEINFO.dLocationUser             = 0.5; 
	nsa_SEGSOURCEINFO.dHighFreqCorner           = 0; 
	nsa_SEGSOURCEINFO.dwHighFreqOrder           = 0;
	nsa_SEGSOURCEINFO.szHighFilterType          = 'Highcomment'; 
	nsa_SEGSOURCEINFO.dLowFreqCorner            = 0; 
	nsa_SEGSOURCEINFO.dwLowFreqOrder            = 0; 
	nsa_SEGSOURCEINFO.szLowFilterType           = 'Lowcomment'; 
	nsa_SEGSOURCEINFO.szProbeInfo               = 'comment'; 
	%nsa_SEGSOURCEINFO.abc                      = 0;				%	[ERROR] 	Wrong name of member. Set method returns ns_WRONGINFO.
	%nsa_SEGSOURCEINFO.szProbeInfo              = 1234;				%	[WARNING]	Wrong type of member. Set method returns ns_OK, but, the value still remain. 
	
	%	Set header.
	%[ ns_Result nsObj ] = ns_SetSegmentSourceInfo( nsObj, 1.1, SegmentSourceID, nsa_SEGSOURCEINFO );				%	[ERROR] Wrong type of ID. The ID should be 0 or natural number. Return ns_WRONGID, nsObj.
	%[ ns_Result nsObj ] = ns_SetSegmentSourceInfo( nsObj, 80, SegmentSourceID, nsa_SEGSOURCEINFO );				%	[ERROR] Wrong value of ID. The SEGMENT{ID} should exist. Return ns_WRONGID, nsObj.
	%[ ns_Result nsObj ] = ns_SetSegmentSourceInfo( nsObj, SegmentID, 1.1, nsa_SEGSOURCEINFO );						%	[ERROR] Wrong type of ID. The ID should be 0 or natural number. Return ns_WRONGID, nsObj.
	%[ ns_Result nsObj ] = ns_SetSegmentSourceInfo( nsObj, SegmentID, 80, nsa_SEGSOURCEINFO );						%	[ERROR] Wrong value of ID. The SEGMENT{ID}.ns_SEGSOURCEINFO(ID) should exist. Return ns_WRONGID, nsObj.
	%[ ns_Result nsObj ] = ns_SetSegmentSourceInfo( nsObj, SegmentID, SegmentSourceID, nsa_SEGSOURCEINFO.dMinVal );	%	[ERROR]	Wrong type of input args. Return ns_WRONGINFO, nsObj.
	[ ns_Result nsObj] = ns_SetSegmentSourceInfo( nsObj, SegmentID, 1, nsa_SEGSOURCEINFO );			%	[OK]	If nsa_SEGSOURCEINFO includes wrong name of members, then return ns_WRONGINFO, nsObj.
	if 0 ~= ns_Result
		return;
	end

	
end

%	Clear Segment Data
clear nsa_SEGMENTINFO;
clear nsa_SEGSOURCEINFO;
clear segmentData;
clear Time UnitID Value DummyValue row;

%	SD2


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	21.Integrate all intermediate files.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%	Integrate all files.
ns_Result = ns_CloseFile( nsObj );
if 0 ~= ns_Result
	return;
end

%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%	SC source end
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%   APPENDIX
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
%	1.Meaning of ERROR, WARNING messages.
%	2.Data format for this SC.
%	3.Change log of this SC.
%
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%	1.Meaning of ERROR, WARNING messages.
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
%	SC or MATLAB Lib. displays message below on command window when ERROR or WARNING occur.
%	If you see message, you should check below.
%
%	1.	??? Error using ==> fwrite
%		Invalid file identifier.  Use fopen to generate a valid file identifier.
%				
%			[TODO]:Modify the output directory name.
%                       It is needed to create the output directory already.
%
%	2.	file not found
%
%			[TODO]:Modify the input file path.
%                       System can't find it.
%
%	3.	WRONG EXTENSION OF OUTPUT_FILE
%
%			[TODO]:Modify extension of the output file name as '.nsn'
%                       Don't set '.NSN'
%
%	4.	WRONG ID_TYPE 
%
%			[TODO]:Modify type of the entity ID.
%                       You have to set integer value.
%								
%	5.	WRONG ID_VALUE
%
%			[TODO]:Modify value of the entity ID.
%                       You have to set value already exists.
%
%	6.	WRONG INFO
%
%			[TODO]:Modify type of nsa_***INFO.
%                       You have to check members of it.
%				
%	7.	WRONG INFO_TYPE
%
%			[TODO]:Modify type of member of nsa_***INFO.
%								
%	8.	WRONG INFO_VALUE
%
%			[TODO]:Modify value of member of nsa_***INFO.
%
%	9.	WRONG DATA_TYPE
%
%			[TODO]:Modify type of data.
%
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%	2.Data format for this SC.
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%   SC treats formats below as input data.
%
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%	2-1.Event Entity Data File
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%	Format for Event Entity.
%
%	1.Text file.
%   2.Means [dTimeStamp], [EventValue].
%	3.Delimiter is a tab.
%
%11.5	1
%12.5	2
%13.5	3
%14.5	4
%
%
%
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%	2-2.Analog Entity Data File.
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%	Format for Analog Entity.
%
%	1.Text file.
%   2.Means [dTimeStamp], [dAnalogValue[0]], [dAnalogValue[1]], ... (No need dwDataCount![is calculated automatically])
%	3.Delimiter is a tab.
%
%51.5	11.0	12.0	13.0	14.0	15.0	16.0	17.0	18.0	19.0	20.0
%52.5	21.0	22.0	23.0	24.0	25.0	26.0	27.0	28.0	29.0	30.0
%
%
%
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%	2-3.Segment Entity Data File.
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%	Format for Segment Entity.
%
%	1.Text file.
%	2.Means [dTimeStamp], [dwUnitID], [dValue[0][0]], [dAnalogValue[0][1]], ...(No need dwSampleCount![is calculated automatically])
%	3.Delimiter is a tab.
%
%31.5	1	13.1	13.2	13.3	13.4	13.5
%32.0	2	13.6	13.7	13.8	13.9	14.0
%32.5	3	14.1	14.2	14.3	14.4	14.5
%
%
%
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%	2-4.Neural Event Entity Data File.
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%	Format for Neural Event Entity.
%
%	1.Text file.
%   2.Means [dTimeStamp].
%
%11.0
%12.0
%13.0
%14.0
%15.0
%
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%	3.Change log of this SC.
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%   Change log.
%
%	2009/01/28	K.Harada	Create new.
%	2009/02/09	K.Harada	Mod NeuralEvent.
%	2009/02/17	K.Harada	Mod ns_Set***.
%	2009/03/06	K.Harada	Mod ns_Add***.
%	2009/03/09	K.Harada	Mod file path.
%	2009/03/13	K.Harada	Mod type of value.( The lib. can accept integer double value for uint32 inputs )
%	2009/03/24	K.Harada	Mod value of ns_Result, mod comments. 
%	2009/03/31	K.Harada	Mod file path.( The lib. only accept no-extension or 'nsn' extension. )
%	2009/04/03	K.Harada	Mod seq. after ERROR.
%	2009/04/06	K.Harada	Add comments about wrong using.
%	2009/04/13	K.Harada	Add comments.
%	2009/04/17	K.Harada	Add comments.
%	2009/05/13	K.Harada	Mod name of structs.( from ns_***INFO to nsa_***INFO )
%	2009/06/02	K.Harada	Mod treat ns_EVENTINFO.dwEventType as not editable.
%	2009/06/04	K.Harada	Mod seq. caused by modifying ns_AddSegmentData.
%   2010/05/12  K.Harada    Translate comments from JP to EN.
%   2010/05/14  K.Harada    Mod comments.
%   2010/05/17  K.Harada    Mod comments.
%   2011/05/30  K.Harada    Fix bug.
%   2012/01/19  K.Harada    Mod input args of  ns_New***Data(for Neuroshare Writer ver.1.4).
