<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    [Software]         ns_CreateFile Library with sample converter
    [Author]           K.Harada (ATR)
    [Date]             2010/03/16
    [Licence Type]     GPL
    [Contact]          kharada@atr.jp
    [Testing Env.]     After MATLAB 7.5.0(R2007b)
    [Development Env.] WindowsXP(SP2) MATLAB 7.5.0(R2007b)
--------------------------------------------------------------------------
Copyright and Disclaimer

This software is free but copyrighted software, distributed under the
terms of the GNU General Public License as published by the Free Software
Foundation. Further details on gcopylefth can be found at
http://www.gnu.org/copyleft/. No formal support or maintenance is provided
or implied.

--------------------------------------------------------------------------
1. About this file
    This file is a Readme file about ns_CreateFile Class Library and
    Sample Converter.
    
    This document describes how to use the library and converter which
    convert Neuroscience data to Neuroshare format.
    
    (Notes) Neuroshare : One of the Neuroscience data format (.nsn).
        Reference : Neuroshare Native File Format Specification Rev 0.9d
        Neuroshare site : http://neuroshare.sourceforge.net/download.shtml
    
--------------------------------------------------------------------------
2. Components
    This software has these components.
    
    @ns_CreateFile directory.                 : The ns_CreateFile Library
    ns_CreatFile Documentation.doc            : The Documentation of the
						ns_CreateFile Library
    
    SampleConverter.m                         : The sample converter
    SampleConverter_withChInfo.m              : The sample converter with setting Channel Info.
    InputFiles directory                      : The input directory for
						dummy files
    OutputFiles directory                     : The output directory for
						Neuroshare files
    
    Readme.txt                                : This file
    
--------------------------------------------------------------------------
3. How to install this software
    There is no installer.
    Please unzip the directory wherever you want.
    
--------------------------------------------------------------------------
4. How to uninstall this software
    Delete the directory.
    
--------------------------------------------------------------------------
5. How to use this library
    ns_CreateFile Library is simply a set of MATLAB functions.
    If you want to use them, see below.
    
    1. Set directory path as the search path.
        1. Set the directory path as the current directory. (recommended)
        or
        2. Call addpath() [MATLAB Function]
        
    2. Use methods.
        See ns_CreateFile Documentation.doc in detail.
        
        
--------------------------------------------------------------------------
6. How to use the sample converter
    ns_Converter is a MATLAB script file.
    It converts input files to Neuroshare files.
    Input files exist in the InputFiles directory.
    Output files exist in the OutputFiles directory.
    For use, see below.
    
    1. Set directory path as the search path.
        1. Set the directory path as the current directory. (recommended)
        or
        2. Call addpath() [MATLAB Function]
    
    2. Execute Converter.
        Type "SampleConverter" in the command window.
        Conversion will be executed.
        
        (*) See SampleConverter.m if you want to know meanings of "ERROR"
           or "WARNING"
        
        (*) Modify the in/output directory paths correctly if you use
            addpath().
    
--------------------------------------------------------------------------
7. History

ver 1.4 Date : 2011/01/20
    Change the method to register Channel data. Add SampleConverter_withChInfo.m

ver 1.3 Date : 2011/03/03
    Change the method to register Segment data.

ver 1.2 Date : 2010/06/16
    'int'-value can be used as input-data.

ver 1.1 Date : 2010/03/03
    Translate comments (Japanese to English).

ver 1.0 Date : 2009/06/09
    Fix bugs with EVENT and SEGMENT data.

ver 0.9 Date : 2009/05/07
    Implement this software, referring to the POMU-Lab site.
    POMU-Lab site
	: http://www2.bpe.es.osaka-u.ac.jp/multineuron/POMU-Lab/index.html
