function [ ns_Result nsObj ] = ns_SetEventInfo(nsObj, ID, nsa_EVENTINFO)
% ns_SetEventInfo - Update ns_EVENTINFO which is identified by ID.
% [ ns_Result nsObj ] = ns_SetEventInfo( nsObj, ID, nsa_EVENTINFO )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   ID        - [uint32] - identification number of this type of entity.
%   nsa_EVENTINFO - [struct] - struct of this entity.
% 
% Outputs:
%   ns_Result - [double] - result value of this function.
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%
% Created By: Keiji HARADA (1),  kharada@atr.jp  09/04/30
% Modified By: Keiji HARADA (1),  kharada@atr.jp  10/03/02 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% Check value of ID 
% If A or B condition consists, ns_Result is ns_WRONGID.
% A. Wrong type of ID (Can't change ID value to uint32(scalar(1*1)) value.)
% B. Unregistered ID (As Event Entity.)
ns_Result = ns_CheckID( nsObj, ID, nsObj.CONST.ns_ENTITY_EVENT );
if nsObj.CONST.ns_OK ~= ns_Result
    return;
end

% Check value of struct
% If A or B or C condition consists, ns_Result is ns_WRONGHEADER
% A. One or more undefined member exists.            [exam. : nsa_EVENTINFO.abc]
% B. One or more unchangeable member exists.         [dwEventType, dwMinDataLength, dwMaxDataLength]
% C. One or more changeable member does not exists.  [nsa_EVENTINFO.szCSVDesc] (case : If application remove it.)
ns_Result = ns_CheckInfo( nsObj, nsa_EVENTINFO, 'nsa_EVENTINFO' );
if nsObj.CONST.ns_OK ~= ns_Result
    return;
end

% Update struct
% If A or B condition consists, Warning message will be displayed. 
%    (ns_Result is ns_OK, nsObj.Event{ID}.ns_EVENTINFO is updated EXCEPT members below)
% A. Wrong type of member    [exam. : nsa_EVENTINFO.szCSVDesc = 123 (Type of szCSVDesc must be char(Vector(1*n)) )]
% B. Wrong value of member   [-- Nothing in ns_EVENTINFO --]
nsObj = ns_UpdateEventInfo( nsObj, ID, nsa_EVENTINFO );


% NOT update value of these members.
% It is not able to change these members value with using Get/Set method. Only New/Add method can do it.

% dwEventType      [scalar(1*1),uint32]
% dwMinDataLength  [scalar(1*1),uint32]
% dwMaxDataLength  [scalar(1*1),uint32]



% Update value of these members.

% szCSVDesc   [char]
