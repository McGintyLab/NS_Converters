function [ ns_Result nsa_FILEINFO ] = ns_GetFileInfo( nsObj )
% ns_GetFileInfo - Get ns_FILEINFO.
%[ ns_Result nsa_FILEINFO ] = ns_GetFileInfo( nsObj )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
% 
% Outputs:
%   ns_Result - [double] - result value of this function.
%   nsa_FILEINFO - [struct] - struct of this file.
%
% Created By: Keiji HARADA (1),  kharada@atr.jp  09/04/30
% Modified By: Keiji HARADA (1),  kharada@atr.jp  10/03/02 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% Set return struct.
nsa_FILEINFO = nsObj.ns_FILEINFO;

% Remove these members from return struct.
% It is not able to change these members value with using Get/Set method. Only New/Add method can do it.
nsa_FILEINFO = rmfield( nsa_FILEINFO, 'dwEntityCount');

% OK
ns_Result = nsObj.CONST.ns_OK;

% Return struct has these members.

% szFileType            [char]
% dTimeStampResolution  [scalar(1*1),double]
% dTimeSpan             [scalar(1*1),double]
% szAppName             [char]
% dwTime_Year           [scalar(1*1),uint32]
% dwTime_Month          [scalar(1*1),uint32]
% dwTime_DayOfWeek      [scalar(1*1),uint32]
% dwTime_Day            [scalar(1*1),uint32]
% dwTime_Hour           [scalar(1*1),uint32]
% dwTime_Min            [scalar(1*1),uint32]
% dwTime_Sec            [scalar(1*1),uint32]
% dwTime_MilliSec       [scalar(1*1),uint32]
% szFileComment         [char]

% Return struct DOESNOT have these members.

% dwEntityCount         [scalar(1*1),uint32]
