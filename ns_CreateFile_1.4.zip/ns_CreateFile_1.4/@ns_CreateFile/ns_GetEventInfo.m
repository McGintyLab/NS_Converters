function [ ns_Result nsa_EVENTINFO ] = ns_GetEventInfo( nsObj, ID )
% ns_GetEventInfo - Get ns_EVENTINFO which is identified by ID.
% [ ns_Result nsa_EVENTINFO ] = ns_GetEventInfo( nsObj, ID )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   ID        - [uint32] - identification number of this type of entity.
% 
% Outputs:
%   ns_Result - [double] - result value of this function.
%   nsa_EVENTINFO - [struct] - struct of this entity.
%
% Created By: Keiji HARADA (1),  kharada@atr.jp  09/04/30
% Modified By: Keiji HARADA (1),  kharada@atr.jp  10/03/02 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% Check value of ID 
% If A or B condition consists, ns_Result is ns_WRONGID.
% A. Wrong type of ID (Can't change ID value to uint32(scalar(1*1)) value.)
% B. Unregistered ID (As Event Entity.)
ns_Result = ns_CheckID( nsObj, ID, nsObj.CONST.ns_ENTITY_EVENT );
if nsObj.CONST.ns_OK ~= ns_Result
    nsa_EVENTINFO = '';
    return;
end

% Set return struct.
nsa_EVENTINFO = nsObj.Event{ID}.ns_EVENTINFO;

% Remove these members from return struct.
% It is not able to change these members value with using Get/Set method. Only New/Add method can do it.
nsa_EVENTINFO = rmfield( nsa_EVENTINFO, 'dwEventType');
nsa_EVENTINFO = rmfield( nsa_EVENTINFO, 'dwMinDataLength');
nsa_EVENTINFO = rmfield( nsa_EVENTINFO, 'dwMaxDataLength');

% Return struct has these members.

% szCSVDesc   [char]

% Return struct DOESNOT have these members.

% dwEventType      [scalar(1*1),uint32]
% dwMinDataLength  [scalar(1*1),uint32]
% dwMaxDataLength  [scalar(1*1),uint32]
