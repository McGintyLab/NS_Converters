function [ ns_Result nsObj ] = ns_AddNeuralEventData( nsObj, ID, dTime )
% ns_AddNeuralEventData - Update nsObj, Add dTime to the intermediate file which is identified by ID.
%[ ns_Result nsObj ] = ns_AddNeuralEventData( nsObj, ID, dTime )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   ID        - [uint32] - identification number of this type of entity.
%   dTime     - [double] - value of timestamp.
% 
% Outputs:
%   ns_Result - [double] - result value of this function.
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/03/02 
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/03/16
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/03/22
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% Check value of ID 
% If A or B condition consists, ns_Result is ns_WRONGID.
% A. Wrong type of ID (Can't change ID value to uint32(scalar(1*1)) value.)
% B. Unregistered ID (As Neural Event Entity.)
ns_Result = ns_CheckID( nsObj, ID, nsObj.CONST.ns_ENTITY_NEURAL );
if nsObj.CONST.ns_OK ~= ns_Result
 return;
end

% Convert int to double, if needed      % SM
if isinteger(dTime)
    dTime = double(dTime);
end

% Check value of dTime 
% If A condition consists, ns_Result is ns_WRONGDATA.
% A. Wrong type of dTime (Can't change dTime value to double(scalar(1*1)) value.)
ns_Result = ns_CheckNeuralEventData( nsObj, dTime );
if nsObj.CONST.ns_OK ~= ns_Result
 return;
end
 
% Correct values to rewrite object.
% --nothing--

% Add data to the intermediate file.
fid = fopen(nsObj.NeuralEvent{ID}.FNAME,'a');       % SM
%fwrite(nsObj.NeuralEvent{ID}.FID, dTime,'double');
fwrite(fid,dTime,'double');
fclose(fid);

% Update nsObj.
% *************  ns_TAGELEMENT  *************
% ns_TAGELEMENT : dwElemLength (total bytes of this analog entity)
nsObj.NeuralEvent{ID}.ns_TAGELEMENT.dwElemLength = ...
 nsObj.NeuralEvent{ID}.ns_TAGELEMENT.dwElemLength + 8;

% *************  ns_ENTITYINFO  *************
% ns_ENTITYINFO : dwItemCount (total number of this analog values)
nsObj.NeuralEvent{ID}.ns_ENTITYINFO.dwItemCount = ...
 nsObj.NeuralEvent{ID}.ns_ENTITYINFO.dwItemCount + 1;

