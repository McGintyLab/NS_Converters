function [ ns_Result nsObj ] = ns_SetSegmentInfo(nsObj, ID, nsa_SEGMENTINFO)
% ns_SetSegmentInfo - Update ns_SEGMENTINFO which is identified by ID.
% [ ns_Result nsObj ] = ns_SetSegmentInfo( nsObj, ID, nsa_SEGMENTINFO )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   ID        - [uint32] - identification number of this type of entity.
%   nsa_SEGMENTINFO - [struct] - struct of this entity.
% 
% Outputs:
%   ns_Result - [double] - result value of this function.
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%
% Created By: Keiji HARADA (1),  kharada@atr.jp  09/04/30
% Modified By: Keiji HARADA (1),  kharada@atr.jp  10/03/02 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% Check value of ID 
% If A or B condition consists, ns_Result is ns_WRONGID.
% A. Wrong type of ID (Can't change ID value to uint32(scalar(1*1)) value.)
% B. Unregistered ID (As Segment Entity.)
ns_Result = ns_CheckID( nsObj, ID, nsObj.CONST.ns_ENTITY_SEGMENT );
if	nsObj.CONST.ns_OK ~= ns_Result
	return;
end

% Check value of struct
% If A or B or C condition consists, ns_Result is ns_WRONGHEADER
% A. One or more undefined member exists.            [exam. : nsa_SEGMENTINFO.abc]
% B. One or more unchangeable member exists.         [dwSourceCount, dwMinSampleCount, dwMaxSampleCount]
% C. One or more changeable member does not exists.  [nsa_SEGMENTINFO.dSampleRate, nsa_SEGMENTINFO.szUnits] (case : If application remove it.)
ns_Result = ns_CheckInfo( nsObj, nsa_SEGMENTINFO, 'nsa_SEGMENTINFO' );
if nsObj.CONST.ns_OK ~= ns_Result
	return;
end

% Update struct
% If A or B condition consists, Warning message will be displayed. 
%    (ns_Result is ns_OK, nsObj.Segment{ID}.ns_SEGMENTINFO is updated EXCEPT members below)
% A. Wrong type of member    [exam. : nsa_SEGMENTINFO.szUnits = 123 (Type of szUnits must be char(Vector(1*n)) )]
% B. Wrong value of member   [-- Nothing in ns_SEGMENTINFO --]
nsObj = ns_UpdateSegmentInfo( nsObj, ID, nsa_SEGMENTINFO );


% NOT update value of these members.
% It is not able to change these members value with using Get/Set method. Only New/Add method can do it.

% dwSourceCount    [scalar(1*1),uint32]
% dwMinSampleCount [scalar(1*1),uint32]
% dwMaxSampleCount [scalar(1*1),uint32]



% Update value of these members.

% dSampleRate      [scalar(1*1),double]
% szUnits          [char]
