function [ ns_Result nsObj ] = ns_SetSegmentSourceInfo(nsObj, SEGID, SEGSOURCEID, nsa_SEGSOURCEINFO)
% ns_SetSegmentSourceInfo - Update ns_EVENTINFO which is identified by SEGID and SEGSOURCEID.
% [ ns_Result nsObj ] = ns_SetSegmentSourceInfo(nsObj, SEGID, SEGSOURCEID, nsa_SEGSOURCEINFO)
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   SEGID     - [uint32] - identification number of this type of entity.
%   SEGSOURCEID - [uint32] - identification number of this source.
%   nsa_SEGSOURCEINFO- [struct] - struct of this entity.
% 
% Outputs:
%   ns_Result - [double] - result value of this function.
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%
% Created By: Keiji HARADA (1),  kharada@atr.jp  09/04/30
% Modified By: Keiji HARADA (1),  kharada@atr.jp  10/03/02 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% Check value of SEGID 
% If A or B condition consists, ns_Result is ns_WRONGID.
% A. Wrong type of SEGID (Can't change SEGID value to uint32(scalar(1*1)) value.)
% B. Unregistered SEGID (As Segment Entity.)
ns_Result = ns_CheckID( nsObj, SEGID, nsObj.CONST.ns_ENTITY_SEGMENT );
if	nsObj.CONST.ns_OK ~= ns_Result
	return;
end

% Check value of SEGSOURCEID 
% If A or B condition consists, ns_Result is ns_WRONGID.
% A. Wrong type of SEGSOURCEID (Can't change SEGSOURCEID value to uint32(scalar(1*1)) value.)
% B. Unregistered SEGSOURCEID (As Segment Entity.)
ns_Result = ns_CheckSegmentSourceID( nsObj, SEGID, SEGSOURCEID );
if	nsObj.CONST.ns_OK ~= ns_Result
	return;
end

% Check value of struct
% If A or B or C condition consists, ns_Result is ns_WRONGHEADER
% A. One or more undefined member exists.            [exam. : nsa_SEGSOURCEINFO(SEGSOURCEID).abc]
% B. One or more unchangeable member exists.         [-- Nothing in ns_SEGSOURCEINFO --]
% C. One or more changeable member does not exists.  [exam. : nsa_SEGSOURCEINFO(SEGSOURCEID).dResolution] (case : If application remove it.)
ns_Result = ns_CheckInfo( nsObj, nsa_SEGSOURCEINFO, 'nsa_SEGSOURCEINFO' );
if nsObj.CONST.ns_OK ~= ns_Result
	return;
end

% Update struct
% If A or B condition consists, Warning message will be displayed. 
%    (ns_Result is ns_OK, nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(SEGSOURCEID) is updated EXCEPT members below)
% A. Wrong type of member    [exam. : nsa_SEGSOURCEINFO(SEGSOURCEID).dResolution = 'text words' (Type of dResolution must be double(scalar(1*1)) )]
% B. Wrong value of member   [-- Nothing in ns_SEGSOURCEINFO --]
nsObj = ns_UpdateSegSourceInfo( nsObj, SEGID, SEGSOURCEID, nsa_SEGSOURCEINFO );


% NOT update value of these members.
% It is not able to change these members value with using Get/Set method. Only New/Add method can do it.

% -- Nothing --



% Update value of these members.

% dMinVal          [scalar(1*1),double]
% dMaxVal          [scalar(1*1),double]
% dResolution      [scalar(1*1),double]
% dSubSampleShift  [scalar(1*1),double]
% dLocationX       [scalar(1*1),double]
% dLocationY       [scalar(1*1),double]
% dLocationZ       [scalar(1*1),double]
% dLocationUser    [scalar(1*1),double]
% dHighFreqCorner  [scalar(1*1),double]
% dwHighFreqOrder  [scalar(1*1),uint32]
% szHighFilterType [char]
% dLowFreqCorner   [scalar(1*1),double]
% dwLowFreqOrder   [scalar(1*1),uint32]
% szLowFilterType  [char]
% szProbeInfo      [char]
