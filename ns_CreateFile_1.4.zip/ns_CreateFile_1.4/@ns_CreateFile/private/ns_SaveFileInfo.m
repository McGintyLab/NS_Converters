function ns_Result = ns_SaveFileInfo(nsObj)
% ns_SaveFileInfo - Save ns_FILEINFO to intermediate file. ( 1 File )
% ns_Result = ns_SaveFileInfo(nsObj)
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/05/07 
% Modified By: Satoshi Murata (1),  satoshi-m@atr.jp  11/11/18 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

try
    %   Intermediate file name.
	filename = fullfile(nsObj.directory,...
		['_00_FileInfoHeader_' nsObj.filename]);
	ns_FILEINFO = nsObj.ns_FILEINFO;
    
    if ~isempty(nsObj.chInfo) && isstruct(nsObj.chInfo)
        ns_FILEINFO.dwEntityCount = ns_FILEINFO.dwEntityCount + 1;      % for INFO_FILE
    end

	fid = fopen(filename, 'w');

	%   sMagicCode
	fwrite(fid,nsObj.sMagicCode);
	fwrite(fid,0);

    %   ns_FILEINFO
    s=[ns_FILEINFO.szFileType blanks(32)];
	fwrite(fid,s(1:32));
	fwrite(fid,ns_FILEINFO.dwEntityCount,'uint32');
	fwrite(fid,ns_FILEINFO.dTimeStampResolution,'double');
	fwrite(fid,ns_FILEINFO.dTimeSpan,'double');
	s=[ns_FILEINFO.szAppName blanks(64)];
	fwrite(fid,s(1:64));
	fwrite(fid,ns_FILEINFO.dwTime_Year,'uint32');
	fwrite(fid,ns_FILEINFO.dwTime_Month,'uint32');
	fwrite(fid,ns_FILEINFO.dwTime_DayOfWeek,'uint32');
	fwrite(fid,ns_FILEINFO.dwTime_Day,'uint32');
	fwrite(fid,ns_FILEINFO.dwTime_Hour,'uint32');
	fwrite(fid,ns_FILEINFO.dwTime_Min,'uint32');
	fwrite(fid,ns_FILEINFO.dwTime_Sec,'uint32');
	fwrite(fid,ns_FILEINFO.dwTime_MilliSec,'uint32');
	s=[ns_FILEINFO.szFileComment blanks(256)];
	fwrite(fid,s(1:256));

	fclose(fid);
	ns_Result = nsObj.CONST.ns_OK;

catch

    % File handling error
	A{1} = nsObj.MESSAGE.FILEMANIPULATIONERROR;
	A{2} = 'Save FileInfo To Intermediate File';
	A{3} = nsObj.MESSAGE.COLON;
	A{4} = nsObj.MESSAGE.STOPSEQUENCE;

    msg = strcat(A{:});
	
	disp(msg);
	
    %   as debug
    dbstack;
    
	% File creation error
	ns_Result = nsObj.CONST.ns_FILEERROR;
end