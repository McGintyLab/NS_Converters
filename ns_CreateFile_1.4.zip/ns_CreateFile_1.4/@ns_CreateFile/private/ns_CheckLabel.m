function ns_Result = ns_CheckLabel( nsObj, szLabel )
% ns_CheckLabel - Check label.
% ns_Result = ns_CheckLabel( nsObj, szLabel )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%	szLabel   - [char]   - label.
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/05/21 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

ns_Result = nsObj.CONST.ns_OK;

%	check type of szLabel
if 0 ~= CheckTypeOfLabel( szLabel )
	
	%	ERROR:WRONGDATATYPE
	A{1} = nsObj.MESSAGE.ERROR;
	A{2} = nsObj.MESSAGE.WRONGDATATYPE;
	A{3} = 'LABEL';
	A{4} = nsObj.MESSAGE.MUSTBEsz;
	A{5} = nsObj.MESSAGE.COLON;
	A{6} = nsObj.MESSAGE.STOPSEQUENCE;
	
	msgct = strcat(A{:});
	
	disp(msgct);

    %   as debug
    dbstack;
    
	%	wrong LABEL
    ns_Result = nsObj.CONST.ns_WRONGLABEL;
end

%	It is not needed to check value of szLabel.

%**************************************************************************
function ns_Result = CheckTypeOfLabel( Label )
%	check type of Label
%	If type of the value meets the following conditions, it is correct.
%   1. char

if 1 ~= isa(Label, 'char')
%%	NG
	ns_Result = -1;		%	not char.

else
%%	OK
	ns_Result = 0;		%	no problems.
end

