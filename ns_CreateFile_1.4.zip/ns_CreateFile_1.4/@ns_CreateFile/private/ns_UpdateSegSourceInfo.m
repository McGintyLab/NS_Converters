function nsObj = ns_UpdateSegSourceInfo( nsObj, SEGID, SEGSOURCEID, Data )
% ns_UpdateSegSourceInfo - Update ns_SEGSOURCEINFO.
% nsObj = ns_UpdateSegSourceInfo( nsObj, SEGID, SEGSOURCEID, Data )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   SEGID     - [uint32] - identification number of this type of entity.
%   SEGSOURCEID - [uint32] - identification number of the source.
%   Data      - [struct] - nsa_SEGSOURCEINFO which user modified.
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/05/07 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

%	List of ns_SEGSOURCEINFO

%   [OK RANGE]
%       System allows user to change this value only within the range.
%       If user set value over this range, then system remains it and displays WARNING message. ( NOT ERROR )

%   [KIND]
%       A : User can't change this value. Only system can set it.  
%       B : User can change this value. System can set it, too. (The larger max val [least min val] is adopted.)
%       C : User can change this value. System doesn't set it.

%	[NAME]              [TYPE]						[OK RANGE]  	[KIND]
%	dMinVal				[scalar(1*1),double]		[]				[B]
%	dMaxVal				[scalar(1*1),double]		[]				[B]
%	dResolution			[scalar(1*1),double]		[]				[C]
%	dSubSampleShift		[scalar(1*1),double]		[]				[C]
%	dLocationX			[scalar(1*1),double]		[]				[C]
%	dLocationY			[scalar(1*1),double]		[]				[C]
%	dLocationZ			[scalar(1*1),double]		[]				[C]
%	dLocationUser		[scalar(1*1),double]		[]				[C]
%	dHighFreqCorner		[scalar(1*1),double]		[]				[C]
%	dwHighFreqOrder		[scalar(1*1),uint32]		[]				[C]
%	szHighFilterType	[char]						[]				[C]
%	dLowFreqCorner		[scalar(1*1),double]		[]				[C]
%	dwLowFreqOrder		[scalar(1*1),uint32]		[]				[C]
%	szLowFilterType		[char]						[]				[C]
%	szProbeInfo			[char]						[]				[C]

A_TY = nsObj.MESSAGE.WRONGINFOTYPE;
A_VL = nsObj.MESSAGE.WRONGINFOVALUE;
A_NP = nsObj.MESSAGE.NOTPOSSIBLETOSETVALUE;
B = nsObj.MESSAGE.ns_SEGSOURCEINFO;
C = '(';
D = int2str( SEGSOURCEID );
E = ').';
%	F	NAME of the member.
G_d = nsObj.MESSAGE.MUSTBEd; 
G_dw = nsObj.MESSAGE.MUSTBEdw; 
G_sz = nsObj.MESSAGE.MUSTBEsz;
G_SF = nsObj.MESSAGE.SETBYFUNCTION;
H =	nsObj.MESSAGE.COLON;
I = nsObj.MESSAGE.THISISNOTUPDATED;

%	dMinVal				[scalar(1*1),double]		[]				[B]
if 1 == isscalar(Data.dMinVal) && 1 == isa(Data.dMinVal,'double')
	%	OK
	nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(SEGSOURCEID).dMinVal = Data.dMinVal;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,C,D,E,'dMinVal',G_d,H,I);
	warning(msg);
end

%	dMaxVal				[scalar(1*1),double]		[]				[B]
if 1 == isscalar(Data.dMaxVal) && 1 == isa(Data.dMaxVal,'double')
	%	OK
	nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(SEGSOURCEID).dMaxVal = Data.dMaxVal;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,C,D,E,'dMaxVal',G_d,H,I);
	warning(msg);
end

%	dResolution			[scalar(1*1),double]		[]				[C]
if 1 == isscalar(Data.dResolution) && 1 == isa(Data.dResolution,'double')
	%	OK
	nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(SEGSOURCEID).dResolution = Data.dResolution;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,C,D,E,'dResolution',G_d,H,I);
	warning(msg);
end

%	dSubSampleShift		[scalar(1*1),double]		[]				[C]
if 1 == isscalar(Data.dSubSampleShift) && 1 == isa(Data.dSubSampleShift,'double')
	%	OK
	nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(SEGSOURCEID).dSubSampleShift = Data.dSubSampleShift;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,C,D,E,'dSubSampleShift',G_d,H,I);
	warning(msg);
end

%	dLocationX			[scalar(1*1),double]		[]				[C]
if 1 == isscalar(Data.dLocationX) && 1 == isa(Data.dLocationX,'double')
	%	OK
	nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(SEGSOURCEID).dLocationX = Data.dLocationX;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,C,D,E,'dLocationX',G_d,H,I);
	warning(msg);
end

%	dLocationY			[scalar(1*1),double]		[]				[C]
if 1 == isscalar(Data.dLocationY) && 1 == isa(Data.dLocationY,'double')
	%	OK
	nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(SEGSOURCEID).dLocationY = Data.dLocationY;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,C,D,E,'dLocationY',G_d,H,I);
	warning(msg);
end

%	dLocationZ			[scalar(1*1),double]		[]				[C]
if 1 == isscalar(Data.dLocationZ) && 1 == isa(Data.dLocationZ,'double')
	%	OK
	nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(SEGSOURCEID).dLocationZ = Data.dLocationZ;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,C,D,E,'dLocationZ',G_d,H,I);
	warning(msg);
end

%	dLocationUser		[scalar(1*1),double]		[]				[C]
if 1 == isscalar(Data.dLocationUser) && 1 == isa(Data.dLocationUser,'double')
	%	OK
	nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(SEGSOURCEID).dLocationUser = Data.dLocationUser;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,C,D,E,'dLocationUser',G_d,H,I);
	warning(msg);
end

%	dHighFreqCorner		[scalar(1*1),double]		[]				[C]
if 1 == isscalar(Data.dHighFreqCorner) && 1 == isa(Data.dHighFreqCorner,'double')
	%	OK
	nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(SEGSOURCEID).dHighFreqCorner = Data.dHighFreqCorner;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,C,D,E,'dHighFreqCorner',G_d,H,I);
	warning(msg);
end

%	dwHighFreqOrder		[scalar(1*1),uint32]		[]				[C]
if	1 == isnumeric(Data.dwHighFreqOrder)	%	numeric?
	if Data.dwHighFreqOrder == fix(Data.dwHighFreqOrder) && 0 <= Data.dwHighFreqOrder	%	0 or natural number?
		if 1 == isscalar(Data.dwHighFreqOrder)	%	scalar(1*1)?
			%	OK
			Data.dwHighFreqOrder = uint32(fix(Data.dwHighFreqOrder));	%	cast to uint32 ( if type of Data.dwHighFreqOrder is double, uint8, ... )
			nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(SEGSOURCEID).dwHighFreqOrder = Data.dwHighFreqOrder;
		else
			%	NG - WARNING - wrong type - not scalar(1*1)
			msg = strcat(A_TY,B,C,D,E,'dwHighFreqOrder',G_dw,H,I);
			warning(msg);
		end
	else
		%	NG - WARNING - wrong type - not 0 or natural number
		msg = strcat(A_TY,B,C,D,E,'dwHighFreqOrder',G_dw,H,I);
		warning(msg);	
	end
else
	%	NG - WARNING - wrong type - not numeric
	msg = strcat(A_TY,B,C,D,E,'dwHighFreqOrder',G_dw,H,I);
	warning(msg);
end

%	szHighFilterType	[char]						[]				[C]
if 1 == isa(Data.szHighFilterType,'char')
	%	OK
	nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(SEGSOURCEID).szHighFilterType = Data.szHighFilterType;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,C,D,E,'szHighFilterType',G_sz,H,I);
	warning(msg);
end

%	dLowFreqCorner		[scalar(1*1),double]		[]				[C]
if 1 == isscalar(Data.dLowFreqCorner) && 1 == isa(Data.dLowFreqCorner,'double')
	%	OK
	nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(SEGSOURCEID).dLowFreqCorner = Data.dLowFreqCorner;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,C,D,E,'dLowFreqCorner',G_d,H,I);
	warning(msg);
end

%	dwLowFreqOrder		[scalar(1*1),uint32]		[]				[C]
if	1 == isnumeric(Data.dwLowFreqOrder)	%	numeric?
	if Data.dwLowFreqOrder == fix(Data.dwLowFreqOrder) && 0 <= Data.dwLowFreqOrder	%	0 or natural number?
		if 1 == isscalar(Data.dwLowFreqOrder)	%	scalar(1*1)?
			%	OK
			Data.dwLowFreqOrder = uint32(fix(Data.dwLowFreqOrder));	%	cast to uint32 ( if type of Data.dwHighFreqOrder is double, uint8, ... )
			nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(SEGSOURCEID).dwLowFreqOrder = Data.dwLowFreqOrder;
		else
			%	NG - WARNING - wrong type - not scalar(1*1)
			msg = strcat(A_TY,B,C,D,E,'dwLowFreqOrder',G_dw,H,I);
			warning(msg);
		end
	else
		%	NG - WARNING - wrong type - not 0 or natural number
		msg = strcat(A_TY,B,C,D,E,'dwLowFreqOrder',G_dw,H,I);
		warning(msg);	
	end
else
	%	NG - WARNING - wrong type - not numeric
	msg = strcat(A_TY,B,C,D,E,'dwLowFreqOrder',G_dw,H,I);
	warning(msg);
end

%	szLowFilterType		[char]						[]				[C]
if 1 == isa(Data.szLowFilterType,'char')
	%	OK
	nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(SEGSOURCEID).szLowFilterType = Data.szLowFilterType;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,C,D,E,'szLowFilterType',G_sz,H,I);
	warning(msg);
end

%	szProbeInfo			[char]						[]				[C]
if 1 == isa(Data.szProbeInfo,'char')
	%	OK
	nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(SEGSOURCEID).szProbeInfo = Data.szProbeInfo;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,C,D,E,'szProbeInfo',G_sz,H,I);
	warning(msg);
end

