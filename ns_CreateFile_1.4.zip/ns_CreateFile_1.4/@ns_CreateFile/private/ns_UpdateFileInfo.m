function nsObj = ns_UpdateFileInfo( nsObj, Data )
% ns_UpdateFileInfo - Update ns_FILEINFO.
% nsObj = ns_UpdateFileInfo( nsObj, Data )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   Data      - [struct] - nsa_FILEINFO which user modified.
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/05/07 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

%	List of ns_FILEINFO

%   [OK RANGE]
%       System allows user to change this value only within the range.
%       If user set value over this range, then system remains it and displays WARNING message. ( NOT ERROR )

%   [KIND]
%       A : User can't change this value. Only system can set it.  
%       B : User can change this value. System can set it, too. (The larger max val [least min val] is adopted.)
%       C : User can change this value. System doesn't set it.

%	[NAME]              [TYPE]						[OK RANGE]  	[KIND]
%	szFileType			[char]						[]				[C]
%	dwEntityCount		[scalar(1*1),uint32]		[]				[A]
%	dTimeStampResolution[scalar(1*1),double]		[]				[C]
%	dTimeSpan			[scalar(1*1),double]		[]				[C]
%	szAppName			[char]						[]				[C]
%	dwTime_Year			[scalar(1*1),uint32]		[]				[C]
%	dwTime_Month		[scalar(1*1),uint32]		[1-12]			[C]
%	dwTime_DayOfWeek	[scalar(1*1),uint32]		[0-6]			[C]
%	dwTime_Day			[scalar(1*1),uint32]		[1-31]			[C]
%	dwTime_Hour			[scalar(1*1),uint32]		[0-23]			[C]
%	dwTime_Min			[scalar(1*1),uint32]		[0-59]			[C]
%	dwTime_Sec			[scalar(1*1),uint32]		[0-59]			[C]
%	dwTime_MilliSec		[scalar(1*1),uint32]		[0-1000]		[C]
%	szFileComment		[char]						[]				[C]

A_TY = nsObj.MESSAGE.WRONGINFOTYPE;
A_VL = nsObj.MESSAGE.WRONGINFOVALUE;
A_NP = nsObj.MESSAGE.NOTPOSSIBLETOSETVALUE;
B = nsObj.MESSAGE.ns_FILEINFO;
%	C	NAME of the member.
D_d = nsObj.MESSAGE.MUSTBEd; 
D_dw = nsObj.MESSAGE.MUSTBEdw; 
D_sz = nsObj.MESSAGE.MUSTBEsz;
D_SF = nsObj.MESSAGE.SETBYFUNCTION;
E =	nsObj.MESSAGE.COLON;
F = nsObj.MESSAGE.THISISNOTUPDATED;

%	szFileType			[char]						[]				[C]
if 1 == isa(Data.szFileType,'char')
	%	OK
	nsObj.ns_FILEINFO.szFileType = Data.szFileType;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'szFileType',D_sz,E,F);
	warning(msg);
end

%	dwEntityCount		[scalar(1*1),uint32]		[]				[A]
%   It is no need to check it.
%   Data doesn't have this member.

%	dTimeStampResolution[scalar(1*1),double]		[]				[C]
if 1 == isscalar(Data.dTimeStampResolution) && 1 == isa(Data.dTimeStampResolution,'double')
	%	OK
	nsObj.ns_FILEINFO.dTimeStampResolution = Data.dTimeStampResolution;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'dTimeStampResolution',D_d,E,F);
	warning(msg);
end

%	dTimeSpan			[scalar(1*1),double]		[]				[C]
if 1 == isscalar(Data.dTimeSpan) && 1 == isa(Data.dTimeSpan,'double')
	%	OK
	nsObj.ns_FILEINFO.dTimeSpan = Data.dTimeSpan;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'dTimeSpan',D_d,E,F);
	warning(msg);
end

%	szAppName			[char]						[]				[C]
if 1 == isa(Data.szAppName,'char')
	%	OK
	nsObj.ns_FILEINFO.szAppName = Data.szAppName;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'szAppName',D_sz,E,F);
	warning(msg);
end

%	dwTime_Year			[scalar(1*1),uint32]		[]				[C]
if	1 == isnumeric(Data.dwTime_Year)	%	numeric?
	if Data.dwTime_Year == fix(Data.dwTime_Year) && 0 <= Data.dwTime_Year	%	0 or natural number?
		if 1 == isscalar(Data.dwTime_Year)	%	scalar(1*1)?
			%	OK
			Data.dwTime_Year = uint32(fix(Data.dwTime_Year));	%	cast to uint32 ( if type of Data.dwHighFreqOrder is double, uint8, ... )
			nsObj.ns_FILEINFO.dwTime_Year = Data.dwTime_Year;
		else
			%	NG - WARNING - wrong type - not scalar(1*1)
			msg = strcat(A_TY,B,'dwTime_Year',D_dw,E,F);
			warning(msg);
		end
	else
		%	NG - WARNING - wrong type - not 0 or natural number
		msg = strcat(A_TY,B,'dwTime_Year',D_dw,E,F);
		warning(msg);	
	end
else
	%	NG - WARNING - wrong type - not numeric
	msg = strcat(A_TY,B,'dwTime_Year',D_dw,E,F);
	warning(msg);
end

%	dwTime_Month		[scalar(1*1),uint32]		[1-12]			[C]
if	1 == isnumeric(Data.dwTime_Month)	%	numeric?
	if Data.dwTime_Month == fix(Data.dwTime_Month) && 0 <= Data.dwTime_Month	%	0 or natural number?
		if 1 == isscalar(Data.dwTime_Month)	%	scalar(1*1)?
			if 1 <= Data.dwTime_Month && Data.dwTime_Month <= 12	%	in the range?
				%	OK
				Data.dwTime_Month = uint32(fix(Data.dwTime_Month));	%	cast to uint32 ( if type of Data.dwHighFreqOrder is double, uint8, ... )
				nsObj.ns_FILEINFO.dwTime_Month = Data.dwTime_Month;
			else
				%	NG - WARNING - wrong value - out of the range
				msg = strcat(A_VL,B,'dwTime_Month','(MUST BE [1-12])',E,F);
				warning(msg);
			end
		else
			%	NG - WARNING - wrong type - not scalar(1*1)
			msg = strcat(A_TY,B,'dwTime_Month',D_dw,E,F);
			warning(msg);
		end
	else
		%	NG - WARNING - wrong type - not 0 or natural number
		msg = strcat(A_TY,B,'dwTime_Month',D_dw,E,F);
		warning(msg);	
	end
else
	%	NG - WARNING - wrong type - not numeric
	msg = strcat(A_TY,B,'dwTime_Month',D_dw,E,F);
	warning(msg);
end

%	dwTime_DayOfWeek	[scalar(1*1),uint32]		[0-6]			[C]
if	1 == isnumeric(Data.dwTime_DayOfWeek)	%	numeric?
	if Data.dwTime_DayOfWeek == fix(Data.dwTime_DayOfWeek) && 0 <= Data.dwTime_DayOfWeek	%	0 or natural number?
		if 1 == isscalar(Data.dwTime_DayOfWeek)	%	scalar(1*1)?
			if 0 <= Data.dwTime_DayOfWeek && Data.dwTime_DayOfWeek <= 6 %	in the range?
				%	OK
				Data.dwTime_DayOfWeek = uint32(fix(Data.dwTime_DayOfWeek));	%	cast to uint32 ( if type of Data.dwHighFreqOrder is double, uint8, ... )
				nsObj.ns_FILEINFO.dwTime_DayOfWeek = Data.dwTime_DayOfWeek;
			else
				%	NG - WARNING - wrong value - out of the range
				msg = strcat(A_VL,B,'dwTime_DayOfWeek','(MUST BE [0-6])',E,F);
				warning(msg);
			end
		else
			%	NG - WARNING - wrong type - not scalar(1*1)
			msg = strcat(A_TY,B,'dwTime_DayOfWeek',D_dw,E,F);
			warning(msg);
		end
	else
		%	NG - WARNING - wrong type - not 0 or natural number
		msg = strcat(A_TY,B,'dwTime_DayOfWeek',D_dw,E,F);
		warning(msg);	
	end
else
	%	NG - WARNING - wrong type - not numeric
	msg = strcat(A_TY,B,'dwTime_DayOfWeek',D_dw,E,F);
	warning(msg);
end

%	dwTime_Day			[scalar(1*1),uint32]		[1-31]			[C]
if	1 == isnumeric(Data.dwTime_Day)	%	numeric?
	if Data.dwTime_Day == fix(Data.dwTime_Day) && 0 <= Data.dwTime_Day	%	0 or natural number?
		if 1 == isscalar(Data.dwTime_Day)	%	scalar(1*1)?
			if 1 <= Data.dwTime_Day && Data.dwTime_Day <= 31 %	in the range?
				%	OK
				Data.dwTime_Day = uint32(fix(Data.dwTime_Day));	%	cast to uint32 ( if type of Data.dwHighFreqOrder is double, uint8, ... )
				nsObj.ns_FILEINFO.dwTime_Day = Data.dwTime_Day;
			else
				%	NG - WARNING - wrong value - out of the range
				msg = strcat(A_VL,B,'dwTime_Day','(MUST BE [1-31])',E,F);
				warning(msg);
			end
		else
			%	NG - WARNING - wrong type - not scalar(1*1)
			msg = strcat(A_TY,B,'dwTime_Day',D_dw,E,F);
			warning(msg);
		end
	else
		%	NG - WARNING - wrong type - not 0 or natural number
		msg = strcat(A_TY,B,'dwTime_Day',D_dw,E,F);
		warning(msg);	
	end
else
	%	NG - WARNING - wrong type - not numeric
	msg = strcat(A_TY,B,'dwTime_Day',D_dw,E,F);
	warning(msg);
end

%	dwTime_Hour			[scalar(1*1),uint32]		[0-23]			[C]
if	1 == isnumeric(Data.dwTime_Hour)	%	numeric?
	if Data.dwTime_Hour == fix(Data.dwTime_Hour) && 0 <= Data.dwTime_Hour	%	0 or natural number?
		if 1 == isscalar(Data.dwTime_Hour)	%	scalar(1*1)?
			if 0 <= Data.dwTime_Hour && Data.dwTime_Hour <= 23  %	in the range?
				%	OK
				Data.dwTime_Hour = uint32(fix(Data.dwTime_Hour));	%	cast to uint32 ( if type of Data.dwHighFreqOrder is double, uint8, ... )
				nsObj.ns_FILEINFO.dwTime_Hour = Data.dwTime_Hour;
			else
				%	NG - WARNING - wrong value - out of the range
				msg = strcat(A_VL,B,'dwTime_Hour','(MUST BE [0-23])',E,F);
				warning(msg);
			end
		else
			%	NG - WARNING - wrong type - not scalar(1*1)
			msg = strcat(A_TY,B,'dwTime_Hour',D_dw,E,F);
			warning(msg);
		end
	else
		%	NG - WARNING - wrong type - not 0 or natural number
		msg = strcat(A_TY,B,'dwTime_Hour',D_dw,E,F);
		warning(msg);	
	end
else
	%	NG - WARNING - wrong type - not numeric
	msg = strcat(A_TY,B,'dwTime_Hour',D_dw,E,F);
	warning(msg);
end

%	dwTime_Min			[scalar(1*1),uint32]		[0-59]			[C]
if	1 == isnumeric(Data.dwTime_Min)	%	numeric?
	if Data.dwTime_Min == fix(Data.dwTime_Min) && 0 <= Data.dwTime_Min	%	0 or natural number?
		if 1 == isscalar(Data.dwTime_Min)	%	scalar(1*1)?
			if 0 <= Data.dwTime_Min && Data.dwTime_Min <= 59  %	in the range?
				%	OK
				Data.dwTime_Min = uint32(fix(Data.dwTime_Min));	%	cast to uint32 ( if type of Data.dwHighFreqOrder is double, uint8, ... )
				nsObj.ns_FILEINFO.dwTime_Min = Data.dwTime_Min;
			else
				%	NG - WARNING - wrong value - out of the range
				msg = strcat(A_VL,B,'dwTime_Min','(MUST BE [0-59])',E,F);
				warning(msg);
			end
		else
			%	NG - WARNING - wrong type - not scalar(1*1)
			msg = strcat(A_TY,B,'dwTime_Min',D_dw,E,F);
			warning(msg);
		end
	else
		%	NG - WARNING - wrong type - not 0 or natural number
		msg = strcat(A_TY,B,'dwTime_Min',D_dw,E,F);
		warning(msg);	
	end
else
	%	NG - WARNING - wrong type - not numeric
	msg = strcat(A_TY,B,'dwTime_Min',D_dw,E,F);
	warning(msg);
end

%	dwTime_Sec			[scalar(1*1),uint32]		[0-59]			[C]
if	1 == isnumeric(Data.dwTime_Sec)	%	numeric?
	if Data.dwTime_Sec == fix(Data.dwTime_Sec) && 0 <= Data.dwTime_Sec	%	0 or natural number?
		if 1 == isscalar(Data.dwTime_Sec)	%	scalar(1*1)?
			if 0 <= Data.dwTime_Sec && Data.dwTime_Sec <= 59  %	in the range?
				%	OK
				Data.dwTime_Sec = uint32(fix(Data.dwTime_Sec));	%	cast to uint32 ( if type of Data.dwHighFreqOrder is double, uint8, ... )
				nsObj.ns_FILEINFO.dwTime_Sec = Data.dwTime_Sec;
			else
				%	NG - WARNING - wrong value - out of the range
				msg = strcat(A_VL,B,'dwTime_Sec','(MUST BE [0-59])',E,F);
				warning(msg);
			end
		else
			%	NG - WARNING - wrong type - not scalar(1*1)
			msg = strcat(A_TY,B,'dwTime_Sec',D_dw,E,F);
			warning(msg);
		end
	else
		%	NG - WARNING - wrong type - not 0 or natural number
		msg = strcat(A_TY,B,'dwTime_Sec',D_dw,E,F);
		warning(msg);	
	end
else
	%	NG - WARNING - wrong type - not numeric
	msg = strcat(A_TY,B,'dwTime_Sec',D_dw,E,F);
	warning(msg);
end

%	dwTime_MilliSec		[scalar(1*1),uint32]		[0-1000]		[C]
if	1 == isnumeric(Data.dwTime_MilliSec)	%	numeric?
	if Data.dwTime_MilliSec == fix(Data.dwTime_MilliSec) && 0 <= Data.dwTime_MilliSec	%	0 or natural number?
		if 1 == isscalar(Data.dwTime_MilliSec)	%	scalar(1*1)?
			if 0 <= Data.dwTime_MilliSec && Data.dwTime_MilliSec <= 1000  %	in the range?
				%	OK
				Data.dwTime_MilliSec = uint32(fix(Data.dwTime_MilliSec));	%	cast to uint32 ( if type of Data.dwHighFreqOrder is double, uint8, ... )
				nsObj.ns_FILEINFO.dwTime_MilliSec = Data.dwTime_MilliSec;
			else
				%	NG - WARNING - wrong value - out of the range
				msg = strcat(A_VL,B,'dwTime_MilliSec','(MUST BE [0-1000])',E,F);
				warning(msg);
			end
		else
			%	NG - WARNING - wrong type - not scalar(1*1)
			msg = strcat(A_TY,B,'dwTime_MilliSec',D_dw,E,F);
			warning(msg);
		end
	else
		%	NG - WARNING - wrong type - not 0 or natural number
		msg = strcat(A_TY,B,'dwTime_MilliSec',D_dw,E,F);
		warning(msg);	
	end
else
	%	NG - WARNING - wrong type - not numeric
	msg = strcat(A_TY,B,'dwTime_MilliSec',D_dw,E,F);
	warning(msg);
end

%	szFileComment		[char]						[]				[C]
if 1 == isa(Data.szFileComment,'char')
	%	OK
	nsObj.ns_FILEINFO.szFileComment = Data.szFileComment;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'szFileComment',D_sz,E,F);
	warning(msg);
end
