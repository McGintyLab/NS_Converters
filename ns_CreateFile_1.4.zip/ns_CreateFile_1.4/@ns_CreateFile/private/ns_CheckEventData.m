function ns_Result = ns_CheckEventData( nsObj, dTime, EventValue )
% ns_CheckEventData - Check dTime and EventValue.
% ns_Result = ns_CheckEventData( nsObj, dTime, EventValue )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   dTime     - [double] - timestamp.
%	EventValue [(u)int8, (u)int16, (u)int32 or char] - event value.
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/05/06 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

ns_Result = nsObj.CONST.ns_OK;

%   check type of dTime.
if 0 ~= CheckTypeOfdTime( dTime )
	
	%	ERROR:WRONGDATATYPE
	A{1} = nsObj.MESSAGE.ERROR;
	A{2} = nsObj.MESSAGE.WRONGDATATYPE;
	A{3} = 'EventData';
	A{4} = nsObj.MESSAGE.COLON;
	A{5} = 'dTimestamp';
	A{6} = nsObj.MESSAGE.MUSTBEd;
	A{7} = nsObj.MESSAGE.COLON;
	A{8} = nsObj.MESSAGE.STOPSEQUENCE;
	
	msgct = strcat(A{:});
	
	disp(msgct);
    
	%   as debug
    dbstack;
    
	%	wrong DATA
	ns_Result = nsObj.CONST.ns_WRONGDATA;
	return;
end

%   check type of EventValue.
if 0 ~= CheckTypeOfEventValue( EventValue )
	
	%	ERROR:WRONGDATATYPE
	A{1} = nsObj.MESSAGE.ERROR;
	A{2} = nsObj.MESSAGE.WRONGDATATYPE;
	A{3} = 'EventData';
	A{4} = nsObj.MESSAGE.COLON;
	A{5} = 'EventValue';
	A{6} = '(MUST BE (u)int8 or (u)int16 or (u)int32 or char )';
	A{7} = nsObj.MESSAGE.COLON;
	A{8} = nsObj.MESSAGE.STOPSEQUENCE;
	
	msgct = strcat(A{:});
	
	disp(msgct);

    %   as debug
    dbstack;
    
	%	wrong DATA
	ns_Result = nsObj.CONST.ns_WRONGDATA;
	return;
end

%	It is not needed to check value of dTime and EventValue.


%**************************************************************************
function ns_Result = CheckTypeOfdTime( dTime )
%	check type of dTime
%	If type of the value meets the following conditions, it is correct.
%   1. scalar(1*1)
%   2. double

check.isscalar(1) = isscalar( dTime );			%	Is it scalar?
check.type(1) = isa( dTime, 'double' );			%	Is it double?

size_isscalar = size( check.isscalar, 2 );
correct_isscalar = ones( 1, size_isscalar );

size_type = size( check.type, 2 );
correct_type = ones( 1, size_type );

if isequal( check.isscalar, correct_isscalar ) ~= 1
%%	NG
	ns_Result = -1;		%	not scalar.

elseif isequal( check.type, correct_type ) ~= 1
%%	NG
	ns_Result = -2;		%	not double.

else
%%	OK
	ns_Result = 0;		%	no problems.
end

%**************************************************************************
function ns_Result = CheckTypeOfEventValue( EventValue )
%	check type of EventValue
%	If type of the value meets the following conditions, it is correct.
%   1. (u)int8 or (u)int16 or (u)int32 or double or char
%   2. scalar(1*1) if type of it is (u)int8 or (u)int16 or (u)int32 or double
%   3. vector(1*n) if type of it is char

ns_Result = 0;

check.class = class( EventValue );				%	get class

switch (check.class)
	
	%	char
	case 'char'
		check.size = size( EventValue, 1 );

		if 1 ~= check.size
%%	NG
			ns_Result = -1;						%	not vector
			return;
		end

	%	double
	case 'double'
		check.size = isscalar( EventValue );
		check.value = fix( EventValue );    	%   fix : round toward zero

		if 1 ~= check.size
%%	NG
			ns_Result = -2;						%	not scalar(1*1)
			return;
		end

		if EventValue ~= check.value
%%	NG
			ns_Result = -3;						%	not convert to integer
			return;
		end

	%	(u)int8,(u)int16,(u)int32	
	case { 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32' }
		check.size = isscalar( EventValue );
		
		if 1 ~= check.size
%%	NG
			ns_Result = -4;						%	not scalar(1*1)
			return;
		end
	
	%	other type [cell�Astruct ���etc]
	otherwise
%%	NG
		ns_Result = -5;							%	not suitable
		return;
end

%%	OK
