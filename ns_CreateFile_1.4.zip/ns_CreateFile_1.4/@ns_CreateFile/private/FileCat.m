function ns_Result = FileCat(nsObj, dstFile, srcFile)
% FileCat - Integrate 2 files. Add srcFile to dstFile.
% ns_Result = FileCat( nsObj, dstFile, srcFile )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   dstFile   - [char]   - full path of the target file.
%   srcFile   - [char]   - full path of the source file.
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/05/13 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

try
    % Source file exits?
    if 0 == exist(srcFile,'file');  %   NOT EXIST : 0
        % Case : data of the entity is empty. ( Only headers. like this... the entity has only [ns_TAGELEMENT + ns_ENTITYINFO + ns_NEURALINFO]. )
        ns_Result = nsObj.CONST.ns_OK;
        return;
    end
        
    % Use 1MByte of memorys
	bufSize = 2^20;
	
    % Open the target file as ADD mode
    fidDst = fopen(dstFile, 'a');

    % Open the source file as READONLY mode
	fidSrc = fopen(srcFile, 'r');

	while 1
		buffer = fread(fidSrc, bufSize, 'uint8=>uint8');
		if isempty(buffer)
			break
		end
		fwrite(fidDst, buffer, 'uint8');
	end
	fclose(fidDst);
	fclose(fidSrc);
	
	ns_Result = nsObj.CONST.ns_OK;
catch

    % File handling error
	A{1} = nsObj.MESSAGE.FILEMANIPULATIONERROR;
	A{2} = 'Integrate Files :';
	A{3} = dstFile;
	A{4} = ' with ';
	A{5} = srcFile;
	A{6} = nsObj.MESSAGE.COLON;
	A{7} = nsObj.MESSAGE.STOPSEQUENCE;
	
	msg = strcat(A{:});
	
	disp(msg);
	
    % as debug
    dbstack;
    
	% File integration error
	ns_Result = nsObj.CONST.ns_FILEERROR;

end