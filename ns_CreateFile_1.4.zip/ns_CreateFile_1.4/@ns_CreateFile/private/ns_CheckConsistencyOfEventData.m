function ns_Result = ns_CheckConsistencyOfEventData( nsObj, ID, EventValue )
% ns_CheckConsistencyOfEventData - Check consistency of event data.
% ns_Result = ns_CheckConsistencyOfEventData( nsObj, ID, EventValue )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   ID        - [uint32] - identification number.
%	EventValue [(u)int8, (u)int16, (u)int32 or char] - event value.
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/05/06 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

ns_Result = nsObj.CONST.ns_OK;

%	if number of records is zero, then OK. (means first record.)
if	0 == nsObj.Event{ID}.ns_ENTITYINFO.dwItemCount
	return;
end

%	check consistency
if	0 ~= CheckConsistencyOfEventData( nsObj, ID, EventValue )

	%	ERROR:WRONGDATATYPE
	A{1} = nsObj.MESSAGE.ERROR;
	A{2} = nsObj.MESSAGE.WRONGDATATYPE;
	A{3} = 'EventData';
	A{4} = nsObj.MESSAGE.COLON;
	A{5} = 'EventValue';
	A{6} = '(Must be Consistency Type )';
	A{7} = nsObj.MESSAGE.COLON;
	A{8} = nsObj.MESSAGE.STOPSEQUENCE;
	
	msgct = strcat(A{:});
	
	disp(msgct);
	
    %   as debug
    dbstack;
    
	%	wrong DATA
	ns_Result = nsObj.CONST.ns_WRONGDATA;
	return;
end


%**************************************************************************
function ns_Result = CheckConsistencyOfEventData( nsObj, ID, EventValue )
%	check type of EventValue
%	If type of the value meets the following conditions, it is correct.
%   1. dwEventType of EventValue equals nsObj.Event{ID}.ns_EVENTINFO.dwEventType.

%	get type of EventValue
A = class( EventValue );

%	get dwEventType of nsObj.Event{ID}.ns_EVENTINFO
B = nsObj.Event{ID}.ns_EVENTINFO.dwEventType;

%   get dwEventType of EventValue
switch (A)
	case 'char'
		C = nsObj.CONST.ns_EVENT_TEXT;		
	case { 'uint8', 'int8' }
		C = nsObj.CONST.ns_EVENT_BYTE;
	case { 'uint16', 'int16' }
		C = nsObj.CONST.ns_EVENT_WORD;
	case { 'uint32', 'int32' }
		C = nsObj.CONST.ns_EVENT_DWORD;
	otherwise
%%	NG
		ns_Result = -2;	%	other type.
		return;		
end

if B ~= C
%%	NG
	ns_Result = -1;		%	not equals.

else
%%	OK
	ns_Result = 0;		%	no problems.
end

