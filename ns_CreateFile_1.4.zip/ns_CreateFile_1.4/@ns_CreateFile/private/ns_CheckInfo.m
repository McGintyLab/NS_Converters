function ns_Result = ns_CheckInfo( nsObj, set_INFO, kind )
% ns_CheckInfo - Check struct.
% ns_Result = ns_CheckInfo( nsObj, set_INFO, kind )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   set_INFO  - [struct] - nsa_***INFO which user want to set.
%	kind      - [char]   - set type. exam. 'nsa_ANALOGINFO'
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/05/06 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

ns_Result = nsObj.CONST.ns_OK;

%	check set_INFO 
if 1 ~= isstruct( set_INFO ) % Is it struct?

    %	ERROR:WRONGINFO
	A{1} = nsObj.MESSAGE.ERROR;
	A{2} = nsObj.MESSAGE.WRONGINFO;
	A{3} = 'set_INFO';
	A{4} = nsObj.MESSAGE.COLON;
	A{5} = nsObj.MESSAGE.THISISNOTSTRUCTURE;
	A{6} = nsObj.MESSAGE.COLON;
	A{7} = nsObj.MESSAGE.STOPSEQUENCE;

	msg = strcat(A{:});
	
	disp(msg);
	%   as debug
    dbstack;
    
	%	wrong HEADER
	ns_Result = nsObj.CONST.ns_WRONGHEADER;
	return;
end

%   Compare set_INFO with nsa_***INFO about below.
%   1.number of members
%   2.members name matching

%	get names of members (set_INFO).
Data = fieldnames( set_INFO );  % fieldnames : get names of members.

%   get number of members (set_INFO).
size_Data = size( Data, 1 );

%   get names of members (nsa_***INFO).
switch (kind)
	
	case 'nsa_FILEINFO'
		[ret CorrectInfo] = ns_GetFileInfo( nsObj );
		%ref = '[ref. help ns_SetFileInfo]';
	case 'nsa_EVENTINFO'
		[ret CorrectInfo] = ns_GetEventInfo( nsObj, 1 );
		%ref = '[ref. help ns_SetEventInfo]';
	case 'nsa_ANALOGINFO'
		[ret CorrectInfo] = ns_GetAnalogInfo( nsObj, 1 );		
		%ref = '[ref. help ns_SetAnalogInfo]';
	case 'nsa_SEGMENTINFO'
		[ret CorrectInfo] = ns_GetSegmentInfo( nsObj, 1 );
		%ref = '[ref. help ns_SetSegmentInfo]';
	case 'nsa_SEGSOURCEINFO'
		[ret CorrectInfo] = ns_GetSegmentSourceInfo( nsObj, 1, 1 );
		%ref = '[ref. help ns_SetSegmentSourceInfo]';
	case 'nsa_NEURALINFO'
		[ret CorrectInfo] = ns_GetNeuralInfo( nsObj, 1 );
		%ref = '[ref. help ns_SetNeuralInfo]';
    otherwise

        %	Undefined Header.
		msg = 'WRONG_HEADER_NAME';

        disp(msg);
    	
        %	wrong HEADER
		ns_Result = nsObj.CONST.ns_WRONGHEADER;
		return;
end

%	get names of members (nsa_***INFO).
CorrectData = fieldnames( CorrectInfo );

%   get number of members (nsa_***INFO).
size_CorrectData = size( CorrectData, 1 );

%   compare set_INFO and nsa_***INFO
if size_CorrectData > size_Data
    
	%	ERROR:WRONGINFO
    A{1} = nsObj.MESSAGE.ERROR;
	A{2} = nsObj.MESSAGE.WRONGINFO;
	A{3} = kind;
	A{4} = nsObj.MESSAGE.COLON;
	A{5} = nsObj.MESSAGE.THISISNOTCORRECTSTRUCTURE;
	A{6} = nsObj.MESSAGE.COLON;
	%A{7} = ref;
	%A{8} = nsObj.MESSAGE.COLON;
	%A{9} = nsObj.MESSAGE.ALLMEMBERSOFTHISSTRUCTWERENOTUPDATED;
	A{7} = nsObj.MESSAGE.ALLMEMBERSOFTHISSTRUCTWERENOTUPDATED;

	msg = strcat(A{:});
	
	disp(msg);
	
	%   as debug
    dbstack;
    
	%	wrong HEADER
	ns_Result = nsObj.CONST.ns_WRONGHEADER;

else

	%	count is number of members (set_INFO).
	for ii = 1:size_Data

		%	search member of set_INFO from nsa_***INFO.
		if zeros(size_CorrectData,1) == strcmp(Data{ii},CorrectData)

			%	no hit
			A{1} = nsObj.MESSAGE.ERROR;
			A{2} = nsObj.MESSAGE.WRONGINFO;
			A{3} = kind;
			A{4} = '.';
			A{5} = Data{ii};
			A{6} = nsObj.MESSAGE.THEMEMBERDOESNOTEXIST;
			A{7} = nsObj.MESSAGE.COLON;
			%A{8} = ref;
			%A{9} = nsObj.MESSAGE.COLON;
			%A{10}= nsObj.MESSAGE.ALLMEMBERSOFTHISSTRUCTWERENOTUPDATED;
			A{8} = nsObj.MESSAGE.ALLMEMBERSOFTHISSTRUCTWERENOTUPDATED;

			msg = strcat(A{:});

			disp(msg);
		    
            %   as debug
            dbstack;
    
        	%	wrong HEADER
            ns_Result = nsObj.CONST.ns_WRONGHEADER;
		end
	end
end