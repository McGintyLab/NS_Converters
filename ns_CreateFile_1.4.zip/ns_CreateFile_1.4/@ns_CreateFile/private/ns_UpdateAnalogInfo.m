function nsObj = ns_UpdateAnalogInfo( nsObj, ID, Data )
% ns_UpdateAnalogInfo - Update ns_ANALOGINFO.
% nsObj = ns_UpdateAnalogInfo( nsObj, ID, Data )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   ID        - [uint32] - identification number.
%   Data      - [struct] - nsa_ANALOGINFO which user modified.
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/05/07 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

%	List of ns_ANALOGINFO

%   [OK RANGE]
%       System allows user to change this value only within the range.
%       If user set value over this range, then system remains it and displays WARNING message. ( NOT ERROR )

%   [KIND]
%       A : User can't change this value. Only system can set it.  
%       B : User can change this value. System can set it, too. (The larger max val [least min val] is adopted.)
%       C : User can change this value. System doesn't set it.

%	[NAME]              [TYPE]						[OK RANGE]  	[KIND]
%	dSampleRate			[scalar(1*1),double]		[]				[C]
%	dMinVal				[scalar(1*1),double]		[]				[B]
%	dMaxVal				[scalar(1*1),double]		[]				[B]
%	szUnits				[char]						[]				[C]
%	dResolution			[scalar(1*1),double]		[]				[C]
%	dLocationX			[scalar(1*1),double]		[]				[C]
%	dLocationY			[scalar(1*1),double]		[]				[C]
%	dLocationZ			[scalar(1*1),double]		[]				[C]
%	dLocationUser		[scalar(1*1),double]		[]				[C]
%	dHighFreqCorner		[scalar(1*1),double]		[]				[C]
%	dwHighFreqOrder		[scalar(1*1),uint32]		[]				[C]
%	szHighFilterType	[char]						[]				[C]
%	dLowFreqCorner		[scalar(1*1),double]		[]				[C]
%	dwLowFreqOrder		[scalar(1*1),uint32]		[]				[C]
%	szLowFilterType		[char]						[]				[C]
%	szProbeInfo			[char]						[]				[C]

A_TY = nsObj.MESSAGE.WRONGINFOTYPE;
A_VL = nsObj.MESSAGE.WRONGINFOVALUE;
B = nsObj.MESSAGE.ns_ANALOGINFO;
%	C	NAME of the member.
D_d = nsObj.MESSAGE.MUSTBEd; 
D_dw = nsObj.MESSAGE.MUSTBEdw; 
D_sz = nsObj.MESSAGE.MUSTBEsz; 
E =	nsObj.MESSAGE.COLON;
F = nsObj.MESSAGE.THISISNOTUPDATED;

%	dSampleRate			[scalar(1*1),double]		[]				[C]
if 1 == isscalar(Data.dSampleRate) && 1 == isa(Data.dSampleRate,'double')
	%	OK
	nsObj.Analog{ID}.ns_ANALOGINFO.dSampleRate = Data.dSampleRate;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'dSampleRate',D_d,E,F);
	warning(msg);
end

%	dMinVal				[scalar(1*1),double]		[]				[B]
if 1 == isscalar(Data.dMinVal) && 1 == isa(Data.dMinVal,'double')
	%	OK
	nsObj.Analog{ID}.ns_ANALOGINFO.dMinVal = Data.dMinVal;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'dMinVal',D_d,E,F);
	warning(msg);
end

%	dMaxVal				[scalar(1*1),double]		[]				[B]
if 1 == isscalar(Data.dMaxVal) && 1 == isa(Data.dMaxVal,'double')
	%	OK
	nsObj.Analog{ID}.ns_ANALOGINFO.dMaxVal = Data.dMaxVal;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'dMaxVal',D_d,E,F);
	warning(msg);
end

%	szUnits				[char]						[]				[C]
if 1 == isa(Data.szUnits,'char')
	%	OK
	nsObj.Analog{ID}.ns_ANALOGINFO.szUnits = Data.szUnits;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'szUnits',D_sz,E,F);
	warning(msg);
end

%	dResolution			[scalar(1*1),double]		[]				[C]
if 1 == isscalar(Data.dResolution) && 1 == isa(Data.dResolution,'double')
	%	OK
	nsObj.Analog{ID}.ns_ANALOGINFO.dResolution = Data.dResolution;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'dResolution',D_d,E,F);
	warning(msg);
end

%	dLocationX			[scalar(1*1),double]		[]				[C]
if 1 == isscalar(Data.dLocationX) && 1 == isa(Data.dLocationX,'double')
	%	OK
	nsObj.Analog{ID}.ns_ANALOGINFO.dLocationX = Data.dLocationX;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'dLocationX',D_d,E,F);
	warning(msg);
end

%	dLocationY			[scalar(1*1),double]		[]				[C]
if 1 == isscalar(Data.dLocationY) && 1 == isa(Data.dLocationY,'double')
	%	OK
	nsObj.Analog{ID}.ns_ANALOGINFO.dLocationY = Data.dLocationY;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'dLocationY',D_d,E,F);
	warning(msg);
end

%	dLocationZ			[scalar(1*1),double]		[]				[C]
if 1 == isscalar(Data.dLocationZ) && 1 == isa(Data.dLocationZ,'double')
	%	OK
	nsObj.Analog{ID}.ns_ANALOGINFO.dLocationZ = Data.dLocationZ;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'dLocationZ',D_d,E,F);
	warning(msg);
end

%	dLocationUser		[scalar(1*1),double]		[]				[C]
if 1 == isscalar(Data.dLocationUser) && 1 == isa(Data.dLocationUser,'double')
	%	OK
	nsObj.Analog{ID}.ns_ANALOGINFO.dLocationUser = Data.dLocationUser;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'dLocationUser',D_d,E,F);
	warning(msg);
end

%	dHighFreqCorner		[scalar(1*1),double]		[]				[C]
if 1 == isscalar(Data.dHighFreqCorner) && 1 == isa(Data.dHighFreqCorner,'double')
	%	OK
	nsObj.Analog{ID}.ns_ANALOGINFO.dHighFreqCorner = Data.dHighFreqCorner;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'dHighFreqCorner',D_d,E,F);
	warning(msg);
end

%	dwHighFreqOrder		[scalar(1*1),uint32]		[]				[C]
if	1 == isnumeric(Data.dwHighFreqOrder)	%	numeric?
	if Data.dwHighFreqOrder == fix(Data.dwHighFreqOrder) && 0 <= Data.dwHighFreqOrder	%	0 or natural number?
		if 1 == isscalar(Data.dwHighFreqOrder)	%	scalar(1*1)?
			%	OK
			Data.dwHighFreqOrder = uint32(fix(Data.dwHighFreqOrder));	%	cast to uint32 ( if type of Data.dwHighFreqOrder is double, uint8, ... )
			nsObj.Analog{ID}.ns_ANALOGINFO.dwHighFreqOrder = Data.dwHighFreqOrder;
		else
			%	NG - WARNING - wrong type - not scalar(1*1)
			msg = strcat(A_TY,B,'dwHighFreqOrder',D_dw,E,F);
			warning(msg);
		end
	else
		%	NG - WARNING - wrong type - not 0 or natural number
		msg = strcat(A_TY,B,'dwHighFreqOrder',D_dw,E,F);
		warning(msg);	
	end
else
	%	NG - WARNING - wrong type - not numeric
	msg = strcat(A_TY,B,'dwHighFreqOrder',D_dw,E,F);
	warning(msg);
end

%	szHighFilterType	[char]						[]				[C]
if 1 == isa(Data.szHighFilterType,'char')
	%	OK
	nsObj.Analog{ID}.ns_ANALOGINFO.szHighFilterType = Data.szHighFilterType;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'szHighFilterType',D_sz,E,F);
	warning(msg);
end

%	dLowFreqCorner		[scalar(1*1),double]		[]				[C]
if 1 == isscalar(Data.dLowFreqCorner) && 1 == isa(Data.dLowFreqCorner,'double')
	%	OK
	nsObj.Analog{ID}.ns_ANALOGINFO.dLowFreqCorner = Data.dLowFreqCorner;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'dLowFreqCorner',D_d,E,F);
	warning(msg);
end

%	dwLowFreqOrder		[scalar(1*1),uint32]		[]				[C]
if	1 == isnumeric(Data.dwLowFreqOrder)	%	numeric?
	if Data.dwLowFreqOrder == fix(Data.dwLowFreqOrder) && 0 <= Data.dwLowFreqOrder	%	0 or natural number?
		if 1 == isscalar(Data.dwLowFreqOrder)	%	scalar(1*1)?
			%	OK
			Data.dwLowFreqOrder = uint32(fix(Data.dwLowFreqOrder)); %	cast to uint32 ( if type of Data.dwHighFreqOrder is double, uint8, ... )
			nsObj.Analog{ID}.ns_ANALOGINFO.dwLowFreqOrder = Data.dwLowFreqOrder;
		else
			%	NG - WARNING - wrong type - not scalar(1*1)
			msg = strcat(A_TY,B,'dwLowFreqOrder',D_dw,E,F);
			warning(msg);
		end
	else
		%	NG - WARNING - wrong type - not 0 or natural number
		msg = strcat(A_TY,B,'dwLowFreqOrder',D_dw,E,F);
		warning(msg);	
	end
else
	%	NG - WARNING - wrong type - not numeric
	msg = strcat(A_TY,B,'dwLowFreqOrder',D_dw,E,F);
	warning(msg);
end

%	szLowFilterType		[char]						[]				[C]
if 1 == isa(Data.szLowFilterType,'char')
	%	OK
	nsObj.Analog{ID}.ns_ANALOGINFO.szLowFilterType = Data.szLowFilterType;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'szLowFilterType',D_sz,E,F);
	warning(msg);
end

%	szProbeInfo			[char]						[]				[C]
if 1 == isa(Data.szProbeInfo,'char')
	%	OK
	nsObj.Analog{ID}.ns_ANALOGINFO.szProbeInfo = Data.szProbeInfo;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'szProbeInfo',D_sz,E,F);
	warning(msg);
end

