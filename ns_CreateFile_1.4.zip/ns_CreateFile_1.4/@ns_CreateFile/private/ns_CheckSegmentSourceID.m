function ns_Result = ns_CheckSegmentSourceID( nsObj, SEGID, SEGSOURCEID )
% ns_CheckSegmentSourceID - Check SEGSOURCEID value.
% ns_Result = ns_CheckSegmentSourceID( nsObj, SEGID, SEGSOURCEID )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   SEGID     - [uint32] - identification number.
%   SEGSOURCEID - [uint32] - identification number of segementsource.
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/05/06 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

ns_Result = nsObj.CONST.ns_OK;

%	check type of SEGSOURCEID
if 0 ~= CheckTypeOfID( SEGSOURCEID )
	
	%	ERROR:WRONGIDTYPE
	A{1} = nsObj.MESSAGE.ERROR;
	A{2} = nsObj.MESSAGE.WRONGIDTYPE;
	A{3} = 'SEGSOURCEID';
	A{4} = nsObj.MESSAGE.MUSTBEdw;
	A{5} = nsObj.MESSAGE.COLON;
	A{6} = nsObj.MESSAGE.STOPSEQUENCE;
	
	msgct = strcat(A{:});
	
    disp(msgct);

    %   as debug
    dbstack;
    
	%	wrong ID
	ns_Result = nsObj.CONST.ns_WRONGID;
	return;
end

%   check value of SEGSOURCEID.
if 0 ~= CheckValueOfSEGMENTSOURCEID( nsObj, SEGID, SEGSOURCEID )

	%	ERROR:WRONGIDVALUE
	A{1} = nsObj.MESSAGE.ERROR;
	A{2} = nsObj.MESSAGE.WRONGIDVALUE;
	A{3} = 'SEGSOURCEID';
	A{4} = '(MUST BE Correct Entity ID)';
	A{5} = nsObj.MESSAGE.COLON;
	A{6} = nsObj.MESSAGE.STOPSEQUENCE;
	
	msgct = strcat(A{:});
	
	disp(msgct);

    %   as debug
    dbstack;
    
	%	wrong ID
	ns_Result = nsObj.CONST.ns_WRONGID;
	return;
end

%**************************************************************************
function ns_Result = CheckTypeOfID( ID )
%	check type of ID
%	If type of the value meets the following conditions, it is correct.
%   1. scalar(1*1)
%   2. numeric value
%   3. convert to 0 or natural number

check.isscalar(1) = isscalar( ID );				%	Is it scalar?
check.isnumeric(1) = isnumeric( ID );			%	Is it numeric?

size_isscalar = size( check.isscalar, 2 );
correct_isscalar = ones( 1, size_isscalar );

size_isnumeric = size( check.isnumeric, 2 );
correct_isnumeric = ones( 1, size_isnumeric );

if isequal( check.isscalar, correct_isscalar ) ~= 1
%%	NG
	ns_Result = -1;		%	not scalar.

elseif isequal( check.isnumeric, correct_isnumeric ) ~= 1
%%	NG
	ns_Result = -2;		%	not numeric.

elseif ID ~= fix(ID) || ID < 0
%%	NG
	ns_Result = -3;		%	not convert to 0 or natural number.

else
%%	OK
	ns_Result = 0;		%	no problems.
end

%**************************************************************************
function ns_Result = CheckValueOfSEGMENTSOURCEID( nsObj, SEGID, SEGSOURCEID )
%	check value of SEGSOURCEID
%	If the value meets the following conditions, it is correct.
%   1. nsObj.Segment{SEGID}.ns_SEGMENTINFO.dwSourceCount is not equal zero.
%   2. SEGSOURCEINFO is less than count of nsObj.Segment{SEGID}.ns_SEGMENTINFO.ns_SEGSOURCEINFO().

ns_Result = 0;

if 0 == nsObj.Segment{SEGID}.ns_SEGMENTINFO.dwSourceCount
%%	NG
	ns_Result = -1;		%	nsObj.Segment{SEGID}.ns_SEGMENTINFO.dwSourceCount is equal zero.
end

size_SegSource = size( nsObj.Segment{SEGID}.ns_SEGSOURCEINFO, 2 );	%	get source count.

if SEGSOURCEID > cast( size_SegSource, 'uint32' )
%%	NG
	ns_Result = -2;		%	number of ns_SEGSOURCEINFO < SEGSOURCEID
end
	
