function ns_Result = ns_SaveNeuralEventInfo(nsObj, ID)
% ns_SaveNeuralEventInfo - Save ns_NEURALINFO to intermediate file. ( 1 File / 1 Entity )
% ns_Result = ns_SaveNeuralEventInfo(nsObj, ID)
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   ID        - [uint32] - identification number.
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/05/07 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

try
    %   Intermediate file name.
	filename = fullfile( nsObj.directory,...
		[sprintf('_01_%05d_NeuralEventInfoHeader_', ID) nsObj.filename] );

	ns_TAGELEMENT = nsObj.NeuralEvent{ID}.ns_TAGELEMENT;
	ns_ENTITYINFO = nsObj.NeuralEvent{ID}.ns_ENTITYINFO;
	ns_NEURALINFO  = nsObj.NeuralEvent{ID}.ns_NEURALINFO;

	fid = fopen(filename, 'w');

	%   ns_TAGELEMENT
	fwrite(fid,ns_TAGELEMENT.dwElemType, 'uint32');
	fwrite(fid,ns_TAGELEMENT.dwElemLength, 'uint32');

	%   ns_ENTITYINFO
	s=[ns_ENTITYINFO.szEntityLabel blanks(32)];
	fwrite(fid,s(1:32));
	fwrite(fid,ns_ENTITYINFO.dwEntityType, 'uint32');
	fwrite(fid,ns_ENTITYINFO.dwItemCount, 'uint32');

	%   ns_NEURALINFO
	fwrite(fid,ns_NEURALINFO.dwSourceEntityID,'uint32');
	fwrite(fid,ns_NEURALINFO.dwSourceUnitID,'uint32');
	s=[ns_NEURALINFO.szProbeInfo blanks(128)];
	fwrite(fid,s(1:128));

	fclose(fid);
	ns_Result = nsObj.CONST.ns_OK;

catch

    % File handling error
    A{1} = nsObj.MESSAGE.FILEMANIPULATIONERROR;
	A{2} = 'Save NeuralInfo To Intermediate File';
	A{3} = nsObj.MESSAGE.COLON;
	A{4} = nsObj.MESSAGE.STOPSEQUENCE;
	
	msg = strcat(A{:});
	
	disp(msg);
	
    %   as debug
    dbstack;
    
	% File creation error
	ns_Result = nsObj.CONST.ns_FILEERROR;
end