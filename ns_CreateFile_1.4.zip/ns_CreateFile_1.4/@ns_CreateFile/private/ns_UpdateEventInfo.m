function nsObj = ns_UpdateEventInfo( nsObj, ID, Data )
% ns_UpdateEventInfo - Update ns_EVENTINFO.
% nsObj = ns_UpdateEventInfo( nsObj, ID, Data )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   ID        - [uint32] - identification number.
%   Data      - [struct] - nsa_EVENTINFO which user modified.
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/05/07 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

%	List of ns_EVENTINFO

%   [OK RANGE]
%       System allows user to change this value only within the range.
%       If user set value over this range, then system remains it and displays WARNING message. ( NOT ERROR )

%   [KIND]
%       A : User can't change this value. Only system can set it.  
%       B : User can change this value. System can set it, too. (The larger max val [least min val] is adopted.)
%       C : User can change this value. System doesn't set it.

%	[NAME]              [TYPE]						[OK RANGE]  	[KIND]
%	dwEventType			[scalar(1*1),uint32]		[0-4]			[A]
%	dwMinDataLength		[scalar(1*1),uint32]		[]				[A]
%	dwMaxDataLength		[scalar(1*1),uint32]		[]				[A]
%	szCSVDesc			[char]						[]				[C]

A_TY = nsObj.MESSAGE.WRONGINFOTYPE;
A_VL = nsObj.MESSAGE.WRONGINFOVALUE;
A_NP = nsObj.MESSAGE.NOTPOSSIBLETOSETVALUE;
B = nsObj.MESSAGE.ns_EVENTINFO;
%	C	NAME of the member.
D_d = nsObj.MESSAGE.MUSTBEd; 
D_dw = nsObj.MESSAGE.MUSTBEdw; 
D_sz = nsObj.MESSAGE.MUSTBEsz;
D_SF = nsObj.MESSAGE.SETBYFUNCTION;
E =	nsObj.MESSAGE.COLON;
F = nsObj.MESSAGE.THISISNOTUPDATED;

%	dwEventType			[scalar(1*1),uint32]		[0-4]			[A]
%   It is no need to check it.
%   Data doesn't have this member.

%	dwMinDataLength		[scalar(1*1),uint32]		[]				[A]
%   It is no need to check it.
%   Data doesn't have this member.

%	dwMaxDataLength		[scalar(1*1),uint32]		[]				[A]
%   It is no need to check it.
%   Data doesn't have this member.

%	szCSVDesc			[char]						[]				[C]
if 1 == isa(Data.szCSVDesc,'char')
	%	OK
	nsObj.Event{ID}.ns_EVENTINFO.szCSVDesc = Data.szCSVDesc;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'szCSVDesc',D_sz,E,F);
	warning(msg);
end
