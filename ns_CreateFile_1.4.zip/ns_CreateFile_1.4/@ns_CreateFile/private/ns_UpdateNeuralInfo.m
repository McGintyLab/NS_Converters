function nsObj = ns_UpdateNeuralInfo( nsObj, ID, Data )
% ns_UpdateNeuralInfo - Update ns_NEURALINFO.
% nsObj = ns_UpdateNeuralInfo( nsObj, ID, Data )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   ID        - [uint32] - identification number.
%   Data      - [struct] - nsa_NEURALINFO which user modified.
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/05/07 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

%	List of ns_NEURALINFO

%   [OK RANGE]
%       System allows user to change this value only within the range.
%       If user set value over this range, then system remains it and displays WARNING message. ( NOT ERROR )

%   [KIND]
%       A : User can't change this value. Only system can set it.  
%       B : User can change this value. System can set it, too. (The larger max val [least min val] is adopted.)
%       C : User can change this value. System doesn't set it.

%	[NAME]              [TYPE]						[OK RANGE]  	[KIND]
%	dwSourceEntityID	[scalar(1*1),uint32]		[]				[C]
%	dwSourceUnitID		[scalar(1*1),uint32]		[]				[C]
%	szProbeInfo			[char]						[]				[C]

A_TY = nsObj.MESSAGE.WRONGINFOTYPE;
A_VL = nsObj.MESSAGE.WRONGINFOVALUE;
B = nsObj.MESSAGE.ns_NEURALINFO;
%	C	NAME of the member.
D_d = nsObj.MESSAGE.MUSTBEd; 
D_dw = nsObj.MESSAGE.MUSTBEdw; 
D_sz = nsObj.MESSAGE.MUSTBEsz; 
E =	nsObj.MESSAGE.COLON;
F = nsObj.MESSAGE.THISISNOTUPDATED;

%	dwSourceEntityID	[scalar(1*1),uint32]		[]				[C]
if	1 == isnumeric(Data.dwSourceEntityID)	%	numeric?
	if Data.dwSourceEntityID == fix(Data.dwSourceEntityID) && 0 <= Data.dwSourceEntityID	%	0 or natural number?
		if 1 == isscalar(Data.dwSourceEntityID)	%	scalar(1*1)?
			%	OK
			Data.dwSourceEntityID = uint32(fix(Data.dwSourceEntityID));	%	cast to uint32 ( if type of Data.dwHighFreqOrder is double, uint8, ... )
			nsObj.NeuralEvent{ID}.ns_NEURALINFO.dwSourceEntityID = Data.dwSourceEntityID;
		else
			%	NG - WARNING - wrong type - not scalar(1*1)
			msg = strcat(A_TY,B,'dwSourceEntityID',D_dw,E,F);
			warning(msg);
		end
	else
		%	NG - WARNING - wrong type - not 0 or natural number
		msg = strcat(A_TY,B,'dwSourceEntityID',D_dw,E,F);
		warning(msg);	
	end
else
	%	NG - WARNING - wrong type - not numeric
	msg = strcat(A_TY,B,'dwSourceEntityID',D_dw,E,F);
	warning(msg);
end

%	dwSourceUnitID		[scalar(1*1),uint32]		[]				[C]
if	1 == isnumeric(Data.dwSourceUnitID)	%	numeric?
	if Data.dwSourceUnitID == fix(Data.dwSourceUnitID) && 0 <= Data.dwSourceUnitID	%	0 or natural number?
		if 1 == isscalar(Data.dwSourceUnitID)	%	scalar(1*1)?
			%	OK
			Data.dwSourceUnitID = uint32(fix(Data.dwSourceUnitID));	%	cast to uint32 ( if type of Data.dwHighFreqOrder is double, uint8, ... )
			nsObj.NeuralEvent{ID}.ns_NEURALINFO.dwSourceUnitID = Data.dwSourceUnitID;
		else
			%	NG - WARNING - wrong type - not scalar(1*1)
			msg = strcat(A_TY,B,'dwSourceUnitID',D_dw,E,F);
			warning(msg);
		end
	else
		%	NG - WARNING - wrong type - not 0 or natural number
		msg = strcat(A_TY,B,'dwSourceUnitID',D_dw,E,F);
		warning(msg);	
	end
else
	%	NG - WARNING - wrong type - not numeric
	msg = strcat(A_TY,B,'dwSourceUnitID',D_dw,E,F);
	warning(msg);
end

%	szProbeInfo			[char]						[]				[C]
if 1 == isa(Data.szProbeInfo,'char')
	%	OK
	nsObj.NeuralEvent{ID}.ns_NEURALINFO.szProbeInfo = Data.szProbeInfo;
else
	%	NG - WARNING - wrong type
	msg = strcat(A_TY,B,'szProbeInfo',D_sz,E,F);
	warning(msg);
end
