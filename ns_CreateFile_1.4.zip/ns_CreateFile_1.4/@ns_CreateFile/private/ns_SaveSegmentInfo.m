function ns_Result = ns_SaveSegmentInfo(nsObj, ID)
% ns_SaveSegmentInfo - Save ns_SEGMENTINFO to intermediate file. ( 1 File / 1 Entity )
% ns_Result = ns_SaveSegmentInfo(nsObj, ID)
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   ID        - [uint32] - identification number.
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/05/07 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

try
    %   Intermediate file name.
	filename = fullfile( nsObj.directory,...
		[sprintf('_01_%05d_SegmentInfoHeader_', ID) nsObj.filename] );

	ns_TAGELEMENT = nsObj.Segment{ID}.ns_TAGELEMENT;
	ns_ENTITYINFO = nsObj.Segment{ID}.ns_ENTITYINFO;
	ns_SEGMENTINFO  = nsObj.Segment{ID}.ns_SEGMENTINFO;
	%ns_SEGSOURCEINFO  = nsObj.Segment{ID}.ns_SEGSOURCEINFO;

	fid = fopen(filename, 'w');

	%   ns_TAGELEMENT
	fwrite(fid,ns_TAGELEMENT.dwElemType, 'uint32');
	fwrite(fid,ns_TAGELEMENT.dwElemLength, 'uint32');

	%   ns_ENTITYINFO
	s=[ns_ENTITYINFO.szEntityLabel blanks(32)];
	fwrite(fid,s(1:32));
	fwrite(fid,ns_ENTITYINFO.dwEntityType, 'uint32');
	fwrite(fid,ns_ENTITYINFO.dwItemCount, 'uint32');

	%   ns_SEGMENTINFO
	fwrite(fid,ns_SEGMENTINFO.dwSourceCount, 'uint32');
	fwrite(fid,ns_SEGMENTINFO.dwMinSampleCount, 'uint32');
	fwrite(fid,ns_SEGMENTINFO.dwMaxSampleCount, 'uint32');
	fwrite(fid,ns_SEGMENTINFO.dSampleRate, 'double');
	t=[ns_SEGMENTINFO.szUnits blanks(32)];
	fwrite(fid,t(1:32));

	%	ns_SEGSOURCEINFO(s) -> save to other files.
	%fwrite(fid,ns_SEGSOURCEINFO.dMinVal, 'double');
	%fwrite(fid,ns_SEGSOURCEINFO.dMaxVal, 'double');
	%fwrite(fid,ns_SEGSOURCEINFO.dResolution, 'double');
	%fwrite(fid,ns_SEGSOURCEINFO.dSubSampleShift, 'double');
	%fwrite(fid,ns_SEGSOURCEINFO.dLocationX, 'double');
	%fwrite(fid,ns_SEGSOURCEINFO.dLocationY, 'double');
	%fwrite(fid,ns_SEGSOURCEINFO.dLocationZ, 'double');
	%fwrite(fid,ns_SEGSOURCEINFO.dLocationUser, 'double');
	%fwrite(fid,ns_SEGSOURCEINFO.dHighFreqCorner, 'double');
	%fwrite(fid,ns_SEGSOURCEINFO.dwHighFreqOrder, 'uint32');
	%u=[ns_SEGSOURCEINFO.szHighFilterType blanks(16)];
	%fwrite(fid,u(1:16));
	%fwrite(fid,ns_SEGSOURCEINFO.dLowFreqCorner, 'double');
	%fwrite(fid,ns_SEGSOURCEINFO.dwLowFreqOrder, 'uint32');
	%u=[ns_SEGSOURCEINFO.szLowFilterType blanks(16)];
	%fwrite(fid,u(1:16));
	%v=[ns_SEGSOURCEINFO.szProbeInfo blanks(128)];
	%fwrite(fid,v(1:128));

	fclose(fid);
	ns_Result = nsObj.CONST.ns_OK;

catch

    % File handling error
	A{1} = nsObj.MESSAGE.FILEMANIPULATIONERROR;
	A{2} = 'Save SegmentInfo To Intermediate File';
	A{3} = nsObj.MESSAGE.COLON;
	A{4} = nsObj.MESSAGE.STOPSEQUENCE;
	
    msg = strcat(A{:});
	
	disp(msg);
	
    %   as debug
    dbstack;
    
	% File creation error
	ns_Result = nsObj.CONST.ns_FILEERROR;
end