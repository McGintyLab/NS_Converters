function ns_Result = ns_CheckID( nsObj, ID, dwEntityType )
% ns_CheckID - Check ID value.
% ns_Result = ns_CheckID( nsObj, ID, dwEntityType )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   ID        - [uint32] - identification number.
%   dwEntityType - [uint32] - type of entity.
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/05/06 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

ns_Result = nsObj.CONST.ns_OK;

%   check type of ID.
if 0 ~= CheckTypeOfID( ID )
	
	%	ERROR:WRONGIDTYPE
	A{1} = nsObj.MESSAGE.ERROR;
	A{2} = nsObj.MESSAGE.WRONGIDTYPE;
	A{3} = 'ID';
	A{4} = nsObj.MESSAGE.MUSTBEdw;
	A{5} = nsObj.MESSAGE.COLON;
	A{6} = nsObj.MESSAGE.STOPSEQUENCE;

	msgct = strcat(A{:});
	
	disp(msgct);

    %   as debug
    dbstack;
    
	%	wrong ID
	ns_Result = nsObj.CONST.ns_WRONGID;
	return;
end

%   check value of ID.
if 0 ~= CheckValueOfID( nsObj, ID, dwEntityType )

	%	ERROR:WRONGIDVALUE
	A{1} = nsObj.MESSAGE.ERROR;
	A{2} = nsObj.MESSAGE.WRONGIDVALUE;
	A{3} = 'ID';
	A{4} = '(MUST BE Correct Entity ID)';
	A{5} = nsObj.MESSAGE.COLON;
	A{6} = nsObj.MESSAGE.STOPSEQUENCE;
	
	msgcv = strcat(A{:});
	
	disp(msgcv);
	
    %   as debug
    dbstack;
    
	%	wrong ID
	ns_Result = nsObj.CONST.ns_WRONGID;
	return;
end

%**************************************************************************
function ns_Result = CheckTypeOfID( ID )
%	check type of ID
%	If type of the value meets the following conditions, it is correct.
%   1. scalar(1*1)
%   2. numeric value
%   3. convert to 0 or natural number

check.isscalar(1) = isscalar( ID );				%	Is it scalar?
check.isnumeric(1) = isnumeric( ID );			%	Is it numeric?

size_isscalar = size( check.isscalar, 2 );
correct_isscalar = ones( 1, size_isscalar );

size_isnumeric = size( check.isnumeric, 2 );
correct_isnumeric = ones( 1, size_isnumeric );

if isequal( check.isscalar, correct_isscalar ) ~= 1
%%	NG
	ns_Result = -1;		%	not scalar.

elseif isequal( check.isnumeric, correct_isnumeric ) ~= 1
%%	NG
	ns_Result = -2;		%	not numeric.

elseif ID ~= fix(ID) || ID < 0
%%	NG
	ns_Result = -3;		%	not convert to 0 or natural number.

else
%%	OK
	ns_Result = 0;		%	no problems.
end

%**************************************************************************
function ns_Result = CheckValueOfID( nsObj, ID, dwEntityType )
%	check value of ID
%	If the value meets the following conditions, it is correct.
%   1. nsObj.***{ID}.ns_ENTITYINFO.dwEntityType equals dwEntityType

%   source has to be surrounded by try-catch.
%   ( NullPointerException will occur if nsObj.***{ID} doesn't exist. ) 
try
	switch(dwEntityType)
		case nsObj.CONST.ns_ENTITY_EVENT
			if nsObj.Event{ID}.ns_ENTITYINFO.dwEntityType == dwEntityType
                %%	OK
                ns_Result = 0;  %   nsObj.Event{ID} exists.
				return;
			end
		case nsObj.CONST.ns_ENTITY_ANALOG
			if nsObj.Analog{ID}.ns_ENTITYINFO.dwEntityType == dwEntityType
                %%	OK
                ns_Result = 0;  %   nsObj.Analog{ID} exists.
				return;
			end
		case nsObj.CONST.ns_ENTITY_SEGMENT
			if nsObj.Segment{ID}.ns_ENTITYINFO.dwEntityType == dwEntityType
                %%	OK
                ns_Result = 0;  %   nsObj.Segment{ID} exists.
				return;
			end
		case nsObj.CONST.ns_ENTITY_NEURAL
			if nsObj.NeuralEvent{ID}.ns_ENTITYINFO.dwEntityType == dwEntityType
                %%	OK
				ns_Result = 0;  %   nsObj.NeuralEvent{ID} exists.
				return;
			end
        otherwise
            %%	NG
			ns_Result = -1;     %   Undefined entity type.
			return;
	end
	ns_Result = -2;             %   dwEntityType is not equal nsObj.***{ID}.ns_ENTITYINFO.dwEntityType.
catch
	ns_Result = -3;             %   NullPointerException
end
		
