function ns_Result = ns_SaveSegSourceInfo(nsObj, ID, SRCID)
% ns_SaveSegSourceInfo - Save ns_SEGSOURCEINFO to intermediate file. ( 1 File / 1 Entity )
% ns_Result = ns_SaveAnalogInfo(nsObj, ID)
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   ID        - [uint32] - identification number of this type of entity.
%   SRCID     - [uint32] - identification number of the source.
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/05/07 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

try
    %   Intermediate file name.
	filename = fullfile( nsObj.directory,...
		[sprintf('_01_%05d_%05d_SegmentSourceHeader_', ID, SRCID) nsObj.filename] );

	%ns_TAGELEMENT = nsObj.Segment{ID}.ns_TAGELEMENT;
	%ns_ENTITYINFO = nsObj.Segment{ID}.ns_ENTITYINFO;
	%ns_SEGMENTINFO  = nsObj.Segment{ID}.ns_SEGMENTINFO;
	ns_SEGSOURCEINFO = nsObj.Segment{ID}.ns_SEGSOURCEINFO(SRCID);

	fid = fopen(filename, 'w');

	%   ns_SEGSOURCEINFO
	fwrite(fid,ns_SEGSOURCEINFO.dMinVal, 'double');
	fwrite(fid,ns_SEGSOURCEINFO.dMaxVal, 'double');
	fwrite(fid,ns_SEGSOURCEINFO.dResolution, 'double');
	fwrite(fid,ns_SEGSOURCEINFO.dSubSampleShift, 'double');
	fwrite(fid,ns_SEGSOURCEINFO.dLocationX, 'double');
	fwrite(fid,ns_SEGSOURCEINFO.dLocationY, 'double');
	fwrite(fid,ns_SEGSOURCEINFO.dLocationZ, 'double');
	fwrite(fid,ns_SEGSOURCEINFO.dLocationUser, 'double');
	fwrite(fid,ns_SEGSOURCEINFO.dHighFreqCorner, 'double');
	fwrite(fid,ns_SEGSOURCEINFO.dwHighFreqOrder, 'uint32');
	u=[ns_SEGSOURCEINFO.szHighFilterType blanks(16)];
	fwrite(fid,u(1:16));
	fwrite(fid,ns_SEGSOURCEINFO.dLowFreqCorner, 'double');
	fwrite(fid,ns_SEGSOURCEINFO.dwLowFreqOrder, 'uint32');
	u=[ns_SEGSOURCEINFO.szLowFilterType blanks(16)];
	fwrite(fid,u(1:16));
	v=[ns_SEGSOURCEINFO.szProbeInfo blanks(128)];
	fwrite(fid,v(1:128));

	fclose(fid);
	ns_Result = nsObj.CONST.ns_OK;

catch

    % File handling error
	A{1} = nsObj.MESSAGE.FILEMANIPULATIONERROR;
	A{2} = 'Save SegSourceInfo To Intermediate File';
	A{3} = nsObj.MESSAGE.COLON;
	A{4} = nsObj.MESSAGE.STOPSEQUENCE;
	
    msg = strcat(A{:});
	
	disp(msg);
	
    %   as debug
    dbstack;
    
	% File creation error
	ns_Result = nsObj.CONST.ns_FILEERROR;
end