function ns_Result = ns_SaveAnalogInfo(nsObj, ID)
% ns_SaveAnalogInfo - Save ns_ANALOGINFO to intermediate file. ( 1 File / 1 Entity )
% ns_Result = ns_SaveAnalogInfo(nsObj, ID)
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   ID        - [uint32] - identification number.
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/05/07 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

try
    %   Intermediate file name.
    filename = fullfile( nsObj.directory,...
		[sprintf('_01_%05d_AnalogInfoHeader_', ID) nsObj.filename] );

	ns_TAGELEMENT = nsObj.Analog{ID}.ns_TAGELEMENT;
	ns_ENTITYINFO = nsObj.Analog{ID}.ns_ENTITYINFO;
	ns_ANALOGINFO  = nsObj.Analog{ID}.ns_ANALOGINFO;

	fid = fopen(filename, 'w');

	%   ns_TAGELEMENT
    fwrite(fid,ns_TAGELEMENT.dwElemType, 'uint32');
	fwrite(fid,ns_TAGELEMENT.dwElemLength, 'uint32');

	%   ns_ENTITYINFO
	s=[ns_ENTITYINFO.szEntityLabel blanks(32)];
	fwrite(fid,s(1:32));
	fwrite(fid,ns_ENTITYINFO.dwEntityType, 'uint32');
	fwrite(fid,ns_ENTITYINFO.dwItemCount, 'uint32');

	%   ns_ANALOGINFO
	fwrite(fid,ns_ANALOGINFO.dSampleRate, 'double');
	fwrite(fid,ns_ANALOGINFO.dMinVal, 'double');
	fwrite(fid,ns_ANALOGINFO.dMaxVal, 'double');
	t=[ns_ANALOGINFO.szUnits blanks(16)];
	fwrite(fid,t(1:16));
	fwrite(fid,ns_ANALOGINFO.dResolution, 'double');
	fwrite(fid,ns_ANALOGINFO.dLocationX, 'double');
	fwrite(fid,ns_ANALOGINFO.dLocationY, 'double');
	fwrite(fid,ns_ANALOGINFO.dLocationZ, 'double');
	fwrite(fid,ns_ANALOGINFO.dLocationUser, 'double');
	fwrite(fid,ns_ANALOGINFO.dHighFreqCorner, 'double');
	fwrite(fid,ns_ANALOGINFO.dwHighFreqOrder, 'uint32');
	u=[ns_ANALOGINFO.szHighFilterType blanks(16)];
	fwrite(fid,u(1:16));
	fwrite(fid,ns_ANALOGINFO.dLowFreqCorner, 'double');
	fwrite(fid,ns_ANALOGINFO.dwLowFreqOrder, 'uint32');
	u=[ns_ANALOGINFO.szLowFilterType blanks(16)];
	fwrite(fid,u(1:16));
	v=[ns_ANALOGINFO.szProbeInfo blanks(128)];
	fwrite(fid,v(1:128));
	
	fclose(fid);
	ns_Result = nsObj.CONST.ns_OK;

catch
    
    % File handling error
	A{1} = nsObj.MESSAGE.FILEMANIPULATIONERROR;
	A{2} = 'Save AnalogInfo To Intermediate File';
	A{3} = nsObj.MESSAGE.COLON;
	A{4} = nsObj.MESSAGE.STOPSEQUENCE;
    
	msg = strcat(A{:});
	
	disp(msg);
	
    %   as debug
    dbstack;
    
	% File creation error
	ns_Result = nsObj.CONST.ns_FILEERROR;
end