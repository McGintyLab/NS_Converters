function ns_Result = ns_CheckChInfo( nsObj, chInfo )
% ns_CheckChInfo - Check channel information.
% ns_Result = ns_CheckChInfo( nsObj, chInfo )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%	chInfo    - [struct] - channel information.
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By:  Satoshi Murata (1),  satoshi-m@atr.jp  11/11/18
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

ns_Result = nsObj.CONST.ns_OK;

if isempty(chInfo)
    if ~isempty(nsObj.chInfo)
        A{1} = nsObj.MESSAGE.ERROR;
        A{2} = nsObj.MESSAGE.WRONGCHINFO;
        A{3} = 'set_CHINFO';
        A{4} = nsObj.MESSAGE.COLON;
        A{5} = nsObj.MESSAGE.THISISNOTSTRUCTURE;
        A{6} = nsObj.MESSAGE.COLON;
        A{7} = nsObj.MESSAGE.STOPSEQUENCE;
        
        msg = strcat(A{:});
        
        disp(msg);

        dbstack;

        %	wrong HEADER
    	ns_Result = nsObj.CONST.ns_WRONGHEADER;
        return;
    end
else
    if ~isstruct(chInfo)
        A{1} = nsObj.MESSAGE.ERROR;
        A{2} = nsObj.MESSAGE.WRONGCHINFO;
        A{3} = 'set_CHINFO';
        A{4} = nsObj.MESSAGE.COLON;
        A{5} = nsObj.MESSAGE.THISISNOTSTRUCTURE;
        A{6} = nsObj.MESSAGE.COLON;
        A{7} = nsObj.MESSAGE.STOPSEQUENCE;
        
        msg = strcat(A{:});
        
        disp(msg);

        dbstack;

        %	wrong HEADER
    	ns_Result = nsObj.CONST.ns_WRONGHEADER;
        return;
        
    elseif ~isfield(chInfo,'chTypeCode') || ~isnumeric(chInfo.chTypeCode)
        A{1} = nsObj.MESSAGE.ERROR;
        A{2} = nsObj.MESSAGE.WRONGCHINFO;
        A{3} = 'chTypeCode';
        A{4} = nsObj.MESSAGE.MUSTBEDEFINEDMEMBER;
        A{5} = nsObj.MESSAGE.COLON;
        A{6} = nsObj.MESSAGE.STOPSEQUENCE;
        
        msg = strcat(A{:});
        
        disp(msg);

        dbstack;

        %	wrong HEADER
    	ns_Result = nsObj.CONST.ns_WRONGHEADER;
        return;
    
    elseif isfield(chInfo,'chType') && ~isempty(chInfo.chType) && ~ischar(chInfo.chType)
        A{1} = nsObj.MESSAGE.ERROR;
        A{2} = nsObj.MESSAGE.WRONGCHINFO;
        A{3} = 'chType';
        A{4} = nsObj.MESSAGE.MUSTBEsz;
        A{5} = nsObj.MESSAGE.COLON;
        A{6} = nsObj.MESSAGE.STOPSEQUENCE;
        
        msg = strcat(A{:});
        
        disp(msg);

        dbstack;

        %	wrong HEADER
    	ns_Result = nsObj.CONST.ns_WRONGHEADER;
        return;
    
    elseif isfield(chInfo,'comment') && ~isempty(chInfo.comment) && ~ischar(chInfo.comment)
        A{1} = nsObj.MESSAGE.ERROR;
        A{2} = nsObj.MESSAGE.WRONGCHINFO;
        A{3} = 'comment';
        A{4} = nsObj.MESSAGE.MUSTBEsz;
        A{5} = nsObj.MESSAGE.COLON;
        A{6} = nsObj.MESSAGE.STOPSEQUENCE;
        
        msg = strcat(A{:});
        
        disp(msg);

        dbstack;

        %	wrong HEADER
    	ns_Result = nsObj.CONST.ns_WRONGHEADER;
        return;
        
    elseif isempty(nsObj.chInfo) && ~isstruct(nsObj.chInfo)
        A{1} = nsObj.MESSAGE.ERROR;
        A{2} = nsObj.MESSAGE.WRONGCHINFO;
        A{3} = 'set_CHINFO';
        A{4} = nsObj.MESSAGE.COLON;
        A{5} = 'MUST SPECIFY CHINFO OF ALL CHANNELS';
        A{6} = nsObj.MESSAGE.COLON;
        A{7} = nsObj.MESSAGE.STOPSEQUENCE;
        
        msg = strcat(A{:});
        
        disp(msg);

        dbstack;

        %	wrong HEADER
    	ns_Result = nsObj.CONST.ns_WRONGHEADER;
        return;
    end
end
