function [ chInfo ] = ns_ChInfo( nsObj, chName, chType, chComment, neuroshareType )
%ns_ChInfo - Return chInfo struct.
% ns_ChInfo( chName, chType, chComment, neuroshareType )
%
% Inputs:
%   nsObj           - [struct] - object which has members of Neuroshare data format.
%   chName        - [char] - label of this channel.
%   chType          - [char] - channel type of this channel.
%   chComment  - [char] - comment of this channel.
%   neuroshareType  - [uint32] - neurosharetype of this channel.
%
% Outputs:
%   chInfo    - [struct] - chInfo struct.
%
% Created By: Keiji HARADA (1),  kharada@atr.jp  12/01/19
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/01/20
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% get type and typecode
if strcmpi(chType, nsObj.CHCONST.TypeECoG)
    colType = nsObj.CHCONST.TypeECoG;
    colCode = nsObj.CHCONST.CodeECoG;
elseif strcmpi(chType,nsObj.CHCONST.TypeEEG)
    colType = nsObj.CHCONST.TypeEEG;
    colCode = nsObj.CHCONST.CodeEEG;
elseif strcmpi(chType,nsObj.CHCONST.TypefMRI)
    colType = nsObj.CHCONST.TypefMRI;
    colCode = nsObj.CHCONST.CodefMRI;
elseif strcmpi(chType,nsObj.CHCONST.TypeMEG)
    colType = nsObj.CHCONST.TypeMEG;
    colCode = nsObj.CHCONST.CodeMEG;
elseif strcmpi(chType,nsObj.CHCONST.TypeMicroelectrode)
    colType = nsObj.CHCONST.TypeMicroelectrode;
    colCode = nsObj.CHCONST.CodeMicroelectrode;
elseif strcmpi(chType,nsObj.CHCONST.TypeNIRS)
    colType = nsObj.CHCONST.TypeNIRS;
    colCode = nsObj.CHCONST.CodeNIRS;
elseif strcmpi(chType,nsObj.CHCONST.TypeOpticalImaging)
    colType = nsObj.CHCONST.TypeOpticalImaging;
    colCode = nsObj.CHCONST.CodeOpticalImaging;
elseif strcmpi(chType,nsObj.CHCONST.TypePET)
    colType = nsObj.CHCONST.TypePET;
    colCode = nsObj.CHCONST.CodePET;
elseif strcmpi(chType,nsObj.CHCONST.TypeBrainOthers)
    colType = nsObj.CHCONST.TypeBrainOthers;
    colCode = nsObj.CHCONST.CodeBrainOthers;
elseif strcmpi(chType,nsObj.CHCONST.TypeMovement)
    colType = nsObj.CHCONST.TypeMovement;
    colCode = nsObj.CHCONST.CodeMovement;
elseif strcmpi(chType,nsObj.CHCONST.TypeStimulus)
    colType = nsObj.CHCONST.TypeStimulus;
    colCode = nsObj.CHCONST.CodeStimulus;
elseif strcmpi(chType,nsObj.CHCONST.TypeTask)
    colType = nsObj.CHCONST.TypeTask;
    colCode = nsObj.CHCONST.CodeTask;
elseif strcmpi(chType,nsObj.CHCONST.TypeBehaviorOthers)
    colType = nsObj.CHCONST.TypeBehaviorOthers;
    colCode = nsObj.CHCONST.CodeBehaviorOthers;
elseif strcmpi(chType,nsObj.CHCONST.TypeComment)
    colType = nsObj.CHCONST.TypeComment;
    colCode = nsObj.CHCONST.CodeComment;
elseif strcmpi(chType,nsObj.CHCONST.TypeUndefined)
    colType = nsObj.CHCONST.TypeUndefined;
    colCode = nsObj.CHCONST.CodeUndefined;
elseif strcmpi(chType,'')
    colType = nsObj.CHCONST.TypeUndefined;
    colCode = nsObj.CHCONST.CodeUndefined;
else
    % Other case, then Type is chType, Code is BrainOther.
    colType = chType;
    colCode = nsObj.CHCONST.CodeBrainOthers;
end

% set values.
chInfo.chName = chName;
chInfo.chType = colType;
chInfo.chTypeCode = colCode;
chInfo.comment = chComment;
chInfo.neuroshareType = neuroshareType;

end

