function ns_Result = ns_SaveChInfo(nsObj)
% ns_SaveChInfo - Save chInfo to XML file. ( 1 XML File / 1 NSN File )
% ns_Result = ns_SaveChInfo(nsObj)
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By:  Satoshi Murata (1),  satoshi-m@atr.jp  11/11/18
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

if isempty(nsObj.chInfo)
    ns_Result = nsObj.CONST.ns_OK;
    return;
end
    
try
    etype = [1 4 2 3];      % Event, Neural, Analog, Segment
    
    xml = '<?xml version="1.0" ?>';
    xml = [xml '<chInfo>'];

    num_ch = 1;
    
    for ite=1:4
        ind = find([nsObj.chInfo.neuroshareType] == etype(ite));
        
        for iti=1:length(ind)
            xml = [xml '<ch num="' num2str(num_ch) '">'];
            xml = [xml '<neuroshareType>' num2str(nsObj.chInfo(ind(iti)).neuroshareType) '</neuroshareType>'];
            xml = [xml '<chName>' nsObj.chInfo(ind(iti)).chName '</chName>'];
            xml = [xml '<chTypeCode>' num2str(nsObj.chInfo(ind(iti)).chTypeCode) '</chTypeCode>'];
            if isfield(nsObj.chInfo(ind(iti)),'chType') && ~isempty(nsObj.chInfo(ind(iti)).chType)
                xml = [xml '<chType>' nsObj.chInfo(ind(iti)).chType '</chType>'];
            end
            if isfield(nsObj.chInfo(ind(iti)),'comment') && ~isempty(nsObj.chInfo(ind(iti)).comment)
                xml = [xml '<comment>' nsObj.chInfo(ind(iti)).comment '</comment>'];
            end
            xml = [xml '</ch>'];
            
            num_ch = num_ch + 1;
        end
    end
    
    xml = [xml '</chInfo>'];
    
    % write XML file
    filename = fullfile( nsObj.directory,'chInfo.xml' );
    fid = fopen(filename,'w');
    fprintf(fid, '%s', xml);
    fclose(fid);

	ns_Result = nsObj.CONST.ns_OK;

catch
    % File handling error
	A{1} = nsObj.MESSAGE.FILEMANIPULATIONERROR;
	A{2} = 'Save ChInfo To XML File';
	A{3} = nsObj.MESSAGE.COLON;
	A{4} = nsObj.MESSAGE.STOPSEQUENCE;
    
	msg = strcat(A{:});
	
	disp(msg);
	
    %   as debug
    dbstack;
    
	% File creation error
	ns_Result = nsObj.CONST.ns_FILEERROR;
end
