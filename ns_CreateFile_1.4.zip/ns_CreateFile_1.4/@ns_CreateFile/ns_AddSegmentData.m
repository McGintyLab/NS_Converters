function [ ns_Result nsObj ] = ns_AddSegmentData( nsObj, SEGID, dTimestamp, dwUnitID, dValue )
%ns_AddSegmentData - Update nsObj, Add ns_SEGSOURCEINFO, Add dTime and dData to the intermediate file which is identified by ID.
%[ ns_Result nsObj SEGSOURCEID ] = ns_AddSegmentData( nsObj, SEGID, dTimestamp, dwUnitID, dValue )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   SEGID     - [uint32] - identification number of this type of entity.
%   dTimestamp- [double] - value of timestamp.
%   dwUnitID  - [uint32] - value of classification ID(scalar : 1*1) 
%   dValue    - [double] - value of segment(vector : 1*n) 
% 
% Outputs:
%   ns_Result - [double] - result value of this function.
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   SEGSOURCEID-[uint32] - identification number of the segment source.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/06/04
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/03/02 
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/03/16
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/03/22
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  11/03/02
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% Check value of ID 
% If A or B condition consists, ns_Result is ns_WRONGID.
% A. Wrong type of ID (Can't change ID value to uint32(scalar(1*1)) value.)
% B. Unregistered ID (As Segment Entity.)
ns_Result = ns_CheckID( nsObj, SEGID, nsObj.CONST.ns_ENTITY_SEGMENT );
if nsObj.CONST.ns_OK ~= ns_Result
    return;
end

% Convert int to double, if needed      % SM
if isinteger(dTimestamp)
    dTimestamp = double(dTimestamp);
end
if isinteger(dValue)
    dValue = double(dValue);
end

% Check value of dTimestamp, dwUnitID and dValue
% If A or B or C condition consists, ns_Result is ns_WRONGDATA.
% A. Wrong type of dTimestamp (Can't change dTimestamp value to double(scalar(1*1)) value.)
% B. Wrong type of dwUnitID (Can't change dwUnitID value to uint32(scalar(1*1)) value.)
% C. Wrong type of dValue (Can't change dValue value to double(scalar(1*n)) value.)
ns_Result = ns_CheckSegmentData( nsObj, dTimestamp, dwUnitID, dValue );
if nsObj.CONST.ns_OK ~= ns_Result
    return;
end

% Correct values to rewrite object.
dwSampleCount = cast( size(dValue,2) , 'uint32' );
maxVal = max(dValue.');
minVal = min(dValue.');

% Add data to the intermediate file.
fid = fopen(nsObj.Segment{SEGID}.FNAME,'a');       % SM
%fwrite(nsObj.Segment{SEGID}.FID, dwSampleCount, 'uint32');
%fwrite(nsObj.Segment{SEGID}.FID, dTimestamp, 'double');
%fwrite(nsObj.Segment{SEGID}.FID, dwUnitID, 'uint32');
%fwrite(nsObj.Segment{SEGID}.FID, dValue, 'double');
fwrite(fid,dwSampleCount,'uint32');
fwrite(fid,dTimestamp,'double');
fwrite(fid,dwUnitID,'uint32');
fwrite(fid,dValue,'double');
fclose(fid);

% Update nsObj.
% *************  ns_TAGELEMENT  *************
% ns_TAGELEMENT : dwElemLength (total bytes of this analog entity)
nsObj.Segment{SEGID}.ns_TAGELEMENT.dwElemLength = ...
    nsObj.Segment{SEGID}.ns_TAGELEMENT.dwElemLength + 4 + 8 + 4 + 8 * dwSampleCount;

% *************  ns_ENTITYINFO  *************
% ns_ENTITYINFO : dwItemCount (total number of this analog values)
nsObj.Segment{SEGID}.ns_ENTITYINFO.dwItemCount = ...
    nsObj.Segment{SEGID}.ns_ENTITYINFO.dwItemCount + 1;

% *************  ns_SEGMENTINFO  *************
% ns_SEGMENTINFO : dwMaxSampleCount / dwMinSampleCount (max or min sample count)
if nsObj.Segment{SEGID}.ns_SEGMENTINFO.dwMaxSampleCount < dwSampleCount
    nsObj.Segment{SEGID}.ns_SEGMENTINFO.dwMaxSampleCount = dwSampleCount;
end
if nsObj.Segment{SEGID}.ns_SEGMENTINFO.dwMinSampleCount > dwSampleCount
    nsObj.Segment{SEGID}.ns_SEGMENTINFO.dwMinSampleCount = dwSampleCount;
end

% *************  ns_SEGSOURCEINFO  *************
% ns_SEGSOURCEINFO : dMaxVal / dMinVal (max or min value)
if nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(1).dMinVal > minVal
    nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(1).dMinVal = minVal;
end
if nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(1).dMaxVal < maxVal
    nsObj.Segment{SEGID}.ns_SEGSOURCEINFO(1).dMaxVal = maxVal;
end
