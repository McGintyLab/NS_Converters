function [ ns_Result nsa_NEURALINFO ] = ns_GetNeuralInfo( nsObj, ID )
% ns_GetNeuralInfo - Get ns_NEURALINFO which is identified by ID.
% [ ns_Result nsa_NEURALINFO ] = ns_GetNeuralInfo( nsObj, ID )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   ID        - [uint32] - identification number of this type of entity.
% 
% Outputs:
%   ns_Result - [double] - result value of this function.
%   nsa_NEURALINFO - [struct] - struct of this entity.
%
% Created By: Keiji HARADA (1),  kharada@atr.jp  09/04/30
% Modified By: Keiji HARADA (1),  kharada@atr.jp  10/03/02 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% Check value of ID 
% If A or B condition consists, ns_Result is ns_WRONGID.
% A. Wrong type of ID (Can't change ID value to uint32(scalar(1*1)) value.)
% B. Unregistered ID (As NeuralEvent Entity.)
ns_Result = ns_CheckID( nsObj, ID, nsObj.CONST.ns_ENTITY_NEURAL );
if nsObj.CONST.ns_OK ~= ns_Result 
    nsa_NEURALINFO = '';
    return;
end

% Set return struct.
nsa_NEURALINFO = nsObj.NeuralEvent{ID}.ns_NEURALINFO;

% Remove these members from return struct.
% It is not able to change these members value with using Get/Set method. Only New/Add method can do it.

% -- Nothing --



% Return struct has these members.

% dwSourceEntityID [scalar(1*1),uint32]
% dwSourceUnitID   [scalar(1*1),uint32]
% szProbeInfo      [char]
