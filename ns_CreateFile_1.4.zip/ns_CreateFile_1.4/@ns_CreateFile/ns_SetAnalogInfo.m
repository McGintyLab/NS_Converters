function [ ns_Result nsObj ] = ns_SetAnalogInfo( nsObj, ID, nsa_ANALOGINFO )
% ns_SetAnalogInfo - Update ns_ANALOGINFO which is identified by ID.
% [ ns_Result nsObj ] = ns_SetAnalogInfo( nsObj, ID, nsa_ANALOGINFO )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   ID        - [uint32] - identification number of this type of entity.
%   nsa_ANALOGINFO - [struct] - struct of this entity.
% 
% Outputs:
%   ns_Result - [double] - result value of this function.
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%
% Created By: Keiji HARADA (1),  kharada@atr.jp  09/04/30
% Modified By: Keiji HARADA (1),  kharada@atr.jp  10/03/02 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% Check value of ID 
% If A or B condition consists, ns_Result is ns_WRONGID.
% A. Wrong type of ID (Can't change ID value to uint32(scalar(1*1)) value.)
% B. Unregistered ID (As Analog Entity.)
ns_Result = ns_CheckID( nsObj, ID, nsObj.CONST.ns_ENTITY_ANALOG );
if nsObj.CONST.ns_OK ~= ns_Result
    return;
end

% Check value of struct
% If A or B or C condition consists, ns_Result is ns_WRONGHEADER
% A. One or more undefined member exists.            [exam. : nsa_ANALOGINFO.abc]
% B. One or more unchangeable member exists.         [-- Nothing in ns_ANALOGINFO --]
% C. One or more changeable member does not exists.  [exam. : nsa_ANALOGINFO.dSampleRate] (case : If application remove it.)
ns_Result = ns_CheckInfo( nsObj, nsa_ANALOGINFO, 'nsa_ANALOGINFO' );
if nsObj.CONST.ns_OK ~= ns_Result
    return;
end

% Update struct
% If A or B condition consists, Warning message will be displayed. 
%    (ns_Result is ns_OK, nsObj.Analog{ID}.ns_ANALOGINFO is updated EXCEPT members below)
% A. Wrong type of member    [exam. : nsa_ANALOGINFO.dSampleRate = 'text words' (Type of dSampleRate must be double(scalar(1*1)) )]
% B. Wrong value of member   [-- Nothing in ns_ANALOGINFO --]
nsObj = ns_UpdateAnalogInfo( nsObj, ID, nsa_ANALOGINFO );


% NOT update value of these members.
% It is not able to change these members value with using Get/Set method. Only New/Add method can do it.

% -- Nothing --



% Update value of these members.

% dSampleRate        [scalar(1*1),double]
% dMinVal            [scalar(1*1),double]
% dMaxVal            [scalar(1*1),double]
% szUnits            [char]
% dResolution        [scalar(1*1),double]
% dLocationX         [scalar(1*1),double]
% dLocationY         [scalar(1*1),double]
% dLocationZ         [scalar(1*1),double]
% dLocationUser      [scalar(1*1),double]
% dHighFreqCorner    [scalar(1*1),double]
% dwHighFreqOrder    [scalar(1*1),uint32]
% szHighFilterType   [char]
% dLowFreqCorner     [scalar(1*1),double]
% dwLowFreqOrder     [scalar(1*1),uint32]
% szLowFilterType    [char]
% szProbeInfo        [char]
