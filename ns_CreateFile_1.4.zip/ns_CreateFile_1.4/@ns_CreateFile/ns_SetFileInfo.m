function [ ns_Result nsObj ] = ns_SetFileInfo( nsObj, nsa_FILEINFO )
% ns_SetFileInfo - Update ns_FILEINFO.
% [ ns_Result nsObj ] = ns_SetFileInfo( nsObj, nsa_FILEINFO )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   nsa_FILEINFO - [struct] - struct of this entity.
% 
% Outputs:
%   ns_Result - [double] - result value of this function.
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%
% Created By: Keiji HARADA (1),  kharada@atr.jp  09/04/30
% Modified By: Keiji HARADA (1),  kharada@atr.jp  10/03/02 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% Check value of struct
% If A or B or C condition consists, ns_Result is ns_WRONGHEADER
% A. One or more undefined member exists.            [exam. : nsa_EVENTINFO.abc]
% B. One or more unchangeable member exists.         [dwEventType, dwMinDataLength, dwMaxDataLength]
% C. One or more changeable member does not exists.  [nsa_EVENTINFO.szCSVDesc] (case : If application remove it.)
ns_Result = ns_CheckInfo( nsObj, nsa_FILEINFO, 'nsa_FILEINFO' );
if nsObj.CONST.ns_OK ~= ns_Result
 return;
end

% Update struct
% If A or B condition consists, Warning message will be displayed. 
%    (ns_Result is ns_OK, nsObj.ns_FILEINFO is updated EXCEPT members below)
% A. Wrong type of member    [exam. : nsa_FILEINFO.szFileType = 123 (Type of szFileType must be char(Vector(1*n)) )]
% B. Wrong value of member   [dwTime_Month, dwTime_DayOfWeek, dwTime_Day, dwTime_Hour, dwTime_Min, dwTime_Sec, dwTime_MilliSec]
nsObj = ns_UpdateFileInfo( nsObj, nsa_FILEINFO );


% NOT update value of these members.
% It is not able to change these members value with using Get/Set method. Only New/Add method can do it.

% dwEntityCount         [scalar(1*1),uint32]



% Update value of these members.

% szFileType            [char]
% dTimeStampResolution  [scalar(1*1),double]
% dTimeSpan             [scalar(1*1),double]
% szAppName             [char]
% dwTime_Year           [scalar(1*1),uint32]
% dwTime_Month          [scalar(1*1),uint32]
% dwTime_DayOfWeek      [scalar(1*1),uint32]
% dwTime_Day            [scalar(1*1),uint32]
% dwTime_Hour           [scalar(1*1),uint32]
% dwTime_Min            [scalar(1*1),uint32]
% dwTime_Sec            [scalar(1*1),uint32]
% dwTime_MilliSec       [scalar(1*1),uint32]
% szFileComment         [char]
