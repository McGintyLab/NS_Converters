function [ ns_Result nsObj ] = ns_SetNeuralInfo(nsObj, ID, nsa_NEURALINFO)
% ns_SetNeuralInfo - Update ns_NEURALINFO which is identified by ID.
% [ ns_Result nsObj ] = ns_SetNeuralInfo( nsObj, ID, nsa_NEURALINFO )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   ID        - [uint32] - identification number of this type of entity.
%   nsa_NEURALINFO - [struct] - struct of this entity.
% 
% Outputs:
%   ns_Result - [double] - result value of this function.
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%
% Created By: Keiji HARADA (1),  kharada@atr.jp  09/04/30
% Modified By: Keiji HARADA (1),  kharada@atr.jp  10/03/02 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% Check value of ID 
% If A or B condition consists, ns_Result is ns_WRONGID.
% A. Wrong type of ID (Can't change ID value to uint32(scalar(1*1)) value.)
% B. Unregistered ID (As Neural Event Entity.)
ns_Result = ns_CheckID( nsObj, ID, nsObj.CONST.ns_ENTITY_NEURAL );
if nsObj.CONST.ns_OK ~= ns_Result
    return;
end

% Check value of struct
% If A or B or C condition consists, ns_Result is ns_WRONGHEADER
% A. One or more undefined member exists.            [exam. : nsa_NEURALINFO.abc]
% B. One or more unchangeable member exists.         [-- Nothing in ns_NEURALINFO --]
% C. One or more changeable member does not exists.  [nsa_NEURALINFO.szProbeInfo] (case : If application remove it.)
ns_Result = ns_CheckInfo( nsObj, nsa_NEURALINFO, 'nsa_NEURALINFO' );
if nsObj.CONST.ns_OK ~= ns_Result
    return;
end

% Update struct
% If A or B condition consists, Warning message will be displayed. 
%    (ns_Result is ns_OK, nsObj.NeuralEvent{ID}.ns_NEURALINFO is updated EXCEPT members below)
% A. Wrong type of member    [exam. : nsa_NEURALINFO.dwSourceEntityID = 'text words' (Type of dSampleRate must be uint32(scalar(1*1)) )]
% B. Wrong value of member   [-- Nothing in ns_NEURALINFO --]
nsObj = ns_UpdateNeuralInfo( nsObj, ID, nsa_NEURALINFO );


% NOT update value of these members.
% It is not able to change these members value with using Get/Set method. Only New/Add method can do it.

% -- Nothing --



% Update value of these members.

% dwSourceEntityID [scalar(1*1),uint32]
% dwSourceUnitID   [scalar(1*1),uint32]
% szProbeInfo      [char]
