function a = subsasgn( a, index , val)
% subsasgn - Display error message if application/user wants to change nsObj with using [.] operator.(**1)
% a =  subsasgn( a, index, val )
% 
% (**1) For protect members of nsObj. application/user can change value of nsObj with using Get/Set method.
%
% Created By: Keiji HARADA (1),  kharada@atr.jp  09/04/30
% Modified By: Keiji HARADA (1),  kharada@atr.jp  10/03/02 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

msgID = 'ERROR : Can not edit a member of [ nsObj ] without using method ';

disp(msgID);
dbstack;
