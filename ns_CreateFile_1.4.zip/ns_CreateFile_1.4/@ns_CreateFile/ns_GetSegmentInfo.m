function [ ns_Result nsa_SEGMENTINFO ] = ns_GetSegmentInfo( nsObj, ID )
% ns_GetSegmentInfo - Get ns_SEGMENTINFO which is identified by ID.
% [ ns_Result nsa_SEGMENTINFO ] = ns_GetSegmentInfo( nsObj, ID )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   ID        - [uint32] - identification number of this type of entity.
% 
% Outputs:
%   ns_Result - [double] - result value of this function.
%   nsa_SEGMENTINFO - [struct] - struct of this entity.
%
% Created By: Keiji HARADA (1),  kharada@atr.jp  09/04/30
% Modified By: Keiji HARADA (1),  kharada@atr.jp  10/03/02 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% Check value of ID 
% If A or B condition consists, ns_Result is ns_WRONGID.
% A. Wrong type of ID (Can't change ID value to uint32(scalar(1*1)) value.)
% B. Unregistered ID (As Segment Entity.)
ns_Result = ns_CheckID( nsObj, ID, nsObj.CONST.ns_ENTITY_SEGMENT );
if nsObj.CONST.ns_OK ~= ns_Result
    nsa_SEGMENTINFO = '';
    return;
end

% Set return struct.
nsa_SEGMENTINFO = nsObj.Segment{ID}.ns_SEGMENTINFO;

% Remove these members from return struct.
% It is not able to change these members value with using Get/Set method. Only New/Add method can do it.
nsa_SEGMENTINFO = rmfield( nsa_SEGMENTINFO, 'dwSourceCount');
nsa_SEGMENTINFO = rmfield( nsa_SEGMENTINFO, 'dwMinSampleCount');
nsa_SEGMENTINFO = rmfield( nsa_SEGMENTINFO, 'dwMaxSampleCount');

% Return struct has these members.

% dSampleRate      [scalar(1*1),double]
% szUnits          [char]

% Return struct DOESNOT have these members.

% dwSourceCount    [scalar(1*1),uint32]
% dwMinSampleCount [scalar(1*1),uint32]
% dwMaxSampleCount [scalar(1*1),uint32]
