function [ ns_Result nsObj ID ] = ns_NewAnalogData( nsObj, szEntityLabel, chType, chComment )
% ns_NewAnalogData - Update nsObj, Create intermediate file for Analog Entity.
% [ ns_Result nsObj ID ] = ns_NewAnalogData( nsObj, szEntityLabel, chType, chComment )
%
% Inputs:
%   nsObj           - [struct] - object which has members of Neuroshare data format.
%   szEntityLabel   - [char]<OPTIONAL> - label of this entity.
%   chType          - [char]<OPTIONAL> - channel type of this entity.
%   chComment  - [char]<OPTIONAL> - comment of this entity.
%
% Outputs:
%   ns_Result       - [double] - result value of this function.
%   nsObj           - [struct] - object which has members of Neuroshare data format.
%   ID              - [uint32] - identification number of the entity.
%
% Created  By: Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/03/02 
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/03/22
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  11/11/18
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/01/19
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% Check number of Inputs
if nargin == 1
    % szEntityLabel and chInfo are omitted.
    szEntityLabel = '';
    chInfo        = '';
elseif nargin ==2
    chInfo        = '';
elseif nargin == 3;
    chComment = '';
    chInfo        = ns_ChInfo(nsObj, szEntityLabel, chType, chComment, nsObj.CONST.ns_ENTITY_ANALOG);
elseif nargin == 4;
    chInfo        = ns_ChInfo(nsObj, szEntityLabel, chType, chComment, nsObj.CONST.ns_ENTITY_ANALOG);
end

% Check value of szEntityLabel
% If A condition consists, ns_Result is ns_WRONGLABEL.
% A. Wrong type of szEntityLabel (Can't change szEntityLabel value to char(scalar(1*n)) value.)
ns_Result = ns_CheckLabel(nsObj, szEntityLabel);
if nsObj.CONST.ns_OK ~= ns_Result
    ID = '';
    return;
end

% Check value of chInfo
ns_Result = ns_CheckChInfo(nsObj, chInfo);
if ns_Result ~= nsObj.CONST.ns_OK
    ID = '';
    return;
end

% Copy chInfo
if isempty(chInfo)
    nsObj.chInfo = '';
else
    fname = fieldnames(chInfo);
    ind   = length(nsObj.chInfo) + 1;
    for iti=1:length(fname)
        nsObj.chInfo(ind).(fname{iti}) = chInfo.(fname{iti});
    end
end

% Create new ID.
ID = cast( size(nsObj.Analog, 2) + 1 , 'uint32' );

% Initialize values.
nsObj.Analog{ID} = nsObj.AnalogHeader;

% Create intermediate file.
fname = [sprintf('_01_%05d_AnalogData_', ID) nsObj.filename];
filename = fullfile(nsObj.directory, fname);
%nsObj.Analog{ID}.FID = fopen(filename, 'w');
nsObj.Analog{ID}.FNAME = filename;     % SM

% Update nsObj.
% *************  ns_FILEINFO  ***************
% ns_FILEINFO : dwEntityCount (total number of entities)
nsObj.ns_FILEINFO.dwEntityCount = nsObj.ns_FILEINFO.dwEntityCount + 1;

% *************  ns_TAGELEMENT  *************
% ns_TAGELEMENT : dwElemType (kind of entity)
% ns_TAGELEMENT : dwElemLength (total bytes of this entity)
nsObj.Analog{ID}.ns_TAGELEMENT.dwElemType     = nsObj.CONST.ns_ENTITY_ANALOG;
nsObj.Analog{ID}.ns_TAGELEMENT.dwElemLength   = 40 + 264;

% *************  ns_ENTITYINFO  *************
% ns_ENTITYINFO : szEntityLabel (label of this entity)
% ns_ENTITYINFO : dwEntityType (kind of entity)
nsObj.Analog{ID}.ns_ENTITYINFO.szEntityLabel  = szEntityLabel;
nsObj.Analog{ID}.ns_ENTITYINFO.dwEntityType   = nsObj.CONST.ns_ENTITY_ANALOG;

% *************  ns_ANALOGINFO  *************
% ns_ANALOGINFO : dMaxVal/dMinVal (max/min value)
nsObj.Analog{ID}.ns_ANALOGINFO.dMinVal = 2^63-1;  % max value as double.
nsObj.Analog{ID}.ns_ANALOGINFO.dMaxVal = -2^63;   % min value as double.
