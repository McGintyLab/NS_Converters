function [ ns_Result nsObj ] = ns_CreateFile( filename )
% ns_CreateFile - Create nsObj, Define constant value and messages.
%[ ns_Result nsObj ] = ns_CreateFile( filename )
%
% Inputs:
%   filename  - [char]   - Neuroshare file name.(**1)
% 
% Outputs:
%   ns_Result - [double] - result value of this function.
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%
% (**1) Extension of the file must be '.nsn' or ''(nothing).
%       Relative or absolute path should be set.
%       See sample below.
%       correct   : 'sample.nsn', 'sample'
%       correct   : 'OutputFile\sample.nsn'(Windows),'data/sample.nsn'(Linux)[Relative path from current directory]
%       correct   : 'C:\MATLAB\OutputFile\sample.nsn'(Windows),'/temp/data/sample.nsn'(Linux)[Absolute path]
%       incorrect : 'sample.abc'
%
% Created By: Keiji HARADA (1),  kharada@atr.jp  09/04/30
% Modified By: Keiji HARADA (1),  kharada@atr.jp  10/03/02 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% Define constant values
nsObj.CONST.ns_OK          =  0;
nsObj.CONST.ns_LIBERROR    = -1;
nsObj.CONST.ns_TYPEERROR   = -2;
nsObj.CONST.ns_FILEERROR   = -3;
nsObj.CONST.ns_BADFILE     = -4;
nsObj.CONST.ns_BADENTITY   = -5;
nsObj.CONST.ns_BADSOURCE   = -6;
nsObj.CONST.ns_BADINDEX    = -7;
nsObj.CONST.ns_WRONGLABEL  = -101;  % ADD K.Harada 09/04/06
nsObj.CONST.ns_WRONGID     = -102;  % ADD K.Harada 09/04/06
nsObj.CONST.ns_WRONGHEADER = -103;  % ADD K.Harada 09/04/06
nsObj.CONST.ns_WRONGDATA   = -104;  % ADD K.Harada 09/04/06
nsObj.CONST.ns_ENTITY_UNKNOWN   = uint32(0);
nsObj.CONST.ns_ENTITY_EVENT     = uint32(1);
nsObj.CONST.ns_ENTITY_ANALOG    = uint32(2);
nsObj.CONST.ns_ENTITY_SEGMENT   = uint32(3);
nsObj.CONST.ns_ENTITY_NEURAL    = uint32(4);
nsObj.CONST.ns_ENTITY_INFO_FILE = uint32(5);
nsObj.CONST.ns_EVENT_TEXT   = uint32(0);
nsObj.CONST.ns_EVENT_CSV    = uint32(1);
nsObj.CONST.ns_EVENT_BYTE   = uint32(2);
nsObj.CONST.ns_EVENT_WORD   = uint32(3);
nsObj.CONST.ns_EVENT_DWORD  = uint32(4);

% Define constant values
nsObj.CHCONST.CodeECoG                   =  110;
nsObj.CHCONST.CodeEEG                      =  120;
nsObj.CHCONST.CodefMRI                    =  130;
nsObj.CHCONST.CodeMEG                    =  140;
nsObj.CHCONST.CodeMicroelectrode   =  150;
nsObj.CHCONST.CodeNIRS                    =  160;
nsObj.CHCONST.CodeOpticalImaging  =  170;
nsObj.CHCONST.CodePET                     =  180;
nsObj.CHCONST.CodeBrainOthers       =  300;
nsObj.CHCONST.CodeMovement         =  410;
nsObj.CHCONST.CodeStimulus            =  510;
nsObj.CHCONST.CodeTask                  =  610;
nsObj.CHCONST.CodeBehaviorOthers =  700;
nsObj.CHCONST.CodeComment          =  900;
nsObj.CHCONST.CodeUndefined         =  000;
nsObj.CHCONST.TypeECoG                   =  'ECoG';
nsObj.CHCONST.TypeEEG                      =  'EEG';
nsObj.CHCONST.TypefMRI                    =  'fMRI';
nsObj.CHCONST.TypeMEG                    =  'MEG';
nsObj.CHCONST.TypeMicroelectrode   =  'Microelectrode';
nsObj.CHCONST.TypeNIRS                    =  'NIRS';
nsObj.CHCONST.TypeOpticalImaging  =  'Optical Imaging';
nsObj.CHCONST.TypePET                     =  'PET';
nsObj.CHCONST.TypeBrainOthers       =  'BrainOthers';
nsObj.CHCONST.TypeMovement         =  'Movement';
nsObj.CHCONST.TypeStimulus            =  'Stimulus';
nsObj.CHCONST.TypeTask                  =  'Task';
nsObj.CHCONST.TypeBehaviorOthers =  'BehaviorOthers';
nsObj.CHCONST.TypeComment          =  'Comment';
nsObj.CHCONST.TypeUndefined         =  'Undefined';

% Define messages
nsObj.MESSAGE.AND     = ' & ';
nsObj.MESSAGE.COLON     = ' : ';
nsObj.MESSAGE.ERROR     = 'ERROR : ';
nsObj.MESSAGE.WRONGIDTYPE   = 'WRONG ID_TYPE : ';
nsObj.MESSAGE.WRONGIDVALUE   = 'WRONG ID_VALUE : ';
nsObj.MESSAGE.WRONGINFOTYPE   = 'WRONG INFO_TYPE : ';
nsObj.MESSAGE.WRONGINFOVALUE  = 'WRONG INFO_VALUE : ';
nsObj.MESSAGE.WRONGINFOMEMBER  = 'WRONG INFO_MEMBER : ';
nsObj.MESSAGE.WRONGINFO    = 'WRONG INFO : ';
nsObj.MESSAGE.WRONGCHINFO  = 'WRONG CHINFO : ';
nsObj.MESSAGE.WRONGDATATYPE   = 'WRONG DATA_TYPE : ';
nsObj.MESSAGE.WRONGDATAVALUE  = 'WRONG DATA_VALUE : ';
nsObj.MESSAGE.NOTPOSSIBLETOSETVALUE = 'NOT POSSIBLE TO SET VALUE : ';
nsObj.MESSAGE.FILEMANIPULATIONERROR = 'FILE MANIPULATION ERROR : ';
nsObj.MESSAGE.ns_FILEINFO   = 'ns_FILEINFO.'; 
nsObj.MESSAGE.ns_EVENTINFO   = 'ns_EVENTINFO.'; 
nsObj.MESSAGE.ns_ANALOGINFO   = 'ns_ANALOGINFO.'; 
nsObj.MESSAGE.ns_SEGMENTINFO  = 'ns_SEGMENTINFO.'; 
nsObj.MESSAGE.ns_SEGSOURCEINFO  = 'ns_SEGSOURCEINFO'; 
nsObj.MESSAGE.ns_NEURALINFO   = 'ns_NEURALINFO.'; 
nsObj.MESSAGE.STOPSEQUENCE   = 'Stop Sequence';
nsObj.MESSAGE.SETBYFUNCTION   = '(SET BY FUNCTION)';
nsObj.MESSAGE.MUSTBEDEFINEDMEMBER = '(MUST BE DEFINED MEMBER)';
nsObj.MESSAGE.MUSTBEREVOKABLEMEMBER = '(MUST BE REVOKABLE MEMBER)';
nsObj.MESSAGE.THEMEMBERDOESNOTEXIST = '(The Member doesn''t exist)';
nsObj.MESSAGE.MUSTBEns_FILEINFO  = '(MUST BE ns_FILEINFO)';
nsObj.MESSAGE.MUSTBEns_EVENTINFO = '(MUST BE ns_EVENTINFO)';
nsObj.MESSAGE.MUSTBEns_ANALOGINFO = '(MUST BE ns_ANALOGINFO)';
nsObj.MESSAGE.MUSTBEns_SEGMENTINFO = '(MUST BE ns_SEGMENTINFO)';
nsObj.MESSAGE.MUSTBEns_SEGSOURCEINFO= '(MUST BE ns_SEGSOURCEINFO)';
nsObj.MESSAGE.MUSTBEns_NEURALINFO = '(MUST BE ns_NEURALINFO)';
nsObj.MESSAGE.MUSTBEd    = '(MUST BE double[scalar(1*1)])';
nsObj.MESSAGE.MUSTBEdw   = '(MUST BE 0 or Positive Integer[scalar(1*1)] )';
nsObj.MESSAGE.MUSTBEsz   = '(MUST BE char)';
nsObj.MESSAGE.ALLMEMBERSOFTHISSTRUCTWERENOTUPDATED = 'ALL members of this struct were not updated';
nsObj.MESSAGE.THISISNOTUPDATED  = 'This is not updated';
nsObj.MESSAGE.THISISNOTSTRUCTURE = 'This is not structure';
nsObj.MESSAGE.THISISNOTCORRECTSTRUCTURE = 'This is not correct structure';
nsObj.MESSAGE.DEFVAL     = 'Use default value';
nsObj.MESSAGE.dDEFVAL    = 'Use default value [ 0.0 ]';
nsObj.MESSAGE.dwDEFVAL   = 'Use default value [ 0 ]';
nsObj.MESSAGE.szDEFSTR   = 'Use default value [ ]';

% -------------------------------------------------------------------------
% Check value of filename 

% If A or B condition consists, ns_Result is ns_WRONGLABEL.
% A. Wrong type of filename (type is not char.)
% B. Wrong extension of filename

% Check type of filename
if 1 ~= isa(filename,'char')
    
    A{1} = nsObj.MESSAGE.ERROR;
    A{2} = 'WRONG NAME OF OUTPUT_FILE';
    A{3} = nsObj.MESSAGE.MUSTBEsz;
    A{4} = nsObj.MESSAGE.COLON;
    A{5} = nsObj.MESSAGE.STOPSEQUENCE;
    
    msg = strcat(A{:});
    
    disp(msg);
    dbstack; 
    
    % NG filename
    ns_Result = nsObj.CONST.ns_WRONGLABEL;
    
    clear nsObj;
    nsObj = '';
    
    return;
end

% Save the Neuroshare file to here. (intermediate files, too)
[nsObj.directory, nsObj.filename, nsObj.extension] = fileparts(deblank(filename));


% Check extension of filename

% Extension of filename is .nsn
if strcmp( nsObj.extension , '.nsn' )
    
    % OK filename
    ns_Result = nsObj.CONST.ns_OK;
    
% Extension of filename is nothing
elseif strcmp( nsObj.extension , '' )
    
    % Add '.nsn'
    nsObj.extension = '.nsn';
    
    % OK filename
    ns_Result = nsObj.CONST.ns_OK;
    
% Extension of filename is not .nsn
else
    A{1} = nsObj.MESSAGE.ERROR;
    A{2} = 'WRONG EXTENSION OF OUTPUT_FILE';
    A{3} = '(MUST BE .nsn)';
    A{4} = nsObj.MESSAGE.COLON;
    A{5} = nsObj.MESSAGE.STOPSEQUENCE;
    
    msg = strcat(A{:});
    
    disp(msg);
    dbstack; 
    
    % NG filename
    ns_Result = nsObj.CONST.ns_WRONGLABEL;
    
    clear nsObj;
    nsObj = '';
    
    return;
end

% -------------------------------------------------------------------------
% General File Information

% Document type identifier
nsObj.sMagicCode = 'NSN ver00000010';

% Tag Identifiers
ns_TAGELEMENT = struct( ...
    'dwElemType',           nsObj.CONST.ns_ENTITY_UNKNOWN, ...
    'dwElemLength',         uint32(0) ...
    );

% General Entity Information Header
ns_ENTITYINFO = struct( ...
    'szEntityLabel',        '', ...     % Specifies the label or name of the entity.
    'dwEntityType',         nsObj.CONST.ns_ENTITY_UNKNOWN, ...
    'dwItemCount',          uint32(0) ...
    );

% File Information Header
nsObj.ns_FILEINFO = struct(    ...
    'szFileType',           '', ...     % Human readable file type descriptor
    'dwEntityCount',        uint32(0), ...
    'dTimeStampResolution', double(0), ...
    'dTimeSpan',            double(0), ...
    'szAppName',            '', ...     % Information about the application that created the file
    'dwTime_Year',          uint32(1900), ...
    'dwTime_Month',         uint32(1), ...
    'dwTime_DayOfWeek',     uint32(1), ...
    'dwTime_Day',           uint32(1), ...
    'dwTime_Hour',          uint32(0), ...
    'dwTime_Min',           uint32(0), ...
    'dwTime_Sec',           uint32(0), ...
    'dwTime_MilliSec',      uint32(0), ...
    'szFileComment',        '' ...  % Extended comments
    );

% -------------------------------------------------------------------------
% Event Entity Element

% Element Tag
nsObj.EventHeader.ns_TAGELEMENT = ns_TAGELEMENT;

% General Entry Information Header
nsObj.EventHeader.ns_ENTITYINFO = ns_ENTITYINFO;

% Event Entity Specific Information Header
nsObj.EventHeader.ns_EVENTINFO = struct(  ...
    'dwEventType',          nsObj.CONST.ns_EVENT_TEXT, ...
    'dwMinDataLength',      uint32(0), ...
    'dwMaxDataLength',      uint32(0), ...
    'szCSVDesc',            '' ...
    );
nsObj.EventHeader.FID = 0;
% -------------------------------------------------------------------------
% Analog Entity Element

% Element Tag
nsObj.AnalogHeader.ns_TAGELEMENT = ns_TAGELEMENT;

% General Entry Information Header
nsObj.AnalogHeader.ns_ENTITYINFO = ns_ENTITYINFO;

% Analog Entity Specific Information Header
nsObj.AnalogHeader.ns_ANALOGINFO=struct( ...
    'dSampleRate',          double(0), ...
    'dMinVal',              double(0), ...
    'dMaxVal',              double(0), ...
    'szUnits',              '', ...
    'dResolution',          double(0), ...
    'dLocationX',           double(0), ...
    'dLocationY',           double(0), ...
    'dLocationZ',           double(0), ...
    'dLocationUser',        double(0), ...
    'dHighFreqCorner',      double(0), ...
    'dwHighFreqOrder',      uint32(0), ...
    'szHighFilterType',     '', ...
    'dLowFreqCorner',       double(0), ...
    'dwLowFreqOrder',       uint32(0), ...
    'szLowFilterType',      '', ...
    'szProbeInfo',          '' ...
    );
nsObj.AnalogHeader.FID = 0;

% -------------------------------------------------------------------------
% Segment Entity Element

% Element Tag
nsObj.SegmentHeader.ns_TAGELEMENT = ns_TAGELEMENT;

% General Entry Information Header
nsObj.SegmentHeader.ns_ENTITYINFO = ns_ENTITYINFO;

% Segment Entity Specific Information Header
nsObj.SegmentHeader.ns_SEGMENTINFO = struct( ...
    'dwSourceCount',        uint32(0), ...
    'dwMinSampleCount',     uint32(0), ...
    'dwMaxSampleCount',     uint32(0), ...
    'dSampleRate',          double(0), ...
    'szUnits',              '' ...
    );

% Segment Source Entity Specific Information Header
nsObj.SegmentHeader.ns_SEGSOURCEINFO = struct( ...
    'dMinVal',              double(0), ...
    'dMaxVal',              double(0), ...
    'dResolution',          double(0), ...
    'dSubSampleShift',      double(0), ...
    'dLocationX',           double(0), ...
    'dLocationY',           double(0), ...
    'dLocationZ',           double(0), ...
    'dLocationUser',        double(0), ...
    'dHighFreqCorner',      double(0), ...
    'dwHighFreqOrder',      uint32(0), ...
    'szHighFilterType',     '', ...
    'dLowFreqCorner',       double(0), ...
    'dwLowFreqOrder',       uint32(0), ...
    'szLowFilterType',      '', ...
    'szProbeInfo',          '' ...
    );
nsObj.SegmentHeader.FID = 0;

% -------------------------------------------------------------------------
% Neural Event Entity Element

% Element Tag
nsObj.NeuralEventHeader.ns_TAGELEMENT = ns_TAGELEMENT;

% General Entry Information Header
nsObj.NeuralEventHeader.ns_ENTITYINFO = ns_ENTITYINFO;

% Neural Event Entity Specific Information Header
nsObj.NeuralEventHeader.ns_NEURALINFO = struct( ...
    'dwSourceEntityID',     uint32(0), ...
    'dwSourceUnitID',       uint32(0), ...
    'szProbeInfo',          '' ...
    );
nsObj.NeuralEventHeader.FID = 0;
% -------------------------------------------------------------------------

nsObj.Event = cell(0);
nsObj.Analog = cell(0);
nsObj.Segment = cell(0);
nsObj.NeuralEvent = cell(0);

nsObj.chInfo = struct([]);

% Create object
nsObj = class(nsObj, 'ns_CreateFile');

