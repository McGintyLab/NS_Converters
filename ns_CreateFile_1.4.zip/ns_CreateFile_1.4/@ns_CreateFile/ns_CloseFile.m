function ns_Result = ns_CloseFile( nsObj )
% ns_CloseFile - Close intermediate files, Integrate intermediate files as a Neuroshare file.
% ns_Result = ns_CloseFile( nsObj )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
% 
% Outputs:
%   ns_Result - [double] - result value of this function.
%
% Created By : Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/03/13 
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  11/11/18
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group


% Close all intermediate files.
fclose('all');

% Save all header information (ns_***INFO) as intermediate files.(create, write, close)
% ns_FILEINFO
ns_Result = ns_SaveFileInfo(nsObj);
if nsObj.CONST.ns_OK ~= ns_Result
    return;
end

% ns_EVENTINFO
for ID=1:size(nsObj.Event, 2)
    ns_Result = ns_SaveEventInfo(nsObj, ID);
    if nsObj.CONST.ns_OK ~= ns_Result
        return;
    end
end

% ns_NEURALINFO
for ID=1:size(nsObj.NeuralEvent, 2)
    ns_Result = ns_SaveNeuralEventInfo(nsObj, ID);
    if nsObj.CONST.ns_OK ~= ns_Result
        return;
    end
end

% ns_ANALOGINFO
for ID=1:size(nsObj.Analog, 2)
    ns_Result = ns_SaveAnalogInfo(nsObj, ID);
    if nsObj.CONST.ns_OK ~= ns_Result
        return;
    end
end

% ns_SEGMENTINFO
for ID=1:size(nsObj.Segment, 2)
    ns_Result = ns_SaveSegmentInfo(nsObj, ID);
    if nsObj.CONST.ns_OK ~= ns_Result
        return;
    end
end

% ns_SEGSOURCEINFO
for ID=1:size(nsObj.Segment, 2)
    for SRCID = 1:size(nsObj.Segment{ID}.ns_SEGSOURCEINFO, 2)
        ns_Result = ns_SaveSegSourceInfo(nsObj, ID, SRCID);
        if nsObj.CONST.ns_OK ~= ns_Result
            return;
        end
    end
end

% chInfo
ns_Result = ns_SaveChInfo(nsObj);
if ns_Result ~= nsObj.CONST.ns_OK
    return;
end

% Delete Neuroshare file which exists already.
warning('off');
dstFile = fullfile(nsObj.directory, [nsObj.filename, nsObj.extension]);
delete(dstFile);
warning('on');

% Integrate All intermediate files from here.

% ns_FILEINFO
srcFile = fullfile(nsObj.directory, ['_00_FileInfoHeader_' nsObj.filename]);
ns_Result = FileCat( nsObj, dstFile, srcFile );
if nsObj.CONST.ns_OK ~= ns_Result
    return;
end
delete(srcFile);

% EVENT
for ID=1:size(nsObj.Event, 2)
    
    % ns_EVENTINFO
    srcFile = fullfile(nsObj.directory,...
        [sprintf('_01_%05d_EventInfoHeader_', ID) nsObj.filename]);
    ns_Result = FileCat( nsObj, dstFile, srcFile );
    if nsObj.CONST.ns_OK ~= ns_Result
        return;
    end
    delete(srcFile);
    
    % EventData
    srcFile = fullfile(nsObj.directory,...
        [sprintf('_01_%05d_EventData_', ID) nsObj.filename]);
    ns_Result = FileCat( nsObj, dstFile, srcFile );
    if nsObj.CONST.ns_OK ~= ns_Result
        return;
    end

    % Delete srcFile if exits
    if 0 ~= exist(srcFile,'file');  %   NOT EXIST : 0
        delete(srcFile);
    end

end

% ANALOG
for ID=1:size(nsObj.Analog, 2)
    
    % ns_ANALOGINFO
    srcFile = fullfile(nsObj.directory,...
        [sprintf('_01_%05d_AnalogInfoHeader_', ID) nsObj.filename]);
    ns_Result = FileCat( nsObj, dstFile, srcFile );
    if nsObj.CONST.ns_OK ~= ns_Result
        return;
    end
    delete(srcFile);
    
    % AnalogData
    srcFile = fullfile(nsObj.directory,...
        [sprintf('_01_%05d_AnalogData_', ID) nsObj.filename]);
    ns_Result = FileCat( nsObj, dstFile, srcFile );
    if nsObj.CONST.ns_OK ~= ns_Result
        return;
    end

    % Delete srcFile if exits
    if 0 ~= exist(srcFile,'file');  %   NOT EXIST : 0
        delete(srcFile);
    end
    
end

% SEGMENT
for ID=1:size(nsObj.Segment, 2)
    
    % ns_SEGMENTINFO
    srcFile = fullfile(nsObj.directory,...
        [sprintf('_01_%05d_SegmentInfoHeader_', ID) nsObj.filename]);
    ns_Result = FileCat( nsObj, dstFile, srcFile );
    if nsObj.CONST.ns_OK ~= ns_Result
        return;
    end
    delete(srcFile);
    
    % ns_SEGSOURCEINFO[n]
    for SEGID = 1:size(nsObj.Segment{ID}.ns_SEGSOURCEINFO, 2)
        srcFile = fullfile(nsObj.directory,...
            [sprintf('_01_%05d_%05d_SegmentSourceHeader_', ID, SEGID) nsObj.filename]);
        ns_Result = FileCat( nsObj, dstFile, srcFile );
        if nsObj.CONST.ns_OK ~= ns_Result
            return;
        end
        delete(srcFile);
    end

    % SegmentData
    srcFile = fullfile(nsObj.directory,...
        [sprintf('_01_%05d_SegmentData_', ID) nsObj.filename]);
    ns_Result = FileCat( nsObj, dstFile, srcFile );
    if nsObj.CONST.ns_OK ~= ns_Result
        return;
    end
    
    % Delete srcFile if exits
    if 0 ~= exist(srcFile,'file');  %   NOT EXIST : 0
        delete(srcFile);
    end

end

% NEURALEVENT
for ID=1:size(nsObj.NeuralEvent, 2)
    
    % ns_NEURALINFO
    srcFile = fullfile(nsObj.directory,...
        [sprintf('_01_%05d_NeuralEventInfoHeader_', ID) nsObj.filename]);
    ns_Result = FileCat( nsObj, dstFile, srcFile );
    if nsObj.CONST.ns_OK ~= ns_Result
        return;
    end
    delete(srcFile);
    
    % NeuralEventData
    srcFile = fullfile(nsObj.directory,...
        [sprintf('_01_%05d_NeuralEventData_', ID) nsObj.filename]);
    ns_Result = FileCat( nsObj, dstFile, srcFile );
    if nsObj.CONST.ns_OK ~= ns_Result
        return;
    end
    
    % Delete srcFile if exits
    if 0 ~= exist(srcFile,'file');  %   NOT EXIST : 0
        delete(srcFile);
    end

end

% CHINFO
if ~isempty(nsObj.chInfo)
    xmlFile = fullfile( nsObj.directory, 'chInfo.xml' );
%   zipFile = fullfile( nsObj.directory, 'chInfo.zip' );
%   zip(zipFile, xmlFile);
    gzip(xmlFile, fileparts(xmlFile));
    zipFile = [xmlFile '.gz'];

    fid  = fopen(zipFile);
    data = fread(fid, inf);
    fclose(fid);

    fid = fopen(dstFile,'ab');
    fwrite(fid, uint32(5), 'uint32');
    fwrite(fid, uint32(length(data)), 'uint32');
    fwrite(fid, data);
    fclose(fid);
    
    delete(xmlFile);
    delete(zipFile);
end
