function display(nsObj)
%display - Display nsObj's contents.
% display( nsObj )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%
% Outputs:
%
% Created By: Keiji HARADA (1),  kharada@atr.jp  09/04/30
% Modified By: Keiji HARADA (1),  kharada@atr.jp  10/03/02 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% display
disp(' ');
disp(' ********** nsObj has these contents. ********** ');
disp(' ');

% disp([' directory of output file: ', nsObj.directory]);
disp([' filename: ', nsObj.filename]);

% -------------------------------------------------------------------------
% General File Information

disp(' ');
disp([' sMagicCode <char[16]>: ', nsObj.sMagicCode]);
disp(' ');
disp(' ns_FILEINFO:');
displayStructureFileInfo(nsObj.ns_FILEINFO);

% -------------------------------------------------------------------------
% Event Entity Element

for ID = 1:size(nsObj.Event, 2)
    disp(' ');
    disp(' --- Event Entity Element');
    disp([' Event ID: ', num2str(ID)]);
    %disp(' ns_ENTITYINFO:');
    displayStructureEntityInfo(nsObj.Event{ID}.ns_ENTITYINFO);
    disp(' ns_EVENTINFO:');
    displayStructureEventInfo(nsObj.Event{ID}.ns_EVENTINFO);
end

% -------------------------------------------------------------------------
% Analog Entity Element
for ID = 1:size(nsObj.Analog, 2)
    disp(' ');
    disp(' --- Analog Entity Element ');
    disp([' Analog ID: ', num2str(ID)]);
    %disp(' ns_ENTITYINFO:');
    displayStructureEntityInfo(nsObj.Analog{ID}.ns_ENTITYINFO);
    disp(' ns_ANALOGINFO:');
    displayStructureAnalogInfo(nsObj.Analog{ID}.ns_ANALOGINFO);
end

% -------------------------------------------------------------------------
% Segment Entity Element
for ID = 1:size(nsObj.Segment, 2)
    disp(' ');
    disp(' --- Segment Entity Element ');
    disp([' Segment ID: ', num2str(ID)]);
    %disp(' ns_ENTITYINFO:');
    displayStructureEntityInfo(nsObj.Segment{ID}.ns_ENTITYINFO);
    disp(' ns_SEGMENTINFO:');
    displayStructureSegmentInfo(nsObj.Segment{ID}.ns_SEGMENTINFO);
    
    for SRCID = 1:size(nsObj.Segment{ID}.ns_SEGSOURCEINFO,2)
        disp(['  SegmentSource ID: ', num2str(SRCID)]);
        disp('  ns_SEGSOURCEINFO:');
        displayStructureSegSourceInfo(nsObj.Segment{ID}.ns_SEGSOURCEINFO(SRCID));
    end
end
% -------------------------------------------------------------------------
% Neural Event Entity Element
for ID = 1:size(nsObj.NeuralEvent, 2)
    disp(' ');
    disp(' --- Neural Event Entity Element ');
    disp([' Neural Event ID: ', num2str(ID)]);
    %disp(' ns_ENTITYINFO:');
    displayStructureEntityInfo(nsObj.NeuralEvent{ID}.ns_ENTITYINFO);
    disp(' ns_NEURALINFO:');
    displayStructureNeuralInfo(nsObj.NeuralEvent{ID}.ns_NEURALINFO);
end

%%
function displayStructureFileInfo(Struct)
FN = fieldnames(Struct);
for n=1:size(FN, 1)
    if strcmp( FN{n}, 'dwEntityCount' )
    else
        Val = eval(['Struct.' FN{n}]);
        disp(['    ', FN{n}, ' <',  class(Val), '>: ', num2str(Val)]);
    end
end
%%
function displayStructureEntityInfo(Struct)
FN = fieldnames(Struct);
for n=1:size(FN, 1)
    if strcmp( FN{n}, 'dwEntityType' )
    elseif strcmp( FN{n}, 'dwItemCount' )
    else
        Val = eval(['Struct.' FN{n}]);
        disp([' Label', ': ', num2str(Val)]);
    end
end
%%
function displayStructureEventInfo(Struct)
FN = fieldnames(Struct);
for n=1:size(FN, 1)
    if strcmp( FN{n}, 'dwMinDataLength' )
    elseif strcmp( FN{n}, 'dwMaxDataLength' )
    else
        Val = eval(['Struct.' FN{n}]);
        disp(['    ', FN{n}, ' <',  class(Val), '>: ', num2str(Val)]);
    end
end
%%
function displayStructureAnalogInfo(Struct)
FN = fieldnames(Struct);
for n=1:size(FN, 1)
    Val = eval(['Struct.' FN{n}]);
    disp(['    ', FN{n}, ' <',  class(Val), '>: ', num2str(Val)]);
end
%%
function displayStructureSegmentInfo(Struct)
FN = fieldnames(Struct);
for n=1:size(FN, 1)
    if strcmp( FN{n}, 'dwSourceCount' )
    elseif strcmp( FN{n}, 'dwMinSampleCount' )
    elseif strcmp( FN{n}, 'dwMaxSampleCount' )
    else
        Val = eval(['Struct.' FN{n}]);
        disp(['    ', FN{n}, ' <',  class(Val), '>: ', num2str(Val)]);
    end
end
%%
function displayStructureSegSourceInfo(Struct)
FN = fieldnames(Struct);
for n=1:size(FN, 1)
    Val = eval(['Struct.' FN{n}]);
    disp(['     ', FN{n}, ' <',  class(Val), '>: ', num2str(Val)]);
end
%%
function displayStructureNeuralInfo(Struct)
FN = fieldnames(Struct);
for n=1:size(FN, 1)
    Val = eval(['Struct.' FN{n}]);
    disp(['    ', FN{n}, ' <',  class(Val), '>: ', num2str(Val)]);
end
