function display_All_Infomation(nsObj)
% display_All_Infomation - Display nsObj's all contents.
% display_All_Infomation( nsObj )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%
% Outputs:
%
% Created By: Keiji HARADA (1),  kharada@atr.jp  09/04/30
% Modified By: Keiji HARADA (1),  kharada@atr.jp  10/05/07 
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% Display all data.
disp(' ');
disp([' class: ', class(nsObj)]);

disp(' ');
disp([' directory of output file: ', nsObj.directory]);
disp([' filename: ', nsObj.filename]);

% -------------------------------------------------------------------------
disp(' ');
disp([' sMagicCode <char[16]>: ', nsObj.sMagicCode]);

disp(' ');
disp(' ns_FILEINFO:');
displayStructure(nsObj.ns_FILEINFO);

% -------------------------------------------------------------------------
% Event Entity Element

for ID = 1:size(nsObj.Event, 2)
	disp(' ');
	disp(' --- Event Entity Element');
	disp([' Event ID: ', num2str(ID)]);
	disp(' ns_TAGELEMENT:');
	displayStructure(nsObj.Event{ID}.ns_TAGELEMENT);
	disp(' ns_ENTITYINFO:');
	displayStructure(nsObj.Event{ID}.ns_ENTITYINFO);
	disp(' ns_EVENTINFO:');
	displayStructure(nsObj.Event{ID}.ns_EVENTINFO);
end


% -------------------------------------------------------------------------
% Analog Entity Element
for ID = 1:size(nsObj.Analog, 2)
	disp(' ');
	disp(' --- Analog Entity Element ');
	disp([' Analog ID: ', num2str(ID)]);
	disp(' ns_TAGELEMENT:');
	displayStructure(nsObj.Analog{ID}.ns_TAGELEMENT);
	disp(' ns_ENTITYINFO:');
	displayStructure(nsObj.Analog{ID}.ns_ENTITYINFO);
	disp(' ns_ANALOGINFO:');
	displayStructure(nsObj.Analog{ID}.ns_ANALOGINFO);
end

% -------------------------------------------------------------------------
% Segment Entity Element
for ID = 1:size(nsObj.Segment, 2)
	disp(' ');
	disp(' --- Segment Entity Element ');
	disp([' Segment ID: ', num2str(ID)]);
	disp(' ns_TAGELEMENT:');
	displayStructure(nsObj.Segment{ID}.ns_TAGELEMENT);
	disp(' ns_ENTITYINFO:');
	displayStructure(nsObj.Segment{ID}.ns_ENTITYINFO);
	disp(' ns_SEGMENTINFO:');
	displayStructure(nsObj.Segment{ID}.ns_SEGMENTINFO);
	
	num_Source = nsObj.Segment{ID}.ns_SEGMENTINFO.dwSourceCount;
	for SRCID = 1:num_Source
		disp([' SegmentSource ID: ', num2str(SRCID)]);
		disp(' ns_SEGSOURCEINFO:');
		displayStructure(nsObj.Segment{ID}.ns_SEGSOURCEINFO(SRCID));
	end
end
% -------------------------------------------------------------------------
% Neural Event Entity Element
for ID = 1:size(nsObj.NeuralEvent, 2)
	disp(' ');
	disp(' --- Neural Event Entity Element ');
	disp([' Neural Event ID: ', num2str(ID)]);
	disp(' ns_TAGELEMENT:');
	displayStructure(nsObj.NeuralEvent{ID}.ns_TAGELEMENT);
	disp(' ns_ENTITYINFO:');
	displayStructure(nsObj.NeuralEvent{ID}.ns_ENTITYINFO);
	disp(' ns_NEURALINFO:');
	displayStructure(nsObj.NeuralEvent{ID}.ns_NEURALINFO);
end

%%
function displayStructure(Struct)
FN = fieldnames(Struct);
for n=1:size(FN, 1)
    Val = eval(['Struct.' FN{n}]);
    disp(['    ', FN{n}, ' <',  class(Val), '>: ', num2str(Val)]);
end
