function [ ns_Result nsObj ID ] = ns_NewEventData( nsObj, szEntityLabel, chType, chComment )
% ns_NewEventData - Update nsObj, Create intermediate file for Event Entity.
% [ ns_Result nsObj ID ] = ns_NewEventData( nsObj, szEntityLabel, chThpe, chComment )
%
% Inputs:
%   nsObj           - [struct] - object which has members of Neuroshare data format.
%   szEntityLabel   - [char]<OPTIONAL> - label of this entity.
%   chType          - [char]<OPTIONAL> - channel type of this entity.
%   chComment  - [char]<OPTIONAL> - comment of this entity.
%
% Outputs:
%   ns_Result       - [double] - result value of this function.
%   nsObj           - [struct] - object which has members of Neuroshare data format.
%   ID              - [uint32] - identification number of the entity.
%
% Created  By: Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/03/02 
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/03/22
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  11/11/18
% Modified By: Keiji HARADA (1),  kharada@atr.jp  12/01/19
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% Check number of Inputs
if nargin == 1
    % szEntityLabel and chInfo are omitted.
    szEntityLabel = '';
    chInfo        = '';
elseif nargin ==2
    chInfo        = '';
elseif nargin == 3;
    chComment = '';
    chInfo        = ns_ChInfo(nsObj, szEntityLabel, chType, chComment, nsObj.CONST.ns_ENTITY_EVENT);
elseif nargin == 4;
    chInfo        = ns_ChInfo(nsObj, szEntityLabel, chType, chComment, nsObj.CONST.ns_ENTITY_EVENT);
end

% Check value of szEntityLabel
% If A condition consists, ns_Result is ns_WRONGLABEL.
% A. Wrong type of szEntityLabel (Can't change szEntityLabel value to char(scalar(1*n)) value.)
ns_Result = ns_CheckLabel(nsObj, szEntityLabel);
if nsObj.CONST.ns_OK ~= ns_Result
    ID = '';
    return;
end

% Check value of chInfo
ns_Result = ns_CheckChInfo(nsObj, chInfo);
if ns_Result ~= nsObj.CONST.ns_OK
    ID = '';
    return;
end

% Copy chInfo
if isempty(chInfo)
    nsObj.chInfo = '';
else
    fname = fieldnames(chInfo);
    ind   = length(nsObj.chInfo) + 1;
    for iti=1:length(fname)
        nsObj.chInfo(ind).(fname{iti}) = chInfo.(fname{iti});
    end
end

% Create new ID.
ID = cast( size(nsObj.Event, 2) + 1 , 'uint32' );

% Initialize values.
nsObj.Event{ID} = nsObj.EventHeader;

% Create intermediate file.
fname = [sprintf('_01_%05d_EventData_', ID) nsObj.filename];
filename = fullfile(nsObj.directory, fname);
%nsObj.Event{ID}.FID = fopen(filename, 'w');
nsObj.Event{ID}.FNAME = filename;       % SM

% Update nsObj.
% *************  ns_FILEINFO  ***************
% ns_FILEINFO : dwEntityCount (total number of entities)
nsObj.ns_FILEINFO.dwEntityCount = nsObj.ns_FILEINFO.dwEntityCount + 1;

% *************  ns_TAGELEMENT  *************
% ns_TAGELEMENT : dwElemType (kind of entity)
% ns_TAGELEMENT : dwElemLength (total bytes of this entity)
nsObj.Event{ID}.ns_TAGELEMENT.dwElemType     = nsObj.CONST.ns_ENTITY_EVENT;
nsObj.Event{ID}.ns_TAGELEMENT.dwElemLength   = 40 + 140;

% *************  ns_ENTITYINFO  *************
% ns_ENTITYINFO : szEntityLabel (label of this entity)
% ns_ENTITYINFO : dwEntityType (kind of entity)
nsObj.Event{ID}.ns_ENTITYINFO.szEntityLabel  = szEntityLabel;
nsObj.Event{ID}.ns_ENTITYINFO.dwEntityType   = nsObj.CONST.ns_ENTITY_EVENT;

% *************  ns_EVENTINFO  **************
% ns_EVENTINFO : dwMaxDataLength / dwMinDataLength (max/min length)
nsObj.Event{ID}.ns_EVENTINFO.dwMinDataLength = uint32(2^32-1);  % max length as uint32
nsObj.Event{ID}.ns_EVENTINFO.dwMaxDataLength = uint32(0);   % min length as uint32
