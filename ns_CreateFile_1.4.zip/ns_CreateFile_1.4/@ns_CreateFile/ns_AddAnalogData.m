function [ ns_Result nsObj ] = ns_AddAnalogData( nsObj, ID, dTime, dData )
% ns_AddAnalogData - Update nsObj, Add dTime and dData to the intermediate file which is identified by ID.
% [ ns_Result nsObj ] = ns_AddAnalogData( nsObj, ID, dTime, dData )
%
% Inputs:
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%   ID        - [uint32] - identification number of the entity in the intermediate file.
%   dTime     - [double] - value of timestamp.
%   dData     - [double] - values of data.(Vector : 1*n)
%
% Outputs:
%   ns_Result - [double] - result value of this function.
%   nsObj     - [struct] - object which has members of Neuroshare data format.
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/03/02 
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/03/16
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/03/22
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% Check value of ID 
% If A or B condition consists, ns_Result is ns_WRONGID.
% A. Wrong type of ID (Can't change ID value to uint32(scalar(1*1)) value.)
% B. Unregistered ID (As Analog Entity.)
ns_Result = ns_CheckID( nsObj, ID, nsObj.CONST.ns_ENTITY_ANALOG );
if nsObj.CONST.ns_OK ~= ns_Result
    return;
end

% Convert int to double, if needed      % SM
if isinteger(dTime)
    dTime = double(dTime);
end
if isinteger(dData)
    dData = double(dData);
end

% Check value of dTime and dData 
% If A or B condition consists, ns_Result is ns_WRONGDATA.
% A. Wrong type of dTime (Can't change dTime value to double(scalar(1*1)) value.)
% B. Wrong type of dData (Can't change dData value to double(scalar(1*n)) value.)
ns_Result = ns_CheckAnalogData( nsObj, dTime, dData );
if nsObj.CONST.ns_OK ~= ns_Result
    return;
end
  
% Correct values to rewrite object.
maxVal = max(dData.');       % max value of dData.
minVal = min(dData.');       % min value of dData.
dataNum = size( dData, 2 );  % number of dData.

% Add data to the intermediate file.
fid = fopen(nsObj.Analog{ID}.FNAME,'a');       % SM
%fwrite(nsObj.Analog{ID}.FID, dTime, 'double');    % as dTimestamp[n]
%fwrite(nsObj.Analog{ID}.FID, dataNum, 'uint32');  % as dwDataCount[n]
%fwrite(nsObj.Analog{ID}.FID, dData, 'double');    % as dAnalogValue[0] - AnalogValue[dwDataCount[n]-1]
fwrite(fid,dTime,'double');
fwrite(fid,dataNum,'uint32');
fwrite(fid,dData,'double');
fclose(fid);

% Update nsObj.
% *************  ns_TAGELEMENT  *************
% ns_TAGELEMENT : dwElemLength (total bytes of this analog entity)
nsObj.Analog{ID}.ns_TAGELEMENT.dwElemLength = nsObj.Analog{ID}.ns_TAGELEMENT.dwElemLength + 8 + 4 + 8 * dataNum;

% *************  ns_ENTITYINFO  *************
% ns_ENTITYINFO : dwItemCount (total number of this analog values)
nsObj.Analog{ID}.ns_ENTITYINFO.dwItemCount = nsObj.Analog{ID}.ns_ENTITYINFO.dwItemCount + dataNum;

% *************  ns_ANALOGINFO  *************
% ns_ANALOGINFO : dMaxVal/dMinVal (max or min value)
if nsObj.Analog{ID}.ns_ANALOGINFO.dMaxVal < maxVal
    nsObj.Analog{ID}.ns_ANALOGINFO.dMaxVal = maxVal;
end
if nsObj.Analog{ID}.ns_ANALOGINFO.dMinVal > minVal
    nsObj.Analog{ID}.ns_ANALOGINFO.dMinVal = minVal;
end
