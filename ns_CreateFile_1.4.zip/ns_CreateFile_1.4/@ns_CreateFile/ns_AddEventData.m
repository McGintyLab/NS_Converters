function [ ns_Result nsObj ] = ns_AddEventData(nsObj, ID, dTimestamp, EventValue)
% ns_AddEventData - Update nsObj, Add dTimestamp and EventValue to the intermediate file which is identified by ID.
% [ ns_Result nsObj ] = ns_AddEventData( nsObj, ID, dTimestamp, EventValue )
%
% Inputs:
%   nsObj           - [struct] - object which has members of Neuroshare data format.
%   ID              - [uint32] - identification number of this type of entity.
%   dTimestamp      - [double] - value of timestamp.
%   EventValue      - [int8/uint8, int16/uint16, int32/uint32 or char] - values of data.(**1)
% 
% Outputs:
%   ns_Result       - [double] - result value of this function.
%   nsObj           - [struct] - object which has members of Neuroshare data format.
%
% (**1) if value is int**/uint**, (scalar : 1*1) if value is char, (vector : 1*n)
%
% Created By:  Keiji HARADA (1),    kharada@atr.jp    09/04/30
% Modified By: Keiji HARADA (1),    kharada@atr.jp    10/03/02 
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/03/16
% Modified By: Satoshi MURATA (1),  satoshi-m@atr.jp  10/03/22
% (1) ATR Intl. Computational Neuroscience Labs, Decoding Group

% Check value of ID 
% If A or B condition consists, ns_Result is ns_WRONGID.
% A. Wrong type of ID (Can't change ID value to uint32(scalar(1*1)) value.)
% B. Unregistered ID (As Event Entity.)
ns_Result = ns_CheckID( nsObj, ID, nsObj.CONST.ns_ENTITY_EVENT );
if nsObj.CONST.ns_OK ~= ns_Result
 return;
end

% Convert int to double, if needed      % SM
if isinteger(dTimestamp)
    dTimestamp = double(dTimestamp);
end

% Check value of dTimestamp and EventValue
% If A or B condition consists, ns_Result is ns_WRONGDATA.
% A. Wrong type of dTimestamp (Can't change dTimestamp value to double(scalar(1*1)) value.)
% B. Wrong type of EventValue (Can't change EventValue value to int**/uint**(scalar(1*1)) or char(Vector(1*n)) value.)
ns_Result = ns_CheckEventData( nsObj, dTimestamp, EventValue );
if nsObj.CONST.ns_OK ~= ns_Result
 return;
end
  
% Change type of EventValue to int32 (if EventValue[double] = EventValue[int32]).
if strcmp( class( EventValue ), 'double' )
 EventValue = cast( EventValue, 'int32' );
end

% Check consistency
% If A condition consists, ns_Result is ns_WRONGDATA.
% A. Different type EventValue
ns_Result = ns_CheckConsistencyOfEventData( nsObj, ID, EventValue );
if nsObj.CONST.ns_OK ~= ns_Result
 return;
end


% Correct values to rewrite object.

% EventValue is ...
% uint8 : dwDataByteSize = 1 [Byte], dwEventType = nsObj.CONST.ns_EVENT_BYTE;
if strcmp(class(EventValue) ,'uint8')
    dwDataByteSize = prod(size(EventValue));
    typeId = 'uint8';
    nsObj.Event{ID}.ns_EVENTINFO.dwEventType = nsObj.CONST.ns_EVENT_BYTE;

% int8 : dwDataByteSize = 1  [Byte], dwEventType = nsObj.CONST.ns_EVENT_BYTE;
elseif strcmp(class(EventValue) ,'int8')
    dwDataByteSize = prod(size(EventValue));
    typeId = 'int8';
    nsObj.Event{ID}.ns_EVENTINFO.dwEventType = nsObj.CONST.ns_EVENT_BYTE;

% uint16 : dwDataByteSize = 2 [Byte], dwEventType = nsObj.CONST.ns_EVENT_WORD;
elseif strcmp(class(EventValue) ,'uint16')
    dwDataByteSize = 2 * prod(size(EventValue));
    typeId = 'uint16';
    nsObj.Event{ID}.ns_EVENTINFO.dwEventType = nsObj.CONST.ns_EVENT_WORD;

% int16 : dwDataByteSize = 2 [Byte], dwEventType = nsObj.CONST.ns_EVENT_WORD;
elseif strcmp(class(EventValue) ,'int16')
    dwDataByteSize = 2 * prod(size(EventValue));
    typeId = 'int16';
    nsObj.Event{ID}.ns_EVENTINFO.dwEventType = nsObj.CONST.ns_EVENT_WORD;

% uint32 : dwDataByteSize = 4 [Byte], dwEventType = nsObj.CONST.ns_EVENT_DWORD;
elseif strcmp(class(EventValue) ,'uint32')
    dwDataByteSize = 4 * prod(size(EventValue));
    typeId = 'uint32';
    nsObj.Event{ID}.ns_EVENTINFO.dwEventType = nsObj.CONST.ns_EVENT_DWORD;

% int32 : dwDataByteSize = 4 [Byte], dwEventType = nsObj.CONST.ns_EVENT_DWORD;
elseif strcmp(class(EventValue) ,'int32')
    dwDataByteSize = 4 * prod(size(EventValue));
    typeId = 'int32';
    nsObj.Event{ID}.ns_EVENTINFO.dwEventType = nsObj.CONST.ns_EVENT_DWORD;

% char : dwDataByteSize = *** [Byte](length of text), dwEventType = nsObj.CONST.ns_EVENT_TEXT;
else
    dwDataByteSize = prod(size(EventValue));
    typeId = 'char';
    nsObj.Event{ID}.ns_EVENTINFO.dwEventType = nsObj.CONST.ns_EVENT_TEXT;
end

% size of EventValue
dwDataByteSize = uint32(dwDataByteSize);

% Add data to the intermediate file.
fid = fopen(nsObj.Event{ID}.FNAME,'a');       % SM
%fwrite(nsObj.Event{ID}.FID, dTimestamp,'double');
%fwrite(nsObj.Event{ID}.FID, dwDataByteSize, 'uint32');
%fwrite(nsObj.Event{ID}.FID, EventValue, typeId);
fwrite(fid,dTimestamp,'double');
fwrite(fid,dwDataByteSize,'uint32');
fwrite(fid,EventValue,typeId);
fclose(fid);

% Update nsObj.
% *************  ns_TAGELEMENT  *************
% ns_TAGELEMENT : dwElemLength (total bytes of this analog entity)
nsObj.Event{ID}.ns_TAGELEMENT.dwElemLength = ...
    nsObj.Event{ID}.ns_TAGELEMENT.dwElemLength + 8 + 4 + dwDataByteSize;

% *************  ns_ENTITYINFO  *************
% ns_ENTITYINFO : dwItemCount (total number of this event values)
nsObj.Event{ID}.ns_ENTITYINFO.dwItemCount = ...
    nsObj.Event{ID}.ns_ENTITYINFO.dwItemCount + 1;

% *************  ns_EVENTINFO  *************
% ns_EVENTINFO : dwMaxDataLength/dwMinDataLength (max or min length)
if nsObj.Event{ID}.ns_EVENTINFO.dwMaxDataLength < dwDataByteSize
    nsObj.Event{ID}.ns_EVENTINFO.dwMaxDataLength = dwDataByteSize;
end
if nsObj.Event{ID}.ns_EVENTINFO.dwMinDataLength > dwDataByteSize
    nsObj.Event{ID}.ns_EVENTINFO.dwMinDataLength = dwDataByteSize;
end
